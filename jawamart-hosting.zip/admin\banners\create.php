<?php
/**
 * JAWA MART - Tambah Banner Promosi
 * File: admin/banners/create.php
 */

declare(strict_types=1);

$adminTitle = 'Tambah Banner Promosi';
require_once __DIR__ . '/../includes/header.php';

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['csrf_token'] ?? '';
    if (!verifyCsrfToken($token)) {
        $errors[] = 'Sesi form Anda telah kedaluwarsa. Silakan muat ulang halaman.';
    } else {
        $title       = trim($_POST['title'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $btnText     = trim($_POST['button_text'] ?? '');
        $btnLink     = trim($_POST['button_link'] ?? '');
        $sortOrder   = (int)($_POST['sort_order'] ?? 0);
        $status      = isset($_POST['status']) ? 1 : 0;

        if (empty($title)) {
            $errors[] = 'Judul banner wajib diisi.';
        }

        // Upload Banner Image
        $imagePath = 'uploads/banners/banner-1.svg';
        if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
            $uploadRes = uploadImage($_FILES['image'], 'banners', 'ban');
            if ($uploadRes['success']) {
                $imagePath = $uploadRes['path'];
            } else {
                $errors[] = $uploadRes['message'];
            }
        } else {
            $errors[] = 'Silakan pilih file gambar banner yang akan diunggah.';
        }

        if (empty($errors)) {
            try {
                $stmt = $pdo->prepare("
                    INSERT INTO banners (title, description, image, button_text, button_link, status, sort_order, created_at, updated_at) 
                    VALUES (:title, :description, :image, :button_text, :button_link, :status, :sort_order, NOW(), NOW())
                ");
                $stmt->execute([
                    'title'       => $title,
                    'description' => $description,
                    'image'       => $imagePath,
                    'button_text' => $btnText,
                    'button_link' => $btnLink,
                    'status'      => $status,
                    'sort_order'  => $sortOrder
                ]);

                setFlash('success', 'Banner promosi berhasil ditambahkan!');
                header('Location: index.php');
                exit;
            } catch (Exception $e) {
                error_log("Error creating banner: " . $e->getMessage());
                $errors[] = 'Gagal menyimpan banner: ' . $e->getMessage();
            }
        }
    }
}
?>

<div class="page-header">
  <div>
    <h1 class="page-title">Tambah Banner Promosi Baru</h1>
    <p class="page-subtitle">Unggah gambar spanduk promosi dan tentukan judul serta link tujuannya</p>
  </div>
  <a href="index.php" class="btn btn-secondary">&larr; Kembali ke Daftar Banner</a>
</div>

<?php if (!empty($errors)): ?>
  <div class="flash-alert danger">
    <div>
      <strong>Terjadi kesalahan:</strong>
      <ul style="margin-left: 20px; margin-top: 4px;">
        <?php foreach ($errors as $err): ?>
          <li><?= htmlspecialchars($err) ?></li>
        <?php endforeach; ?>
      </ul>
    </div>
  </div>
<?php endif; ?>

<div class="admin-card">
  <div class="admin-card-body">
    <form action="create.php" method="POST" enctype="multipart/form-data">
      <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">

      <div class="form-group">
        <label class="form-label" for="title">Judul Banner <span style="color:red;">*</span></label>
        <input type="text" name="title" id="title" class="form-control" placeholder="Contoh: Promo Sembako Hemat Bulan Ini" required value="<?= htmlspecialchars($_POST['title'] ?? '') ?>">
      </div>

      <div class="form-group">
        <label class="form-label" for="description">Deskripsi Singkat Banner</label>
        <input type="text" name="description" id="description" class="form-control" placeholder="Contoh: Belanja beras, minyak, dan gula diskon hingga 20%" value="<?= htmlspecialchars($_POST['description'] ?? '') ?>">
      </div>

      <div class="form-row">
        <div class="form-group">
          <label class="form-label" for="button_text">Teks Tombol (Opsional)</label>
          <input type="text" name="button_text" id="button_text" class="form-control" placeholder="Contoh: Belanja Sekarang" value="<?= htmlspecialchars($_POST['button_text'] ?? '') ?>">
        </div>

        <div class="form-group">
          <label class="form-label" for="button_link">Tautan Tombol / Banner (URL)</label>
          <input type="text" name="button_link" id="button_link" class="form-control" placeholder="Contoh: products.php atau products.php?featured=1" value="<?= htmlspecialchars($_POST['button_link'] ?? 'products.php') ?>">
        </div>

        <div class="form-group">
          <label class="form-label" for="sort_order">Nomor Urutan Tampil</label>
          <input type="number" min="0" name="sort_order" id="sort_order" class="form-control" placeholder="1" value="<?= htmlspecialchars($_POST['sort_order'] ?? '1') ?>">
        </div>
      </div>

      <div class="form-group">
        <label class="form-label" for="image">File Gambar Banner <span style="color:red;">*</span> (Rasio 1200x450 direkomendasikan, Maks 2MB)</label>
        <input type="file" name="image" id="image" class="form-control" accept="image/*" required data-preview="bannerImgPreview">
        <div class="img-preview-box" style="width: 260px; height: 95px;">
          <img id="bannerImgPreview" src="../../assets/images/placeholder.svg" alt="Preview Banner">
        </div>
      </div>

      <div style="margin: 20px 0;">
        <label style="display: flex; align-items: center; gap: 8px; cursor: pointer; font-weight: 600;">
          <input type="checkbox" name="status" value="1" <?= (!isset($_POST['status']) || $_POST['status'] == '1') ? 'checked' : '' ?>>
          <span>Status Aktif (Tampilkan di Beranda)</span>
        </label>
      </div>

      <div style="display: flex; gap: 12px; margin-top: 24px;">
        <button type="submit" class="btn btn-primary" style="padding: 10px 24px;">Simpan Banner Baru</button>
        <a href="index.php" class="btn btn-secondary">Batal</a>
      </div>
    </form>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
