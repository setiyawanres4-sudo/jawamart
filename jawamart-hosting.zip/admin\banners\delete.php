<?php
/**
 * JAWA MART - Hapus Banner Promosi
 * File: admin/banners/delete.php
 */

declare(strict_types=1);

require_once __DIR__ . '/../../includes/auth.php';
requireAdminAuth();

$id    = (int)($_GET['id'] ?? 0);
$token = $_GET['csrf_token'] ?? '';

if (!verifyCsrfToken($token)) {
    setFlash('danger', 'Token keamanan tidak valid atau telah kedaluwarsa.');
    header('Location: index.php');
    exit;
}

if ($id <= 0) {
    setFlash('danger', 'ID banner tidak valid.');
    header('Location: index.php');
    exit;
}

try {
    $stmtDel = $pdo->prepare("DELETE FROM banners WHERE id = :id");
    $stmtDel->execute(['id' => $id]);

    if ($stmtDel->rowCount() > 0) {
        setFlash('success', 'Banner promosi berhasil dihapus.');
    } else {
        setFlash('warning', 'Banner tidak ditemukan.');
    }
} catch (Exception $e) {
    error_log("Error deleting banner: " . $e->getMessage());
    setFlash('danger', 'Gagal menghapus banner: ' . $e->getMessage());
}

header('Location: index.php');
exit;
