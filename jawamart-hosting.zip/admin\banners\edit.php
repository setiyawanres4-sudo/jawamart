<?php
/**
 * JAWA MART - Edit Banner Promosi
 * File: admin/banners/edit.php
 */

declare(strict_types=1);

$adminTitle = 'Edit Banner Promosi';
require_once __DIR__ . '/../includes/header.php';

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    header('Location: index.php');
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM banners WHERE id = :id LIMIT 1");
$stmt->execute(['id' => $id]);
$banner = $stmt->fetch();

if (!$banner) {
    setFlash('danger', 'Banner tidak ditemukan.');
    header('Location: index.php');
    exit;
}

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['csrf_token'] ?? '';
    if (!verifyCsrfToken($token)) {
        $errors[] = 'Sesi form Anda telah kedaluwarsa. Silakan muat ulang halaman.';
    } else {
        $title       = trim($_POST['title'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $btnText     = trim($_POST['button_text'] ?? '');
        $btnLink     = trim($_POST['button_link'] ?? '');
        $sortOrder   = (int)($_POST['sort_order'] ?? 0);
        $status      = isset($_POST['status']) ? 1 : 0;

        if (empty($title)) {
            $errors[] = 'Judul banner wajib diisi.';
        }

        // Upload New Banner Image if provided
        $newImagePath = null;
        if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
            $uploadRes = uploadImage($_FILES['image'], 'banners', 'ban');
            if ($uploadRes['success']) {
                $newImagePath = $uploadRes['path'];
            } else {
                $errors[] = $uploadRes['message'];
            }
        }

        if (empty($errors)) {
            try {
                $finalImagePath = $newImagePath ?? $banner['image'];

                $stmtUp = $pdo->prepare("
                    UPDATE banners SET 
                        title = :title,
                        description = :description,
                        image = :image,
                        button_text = :button_text,
                        button_link = :button_link,
                        status = :status,
                        sort_order = :sort_order,
                        updated_at = NOW()
                    WHERE id = :id
                ");

                $stmtUp->execute([
                    'title'       => $title,
                    'description' => $description,
                    'image'       => $finalImagePath,
                    'button_text' => $btnText,
                    'button_link' => $btnLink,
                    'status'      => $status,
                    'sort_order'  => $sortOrder,
                    'id'          => $id
                ]);

                setFlash('success', 'Banner promosi berhasil diperbarui!');
                header('Location: index.php');
                exit;
            } catch (Exception $e) {
                error_log("Error updating banner: " . $e->getMessage());
                $errors[] = 'Gagal menyimpan perubahan banner: ' . $e->getMessage();
            }
        }
    }
}
?>

<div class="page-header">
  <div>
    <h1 class="page-title">Edit Banner Promosi</h1>
    <p class="page-subtitle">Ubah teks, urutan, gambar, atau link banner</p>
  </div>
  <a href="index.php" class="btn btn-secondary">&larr; Kembali ke Daftar Banner</a>
</div>

<?php if (!empty($errors)): ?>
  <div class="flash-alert danger">
    <div>
      <strong>Terjadi kesalahan:</strong>
      <ul style="margin-left: 20px; margin-top: 4px;">
        <?php foreach ($errors as $err): ?>
          <li><?= htmlspecialchars($err) ?></li>
        <?php endforeach; ?>
      </ul>
    </div>
  </div>
<?php endif; ?>

<div class="admin-card">
  <div class="admin-card-body">
    <form action="edit.php?id=<?= $banner['id'] ?>" method="POST" enctype="multipart/form-data">
      <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">

      <div class="form-group">
        <label class="form-label" for="title">Judul Banner <span style="color:red;">*</span></label>
        <input type="text" name="title" id="title" class="form-control" required value="<?= htmlspecialchars($banner['title']) ?>">
      </div>

      <div class="form-group">
        <label class="form-label" for="description">Deskripsi Singkat Banner</label>
        <input type="text" name="description" id="description" class="form-control" value="<?= htmlspecialchars($banner['description'] ?? '') ?>">
      </div>

      <div class="form-row">
        <div class="form-group">
          <label class="form-label" for="button_text">Teks Tombol</label>
          <input type="text" name="button_text" id="button_text" class="form-control" value="<?= htmlspecialchars($banner['button_text'] ?? '') ?>">
        </div>

        <div class="form-group">
          <label class="form-label" for="button_link">Tautan Tombol / Banner (URL)</label>
          <input type="text" name="button_link" id="button_link" class="form-control" value="<?= htmlspecialchars($banner['button_link'] ?? '') ?>">
        </div>

        <div class="form-group">
          <label class="form-label" for="sort_order">Nomor Urutan Tampil</label>
          <input type="number" min="0" name="sort_order" id="sort_order" class="form-control" value="<?= (int)$banner['sort_order'] ?>">
        </div>
      </div>

      <div class="form-group">
        <label class="form-label" for="image">Ganti Gambar Banner (Kosongkan jika tetap memakai gambar lama)</label>
        <input type="file" name="image" id="image" class="form-control" accept="image/*" data-preview="bannerImgPreview">
        <div style="margin-top: 8px;">
          <div style="font-size: 11.5px; color: #64748b; margin-bottom: 4px;">Banner Saat Ini / Preview:</div>
          <div class="img-preview-box" style="width: 260px; height: 95px;">
            <img id="bannerImgPreview" src="../../<?= htmlspecialchars(!empty($banner['image']) ? $banner['image'] : 'assets/images/placeholder.svg') ?>" alt="Preview">
          </div>
        </div>
      </div>

      <div style="margin: 20px 0;">
        <label style="display: flex; align-items: center; gap: 8px; cursor: pointer; font-weight: 600;">
          <input type="checkbox" name="status" value="1" <?= $banner['status'] ? 'checked' : '' ?>>
          <span>Status Aktif</span>
        </label>
      </div>

      <div style="display: flex; gap: 12px; margin-top: 24px;">
        <button type="submit" class="btn btn-primary" style="padding: 10px 24px;">Simpan Perubahan</button>
        <a href="index.php" class="btn btn-secondary">Batal</a>
      </div>
    </form>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
