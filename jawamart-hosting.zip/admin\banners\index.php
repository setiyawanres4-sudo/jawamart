<?php
/**
 * JAWA MART - Kelola Banner Promosi
 * File: admin/banners/index.php
 */

declare(strict_types=1);

$adminTitle = 'Kelola Banner Promosi';
require_once __DIR__ . '/../includes/header.php';

$banners = [];
try {
    $stmt = $pdo->query("SELECT * FROM banners ORDER BY sort_order ASC, id DESC");
    $banners = $stmt->fetchAll();
} catch (Exception $e) {
    error_log("Error fetching banners: " . $e->getMessage());
}
?>

<div class="page-header">
  <div>
    <h1 class="page-title">Kelola Banner Promosi</h1>
    <p class="page-subtitle">Atur spanduk slider promosi sembako pada halaman beranda website</p>
  </div>
  <a href="create.php" class="btn btn-primary">+ Tambah Banner Baru</a>
</div>

<div class="admin-card">
  <div class="table-responsive">
    <table class="admin-table">
      <thead>
        <tr>
          <th>Urutan</th>
          <th>Preview Banner</th>
          <th>Judul &amp; Deskripsi</th>
          <th>Teks Tombol</th>
          <th>Tautan (Link)</th>
          <th>Status</th>
          <th style="text-align: right;">Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php if (!empty($banners)): ?>
          <?php foreach ($banners as $b): ?>
            <tr>
              <td style="font-weight: 700; width: 50px; text-align: center;"><?= $b['sort_order'] ?></td>
              <td style="width: 140px;">
                <img src="../../<?= htmlspecialchars(!empty($b['image']) ? $b['image'] : 'assets/images/placeholder.svg') ?>" 
                     alt="<?= htmlspecialchars($b['title']) ?>" 
                     style="width: 130px; height: 50px; object-fit: cover; border-radius: 6px; border: 1px solid #dee2e6;">
              </td>
              <td>
                <div style="font-weight: 700; color: #1e293b;"><?= htmlspecialchars($b['title']) ?></div>
                <div style="font-size: 11.5px; color: #64748b; max-width: 280px;"><?= htmlspecialchars($b['description'] ?? '-') ?></div>
              </td>
              <td style="font-size: 12.5px;"><?= htmlspecialchars($b['button_text'] ?? '-') ?></td>
              <td><code style="font-size: 12px; color: #0f172a;"><?= htmlspecialchars($b['button_link'] ?? '-') ?></code></td>
              <td>
                <?php if ($b['status'] == 1): ?>
                  <span class="status-badge badge-active">Aktif</span>
                <?php else: ?>
                  <span class="status-badge badge-inactive">Nonaktif</span>
                <?php endif; ?>
              </td>
              <td style="text-align: right; white-space: nowrap;">
                <a href="edit.php?id=<?= $b['id'] ?>" class="btn btn-primary btn-sm">Edit</a>
                <a href="delete.php?id=<?= $b['id'] ?>&csrf_token=<?= generateCsrfToken() ?>" 
                   class="btn btn-danger btn-sm" 
                   data-confirm="Apakah Anda yakin ingin menghapus banner ini?">
                  Hapus
                </a>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php else: ?>
          <tr><td colspan="7" style="text-align: center; color: #64748b; padding: 24px;">Belum ada banner promosi.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
