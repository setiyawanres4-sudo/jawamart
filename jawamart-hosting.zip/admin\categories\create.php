<?php
/**
 * JAWA MART - Tambah Kategori Baru
 * File: admin/categories/create.php
 */

declare(strict_types=1);

$adminTitle = 'Tambah Kategori Sembako';
require_once __DIR__ . '/../includes/header.php';

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['csrf_token'] ?? '';
    if (!verifyCsrfToken($token)) {
        $errors[] = 'Sesi form Anda telah kedaluwarsa. Silakan muat ulang halaman.';
    } else {
        $name        = trim($_POST['name'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $status      = isset($_POST['status']) ? 1 : 0;

        if (empty($name)) {
            $errors[] = 'Nama kategori wajib diisi.';
        }

        // Slug
        $baseSlug = slugify($name);
        $slug = $baseSlug;
        $counter = 1;
        while (true) {
            $checkSlug = $pdo->prepare("SELECT id FROM categories WHERE slug = :s LIMIT 1");
            $checkSlug->execute(['s' => $slug]);
            if (!$checkSlug->fetch()) break;
            $slug = $baseSlug . '-' . (++$counter);
        }

        // Upload Icon/Foto Kategori
        $imagePath = 'assets/images/placeholder.svg';
        if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
            $uploadRes = uploadImage($_FILES['image'], 'categories', 'cat');
            if ($uploadRes['success']) {
                $imagePath = $uploadRes['path'];
            } else {
                $errors[] = $uploadRes['message'];
            }
        }

        if (empty($errors)) {
            try {
                $stmt = $pdo->prepare("
                    INSERT INTO categories (name, slug, description, image, status, created_at, updated_at) 
                    VALUES (:name, :slug, :description, :image, :status, NOW(), NOW())
                ");
                $stmt->execute([
                    'name'        => $name,
                    'slug'        => $slug,
                    'description' => $description,
                    'image'       => $imagePath,
                    'status'      => $status
                ]);

                setFlash('success', 'Kategori "' . $name . '" berhasil ditambahkan!');
                header('Location: index.php');
                exit;
            } catch (Exception $e) {
                error_log("Error creating category: " . $e->getMessage());
                $errors[] = 'Gagal menyimpan kategori ke database: ' . $e->getMessage();
            }
        }
    }
}
?>

<div class="page-header">
  <div>
    <h1 class="page-title">Tambah Kategori Sembako Baru</h1>
    <p class="page-subtitle">Buat kelompok kategori baru untuk katalog produk</p>
  </div>
  <a href="index.php" class="btn btn-secondary">&larr; Kembali ke Daftar Kategori</a>
</div>

<?php if (!empty($errors)): ?>
  <div class="flash-alert danger">
    <div>
      <strong>Terjadi kesalahan:</strong>
      <ul style="margin-left: 20px; margin-top: 4px;">
        <?php foreach ($errors as $err): ?>
          <li><?= htmlspecialchars($err) ?></li>
        <?php endforeach; ?>
      </ul>
    </div>
  </div>
<?php endif; ?>

<div class="admin-card">
  <div class="admin-card-body">
    <form action="create.php" method="POST" enctype="multipart/form-data">
      <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">

      <div class="form-group">
        <label class="form-label" for="name">Nama Kategori <span style="color:red;">*</span></label>
        <input type="text" name="name" id="name" class="form-control" placeholder="Contoh: Aneka Bumbu Dapur &amp; Rempah" required value="<?= htmlspecialchars($_POST['name'] ?? '') ?>">
      </div>

      <div class="form-group">
        <label class="form-label" for="description">Deskripsi Kategori</label>
        <textarea name="description" id="description" class="form-control" rows="3" placeholder="Penjelasan singkat mengenai kategori sembako ini..."><?= htmlspecialchars($_POST['description'] ?? '') ?></textarea>
      </div>

      <div class="form-group">
        <label class="form-label" for="image">Ikon / Foto Kategori (JPG/PNG/WebP/SVG, Maks 2MB)</label>
        <input type="file" name="image" id="image" class="form-control" accept="image/*" data-preview="catImgPreview">
        <div class="img-preview-box">
          <img id="catImgPreview" src="../../assets/images/placeholder.svg" alt="Preview Gambar">
        </div>
      </div>

      <div style="margin: 20px 0;">
        <label style="display: flex; align-items: center; gap: 8px; cursor: pointer; font-weight: 600;">
          <input type="checkbox" name="status" value="1" <?= (!isset($_POST['status']) || $_POST['status'] == '1') ? 'checked' : '' ?>>
          <span>Status Aktif (Ditampilkan di Website)</span>
        </label>
      </div>

      <div style="display: flex; gap: 12px; margin-top: 24px;">
        <button type="submit" class="btn btn-primary" style="padding: 10px 24px;">Simpan Kategori</button>
        <a href="index.php" class="btn btn-secondary">Batal</a>
      </div>
    </form>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
