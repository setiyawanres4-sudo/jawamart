<?php
/**
 * JAWA MART - Hapus Kategori Sembako
 * File: admin/categories/delete.php
 */

declare(strict_types=1);

require_once __DIR__ . '/../../includes/auth.php';
requireAdminAuth();

$id    = (int)($_GET['id'] ?? 0);
$token = $_GET['csrf_token'] ?? '';

if (!verifyCsrfToken($token)) {
    setFlash('danger', 'Token keamanan tidak valid atau telah kedaluwarsa.');
    header('Location: index.php');
    exit;
}

if ($id <= 0) {
    setFlash('danger', 'ID kategori tidak valid.');
    header('Location: index.php');
    exit;
}

try {
    // ATURAN PRD 8.4: Kategori yang masih memiliki produk aktif tidak boleh dihapus sembarangan!
    $stmtCheck = $pdo->prepare("SELECT COUNT(*) FROM products WHERE category_id = :cid AND deleted_at IS NULL");
    $stmtCheck->execute(['cid' => $id]);
    $activeProductCount = (int)$stmtCheck->fetchColumn();

    if ($activeProductCount > 0) {
        setFlash('warning', 'Kategori ini tidak dapat dihapus karena masih menampung ' . $activeProductCount . ' produk sembako aktif. Silakan pindahkan atau hapus produk terlebih dahulu, atau nonaktifkan status kategori.');
        header('Location: index.php');
        exit;
    }

    // Jika tidak ada produk, aman dihapus
    $stmtDel = $pdo->prepare("DELETE FROM categories WHERE id = :id");
    $stmtDel->execute(['id' => $id]);

    if ($stmtDel->rowCount() > 0) {
        setFlash('success', 'Kategori berhasil dihapus.');
    } else {
        setFlash('warning', 'Kategori tidak ditemukan.');
    }
} catch (Exception $e) {
    error_log("Error deleting category: " . $e->getMessage());
    setFlash('danger', 'Gagal menghapus kategori: ' . $e->getMessage());
}

header('Location: index.php');
exit;
