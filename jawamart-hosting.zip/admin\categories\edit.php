<?php
/**
 * JAWA MART - Edit Kategori Sembako
 * File: admin/categories/edit.php
 */

declare(strict_types=1);

$adminTitle = 'Edit Kategori Sembako';
require_once __DIR__ . '/../includes/header.php';

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    header('Location: index.php');
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM categories WHERE id = :id LIMIT 1");
$stmt->execute(['id' => $id]);
$category = $stmt->fetch();

if (!$category) {
    setFlash('danger', 'Kategori tidak ditemukan.');
    header('Location: index.php');
    exit;
}

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['csrf_token'] ?? '';
    if (!verifyCsrfToken($token)) {
        $errors[] = 'Sesi form Anda telah kedaluwarsa. Silakan muat ulang halaman.';
    } else {
        $name        = trim($_POST['name'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $status      = isset($_POST['status']) ? 1 : 0;

        if (empty($name)) {
            $errors[] = 'Nama kategori wajib diisi.';
        }

        // Upload Icon/Foto Pengganti
        $newImagePath = null;
        if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
            $uploadRes = uploadImage($_FILES['image'], 'categories', 'cat');
            if ($uploadRes['success']) {
                $newImagePath = $uploadRes['path'];
            } else {
                $errors[] = $uploadRes['message'];
            }
        }

        if (empty($errors)) {
            try {
                $finalImagePath = $newImagePath ?? $category['image'];

                $stmtUp = $pdo->prepare("
                    UPDATE categories SET 
                        name = :name,
                        description = :description,
                        image = :image,
                        status = :status,
                        updated_at = NOW()
                    WHERE id = :id
                ");

                $stmtUp->execute([
                    'name'        => $name,
                    'description' => $description,
                    'image'       => $finalImagePath,
                    'status'      => $status,
                    'id'          => $id
                ]);

                setFlash('success', 'Kategori "' . $name . '" berhasil diperbarui!');
                header('Location: index.php');
                exit;
            } catch (Exception $e) {
                error_log("Error updating category: " . $e->getMessage());
                $errors[] = 'Gagal menyimpan perubahan kategori: ' . $e->getMessage();
            }
        }
    }
}
?>

<div class="page-header">
  <div>
    <h1 class="page-title">Edit Kategori: <?= htmlspecialchars($category['name']) ?></h1>
    <p class="page-subtitle">Perbarui nama, ikon gambar, deskripsi, dan status aktif kategori</p>
  </div>
  <a href="index.php" class="btn btn-secondary">&larr; Kembali ke Daftar Kategori</a>
</div>

<?php if (!empty($errors)): ?>
  <div class="flash-alert danger">
    <div>
      <strong>Terjadi kesalahan:</strong>
      <ul style="margin-left: 20px; margin-top: 4px;">
        <?php foreach ($errors as $err): ?>
          <li><?= htmlspecialchars($err) ?></li>
        <?php endforeach; ?>
      </ul>
    </div>
  </div>
<?php endif; ?>

<div class="admin-card">
  <div class="admin-card-body">
    <form action="edit.php?id=<?= $category['id'] ?>" method="POST" enctype="multipart/form-data">
      <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">

      <div class="form-group">
        <label class="form-label" for="name">Nama Kategori <span style="color:red;">*</span></label>
        <input type="text" name="name" id="name" class="form-control" required value="<?= htmlspecialchars($category['name']) ?>">
      </div>

      <div class="form-group">
        <label class="form-label" for="description">Deskripsi Kategori</label>
        <textarea name="description" id="description" class="form-control" rows="3"><?= htmlspecialchars($category['description'] ?? '') ?></textarea>
      </div>

      <div class="form-group">
        <label class="form-label" for="image">Ganti Ikon / Foto Kategori (Kosongkan jika tetap menggunakan foto lama)</label>
        <input type="file" name="image" id="image" class="form-control" accept="image/*" data-preview="catImgPreview">
        <div style="margin-top: 8px;">
          <div style="font-size: 11.5px; color: #64748b; margin-bottom: 4px;">Ikon Saat Ini / Preview:</div>
          <div class="img-preview-box">
            <img id="catImgPreview" src="../../<?= htmlspecialchars(!empty($category['image']) ? $category['image'] : 'assets/images/placeholder.svg') ?>" alt="Preview">
          </div>
        </div>
      </div>

      <div style="margin: 20px 0;">
        <label style="display: flex; align-items: center; gap: 8px; cursor: pointer; font-weight: 600;">
          <input type="checkbox" name="status" value="1" <?= $category['status'] ? 'checked' : '' ?>>
          <span>Status Aktif</span>
        </label>
      </div>

      <div style="display: flex; gap: 12px; margin-top: 24px;">
        <button type="submit" class="btn btn-primary" style="padding: 10px 24px;">Simpan Perubahan</button>
        <a href="index.php" class="btn btn-secondary">Batal</a>
      </div>
    </form>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
