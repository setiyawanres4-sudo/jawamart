<?php
/**
 * JAWA MART - Kelola Kategori Sembako
 * File: admin/categories/index.php
 */

declare(strict_types=1);

$adminTitle = 'Kelola Kategori Sembako';
require_once __DIR__ . '/../includes/header.php';

// Ambil seluruh kategori dan jumlah produk aktif
$categories = [];
try {
    $stmt = $pdo->query("
        SELECT c.*, 
               COUNT(CASE WHEN p.deleted_at IS NULL AND p.status = 1 THEN p.id END) AS active_products_count,
               COUNT(p.id) AS total_products_count
        FROM categories c
        LEFT JOIN products p ON p.category_id = c.id
        GROUP BY c.id
        ORDER BY c.name ASC
    ");
    $categories = $stmt->fetchAll();
} catch (Exception $e) {
    error_log("Error fetching categories: " . $e->getMessage());
}
?>

<div class="page-header">
  <div>
    <h1 class="page-title">Kelola Kategori Sembako</h1>
    <p class="page-subtitle">Atur pengelompokan produk sembako, foto kategori, slug, dan status aktif</p>
  </div>
  <a href="create.php" class="btn btn-primary">
    + Tambah Kategori Baru
  </a>
</div>

<div class="admin-card">
  <div class="table-responsive">
    <table class="admin-table">
      <thead>
        <tr>
          <th>Ikon/Foto</th>
          <th>Nama Kategori</th>
          <th>Slug URL</th>
          <th>Deskripsi Singkat</th>
          <th>Jumlah Produk Aktif</th>
          <th>Status</th>
          <th style="text-align: right;">Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php if (!empty($categories)): ?>
          <?php foreach ($categories as $c): ?>
            <tr>
              <td style="width: 50px;">
                <img src="../../<?= htmlspecialchars(!empty($c['image']) ? $c['image'] : 'assets/images/placeholder.svg') ?>" 
                     alt="<?= htmlspecialchars($c['name']) ?>" 
                     style="width: 44px; height: 44px; object-fit: contain; border-radius: 50%; background: #e8f5e9; padding: 4px;">
              </td>
              <td style="font-weight: 700; color: #1e293b;">
                <?= htmlspecialchars($c['name']) ?>
              </td>
              <td>
                <code style="background: #f1f5f9; padding: 2px 6px; border-radius: 4px; font-size: 12px; color: #0f172a;"><?= htmlspecialchars($c['slug']) ?></code>
              </td>
              <td style="color: #64748b; font-size: 13px; max-width: 250px;">
                <?= htmlspecialchars($c['description'] ?? '-') ?>
              </td>
              <td>
                <span style="font-weight: 700; color: #198754;"><?= (int)$c['active_products_count'] ?></span> produk
              </td>
              <td>
                <?php if ($c['status'] == 1): ?>
                  <span class="status-badge badge-active">Aktif</span>
                <?php else: ?>
                  <span class="status-badge badge-inactive">Nonaktif</span>
                <?php endif; ?>
              </td>
              <td style="text-align: right; white-space: nowrap;">
                <a href="../../products.php?category=<?= urlencode($c['slug']) ?>" target="_blank" class="btn btn-secondary btn-sm" title="Lihat di Web">
                  👁️
                </a>
                <a href="edit.php?id=<?= $c['id'] ?>" class="btn btn-primary btn-sm">
                  Edit
                </a>
                <a href="delete.php?id=<?= $c['id'] ?>&csrf_token=<?= generateCsrfToken() ?>" 
                   class="btn btn-danger btn-sm" 
                   data-confirm="Apakah Anda yakin ingin menghapus kategori '<?= htmlspecialchars(addslashes($c['name'])) ?>'?"
                   title="Hapus Kategori">
                  Hapus
                </a>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php else: ?>
          <tr>
            <td colspan="7" style="text-align: center; color: #64748b; padding: 24px;">
              Belum ada kategori yang ditambahkan.
            </td>
          </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
