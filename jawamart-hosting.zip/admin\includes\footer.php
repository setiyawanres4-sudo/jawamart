    </main>
  </div>
</div>

<script src="<?= getBaseUrl('assets/js/admin.js') ?>"></script>
</body>
</html>
