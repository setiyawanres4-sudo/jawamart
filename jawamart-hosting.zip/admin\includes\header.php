<?php
/**
 * JAWA MART - Admin Layout Header
 * File: admin/includes/header.php
 */

declare(strict_types=1);

require_once __DIR__ . '/../../includes/auth.php';

// Wajibkan login
requireAdminAuth();

$currentAdmin = getLoggedInAdmin();
$storeName    = getSetting('store_name', 'JAWA MART');
$adminTitle   = $adminTitle ?? 'Dashboard Administrator';

// Tentukan menu aktif
$currentUri = $_SERVER['REQUEST_URI'] ?? '';
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= htmlspecialchars($adminTitle) ?> | <?= htmlspecialchars($storeName) ?> Admin</title>
  <link rel="icon" type="image/svg+xml" href="<?= getBaseUrl('assets/images/favicon.svg') ?>">
  <link rel="stylesheet" href="<?= getBaseUrl('assets/css/admin.css') ?>">
</head>
<body>

<div class="admin-wrapper">
  
  <!-- Sidebar -->
  <aside class="admin-sidebar" id="adminSidebar">
    <div class="sidebar-header">
      <a href="<?= getAdminUrl('index.php') ?>" class="sidebar-brand" style="display: flex; align-items: center; justify-content: center; padding: 4px 0;">
        <img src="<?= getBaseUrl('assets/images/logo.png') ?>" alt="<?= htmlspecialchars($storeName) ?>" style="height: 38px; width: auto; object-fit: contain;">
      </a>
    </div>

    <ul class="sidebar-menu">
      <li class="menu-heading">Utama</li>
      <li class="menu-item <?= str_contains($currentUri, 'admin/index.php') || (str_ends_with($currentUri, '/admin/') || str_ends_with($currentUri, '/admin')) ? 'active' : '' ?>">
        <a href="<?= getAdminUrl('index.php') ?>">
          <span class="menu-icon">📊</span>
          <span>Dashboard Overview</span>
        </a>
      </li>

      <li class="menu-heading">Katalog &amp; Inventori</li>
      <li class="menu-item <?= str_contains($currentUri, 'admin/products') ? 'active' : '' ?>">
        <a href="<?= getAdminUrl('products/index.php') ?>">
          <span class="menu-icon">📦</span>
          <span>Kelola Produk</span>
        </a>
      </li>
      <li class="menu-item <?= str_contains($currentUri, 'admin/categories') ? 'active' : '' ?>">
        <a href="<?= getAdminUrl('categories/index.php') ?>">
          <span class="menu-icon">🏷️</span>
          <span>Kategori Sembako</span>
        </a>
      </li>
      <li class="menu-item <?= str_contains($currentUri, 'admin/stock') ? 'active' : '' ?>">
        <a href="<?= getAdminUrl('stock/index.php') ?>">
          <span class="menu-icon">📈</span>
          <span>Manajemen Stok</span>
        </a>
      </li>

      <li class="menu-heading">Transaksi &amp; Analisis</li>
      <li class="menu-item <?= str_contains($currentUri, 'admin/orders') ? 'active' : '' ?>">
        <a href="<?= getAdminUrl('orders/index.php') ?>">
          <span class="menu-icon">🛒</span>
          <span>Pesanan Toko</span>
        </a>
      </li>
      <li class="menu-item <?= str_contains($currentUri, 'admin/reports') ? 'active' : '' ?>">
        <a href="<?= getAdminUrl('reports/index.php') ?>">
          <span class="menu-icon">📑</span>
          <span>Laporan Penjualan</span>
        </a>
      </li>

      <li class="menu-heading">Tampilan &amp; Konfigurasi</li>
      <li class="menu-item <?= str_contains($currentUri, 'admin/banners') ? 'active' : '' ?>">
        <a href="<?= getAdminUrl('banners/index.php') ?>">
          <span class="menu-icon">🖼️</span>
          <span>Banner Promosi</span>
        </a>
      </li>
      <li class="menu-item <?= str_contains($currentUri, 'admin/settings') ? 'active' : '' ?>">
        <a href="<?= getAdminUrl('settings/index.php') ?>">
          <span class="menu-icon">⚙️</span>
          <span>Pengaturan Toko</span>
        </a>
      </li>

      <li class="menu-heading">Sesi</li>
      <li class="menu-item">
        <a href="<?= getBaseUrl('index.php') ?>" target="_blank" rel="noopener">
          <span class="menu-icon">🌐</span>
          <span>Lihat Website Toko &nearr;</span>
        </a>
      </li>
      <li class="menu-item">
        <a href="<?= getAdminUrl('logout.php') ?>" data-confirm="Apakah Anda yakin ingin logout dari sistem?">
          <span class="menu-icon">🚪</span>
          <span style="color: #f87171;">Logout</span>
        </a>
      </li>
    </ul>

    <div class="sidebar-footer">
      <div>JAWA MART v2.0</div>
      <small style="color: #64748b;">Panel Toko Sembako</small>
    </div>
  </aside>

  <!-- Main Content Wrapper -->
  <div class="admin-main">
    
    <!-- Top Navbar -->
    <header class="admin-navbar">
      <div class="navbar-left">
        <button type="button" class="sidebar-toggle-btn" aria-label="Toggle Sidebar">
          ☰
        </button>
        <div style="font-weight: 700; font-size: 15px; color: #334155;">
          <?= htmlspecialchars($adminTitle) ?>
        </div>
      </div>

      <div class="navbar-right">
        <a href="<?= getBaseUrl('index.php') ?>" target="_blank" class="btn btn-secondary btn-sm" style="font-size: 12.5px;">
          <span>Lihat Website &nearr;</span>
        </a>

        <div class="user-badge">
          <div class="user-avatar">
            <?= strtoupper(substr($currentAdmin['name'] ?? 'A', 0, 1)) ?>
          </div>
          <div class="user-info">
            <div class="user-name"><?= htmlspecialchars($currentAdmin['name'] ?? 'Admin') ?></div>
            <div class="user-role"><?= htmlspecialchars(ucfirst($currentAdmin['role'] ?? 'admin')) ?></div>
          </div>
        </div>
      </div>
    </header>

    <!-- Admin Body Content Container -->
    <main class="admin-content">

      <!-- Flash Message Notification -->
      <?php $flash = getFlash(); ?>
      <?php if ($flash): ?>
        <div class="flash-alert <?= htmlspecialchars($flash['type']) ?>" style="margin-bottom: 20px;">
          <span><?= htmlspecialchars($flash['message']) ?></span>
          <button type="button" onclick="this.parentElement.remove()" style="background:none; border:none; cursor:pointer; font-size:16px;">&times;</button>
        </div>
      <?php endif; ?>
