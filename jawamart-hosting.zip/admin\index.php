<?php
/**
 * JAWA MART - Admin Dashboard Overview
 * File: admin/index.php
 */

declare(strict_types=1);

$adminTitle = 'Dashboard Overview';
require_once __DIR__ . '/includes/header.php';

// 1. Statistik Utama
$stats = [
    'total_products'    => 0,
    'total_categories'  => 0,
    'total_orders'      => 0,
    'orders_new'        => 0,
    'orders_processing' => 0,
    'orders_completed'  => 0,
    'total_revenue'     => 0.0,
    'low_stock_count'   => 0,
    'out_of_stock_count'=> 0
];

try {
    // Total Produk Aktif
    $stmt = $pdo->query("SELECT COUNT(*) FROM products WHERE status = 1 AND deleted_at IS NULL");
    $stats['total_products'] = (int)$stmt->fetchColumn();

    // Total Kategori
    $stmt = $pdo->query("SELECT COUNT(*) FROM categories WHERE status = 1");
    $stats['total_categories'] = (int)$stmt->fetchColumn();

    // Total Pesanan Keseluruhan
    $stmt = $pdo->query("SELECT COUNT(*) FROM orders");
    $stats['total_orders'] = (int)$stmt->fetchColumn();

    // Pesanan Baru (Menunggu Konfirmasi)
    $stmt = $pdo->query("SELECT COUNT(*) FROM orders WHERE status = 'Menunggu Konfirmasi'");
    $stats['orders_new'] = (int)$stmt->fetchColumn();

    // Pesanan Diproses / Dalam Pengiriman
    $stmt = $pdo->query("SELECT COUNT(*) FROM orders WHERE status IN ('Dikonfirmasi', 'Diproses', 'Dalam Pengiriman')");
    $stats['orders_processing'] = (int)$stmt->fetchColumn();

    // Pesanan Selesai
    $stmt = $pdo->query("SELECT COUNT(*) FROM orders WHERE status = 'Selesai'");
    $stats['orders_completed'] = (int)$stmt->fetchColumn();

    // Total Omzet (Hanya dari pesanan Selesai, PRD 8.2 & 9.1)
    $stmt = $pdo->query("SELECT COALESCE(SUM(total), 0) FROM orders WHERE status = 'Selesai'");
    $stats['total_revenue'] = (float)$stmt->fetchColumn();

    // Stok Menipis (stok > 0 dan stok <= minimum_stock)
    $stmt = $pdo->query("SELECT COUNT(*) FROM products WHERE stock > 0 AND stock <= minimum_stock AND status = 1 AND deleted_at IS NULL");
    $stats['low_stock_count'] = (int)$stmt->fetchColumn();

    // Stok Habis (stok <= 0)
    $stmt = $pdo->query("SELECT COUNT(*) FROM products WHERE stock <= 0 AND status = 1 AND deleted_at IS NULL");
    $stats['out_of_stock_count'] = (int)$stmt->fetchColumn();
} catch (Exception $e) {
    error_log("Error retrieving dashboard stats: " . $e->getMessage());
}

// 2. Data Grafik Penjualan 7 Hari Terakhir
$chartLabels = [];
$chartValues = [];

try {
    $stmtChart = $pdo->query("
        SELECT DATE_FORMAT(created_at, '%d/%m') as tgl, 
               COALESCE(SUM(total), 0) as omzet 
        FROM orders 
        WHERE status = 'Selesai' AND created_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
        GROUP BY DATE(created_at)
        ORDER BY created_at ASC
    ");
    $chartRows = $stmtChart->fetchAll();
    
    // Siapkan 7 hari default
    for ($i = 6; $i >= 0; $i--) {
        $d = date('d/m', strtotime("-$i days"));
        $chartLabels[] = $d;
        $found = 0;
        foreach ($chartRows as $cr) {
            if ($cr['tgl'] === $d) {
                $found = (float)$cr['omzet'];
                break;
            }
        }
        $chartValues[] = $found;
    }
} catch (Exception $e) {
    //
}

// 3. Pesanan Terbaru
$recentOrders = [];
try {
    $stmtRecent = $pdo->query("
        SELECT id, order_code, customer_name, customer_phone, total, status, created_at 
        FROM orders 
        ORDER BY id DESC 
        LIMIT 6
    ");
    $recentOrders = $stmtRecent->fetchAll();
} catch (Exception $e) {
    //
}

// 4. Produk Stok Menipis & Habis
$lowStockProducts = [];
try {
    $stmtLow = $pdo->query("
        SELECT id, name, sku, stock, minimum_stock, unit 
        FROM products 
        WHERE stock <= minimum_stock AND status = 1 AND deleted_at IS NULL 
        ORDER BY stock ASC 
        LIMIT 6
    ");
    $lowStockProducts = $stmtLow->fetchAll();
} catch (Exception $e) {
    //
}
?>

<!-- Statistic Metric Cards -->
<div class="stats-grid">
  <!-- Omzet Selesai -->
  <div class="stat-card">
    <div class="stat-card-info">
      <p>Omzet Selesai</p>
      <h3 style="color: #198754; font-size: 20px;"><?= formatRupiah($stats['total_revenue']) ?></h3>
      <small style="color: #64748b; font-size: 11px;">Dari pesanan sukses</small>
    </div>
    <div class="stat-card-icon stat-icon-green">💰</div>
  </div>

  <!-- Pesanan Baru -->
  <div class="stat-card">
    <div class="stat-card-info">
      <p>Pesanan Baru</p>
      <h3><?= $stats['orders_new'] ?></h3>
      <small style="color: #856404; font-size: 11px;">Menunggu konfirmasi</small>
    </div>
    <div class="stat-card-icon stat-icon-yellow">🔔</div>
  </div>

  <!-- Pesanan Diproses -->
  <div class="stat-card">
    <div class="stat-card-info">
      <p>Sedang Diproses</p>
      <h3><?= $stats['orders_processing'] ?></h3>
      <small style="color: #084298; font-size: 11px;">Dalam pengiriman/kemas</small>
    </div>
    <div class="stat-card-icon stat-icon-blue">🚚</div>
  </div>

  <!-- Total Produk -->
  <div class="stat-card">
    <div class="stat-card-info">
      <p>Katalog Produk</p>
      <h3><?= $stats['total_products'] ?></h3>
      <small style="color: #64748b; font-size: 11px;"><?= $stats['total_categories'] ?> kategori sembako</small>
    </div>
    <div class="stat-card-icon stat-icon-purple">📦</div>
  </div>
</div>

<!-- Grid Chart & Stock Alerts -->
<div style="display: grid; grid-template-columns: 2fr 1fr; gap: 24px; margin-bottom: 24px;">
  
  <!-- Sales Chart -->
  <div class="admin-card">
    <div class="admin-card-header">
      <h3 class="admin-card-title">Grafik Penjualan 7 Hari Terakhir</h3>
      <a href="reports/index.php" class="btn btn-secondary btn-sm">Lihat Detail Laporan &rarr;</a>
    </div>
    <div class="admin-card-body">
      <canvas id="salesChartCanvas" style="width: 100%; height: 260px;"></canvas>
    </div>
  </div>

  <!-- Stock Alert Card -->
  <div class="admin-card">
    <div class="admin-card-header">
      <h3 class="admin-card-title">Peringatan Stok</h3>
      <a href="stock/index.php" class="btn btn-secondary btn-sm">Kelola Stok &rarr;</a>
    </div>
    <div class="admin-card-body" style="padding: 12px 16px;">
      <?php if (!empty($lowStockProducts)): ?>
        <ul style="list-style: none; display: flex; flex-direction: column; gap: 10px;">
          <?php foreach ($lowStockProducts as $lp): ?>
            <li style="display: flex; justify-content: space-between; align-items: center; padding-bottom: 8px; border-bottom: 1px solid #f1f5f9;">
              <div>
                <div style="font-weight: 700; font-size: 13px; color: #1e293b;"><?= htmlspecialchars($lp['name']) ?></div>
                <div style="font-size: 11px; color: #64748b;">SKU: <?= htmlspecialchars($lp['sku']) ?></div>
              </div>
              <div>
                <?php if ($lp['stock'] <= 0): ?>
                  <span class="status-badge badge-dibatalkan">Habis (0)</span>
                <?php else: ?>
                  <span class="status-badge badge-menunggu-konfirmasi">Sisa <?= $lp['stock'] ?> <?= htmlspecialchars($lp['unit']) ?></span>
                <?php endif; ?>
              </div>
            </li>
          <?php endforeach; ?>
        </ul>
      <?php else: ?>
        <div style="text-align: center; color: #198754; padding: 24px 10px; font-weight: 600;">
          ✓ Semua stok produk berada dalam batas aman!
        </div>
      <?php endif; ?>
    </div>
  </div>

</div>

<!-- Recent Orders Table -->
<div class="admin-card">
  <div class="admin-card-header">
    <h3 class="admin-card-title">Pesanan Pelanggan Terbaru</h3>
    <a href="orders/index.php" class="btn btn-primary btn-sm">Semua Pesanan (<?= $stats['total_orders'] ?>) &rarr;</a>
  </div>

  <div class="table-responsive">
    <table class="admin-table">
      <thead>
        <tr>
          <th>Kode Pesanan</th>
          <th>Nama Pelanggan</th>
          <th>Nomor WhatsApp</th>
          <th>Total</th>
          <th>Status</th>
          <th>Waktu Masuk</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php if (!empty($recentOrders)): ?>
          <?php foreach ($recentOrders as $ro): ?>
            <?php 
              $statusClass = 'badge-menunggu-konfirmasi';
              if ($ro['status'] === 'Dikonfirmasi') $statusClass = 'badge-dikonfirmasi';
              elseif ($ro['status'] === 'Diproses') $statusClass = 'badge-diproses';
              elseif ($ro['status'] === 'Dalam Pengiriman') $statusClass = 'badge-dalam-pengiriman';
              elseif ($ro['status'] === 'Selesai') $statusClass = 'badge-selesai';
              elseif ($ro['status'] === 'Dibatalkan') $statusClass = 'badge-dibatalkan';
            ?>
            <tr>
              <td>
                <a href="orders/detail.php?id=<?= $ro['id'] ?>" style="font-weight: 800; color: #198754;">
                  <?= htmlspecialchars($ro['order_code']) ?>
                </a>
              </td>
              <td style="font-weight: 600;"><?= htmlspecialchars($ro['customer_name']) ?></td>
              <td>
                <a href="https://wa.me/<?= cleanPhoneForWhatsApp($ro['customer_phone']) ?>" target="_blank" style="color: #25d366; font-weight: 600;">
                  <?= htmlspecialchars($ro['customer_phone']) ?>
                </a>
              </td>
              <td style="font-weight: 700; color: #198754;"><?= formatRupiah($ro['total']) ?></td>
              <td>
                <span class="status-badge <?= $statusClass ?>"><?= htmlspecialchars($ro['status']) ?></span>
              </td>
              <td style="color: #64748b; font-size: 12px;"><?= formatDate($ro['created_at']) ?></td>
              <td>
                <a href="orders/detail.php?id=<?= $ro['id'] ?>" class="btn btn-secondary btn-sm">
                  Rincian &rarr;
                </a>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php else: ?>
          <tr>
            <td colspan="7" style="text-align: center; color: #64748b; padding: 24px;">
              Belum ada data transaksi pesanan.
            </td>
          </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<script>
window.salesChartData = {
  labels: <?= json_encode($chartLabels) ?>,
  values: <?= json_encode($chartValues) ?>
};
</script>

<style>
@media (max-width: 900px) {
  div[style*="grid-template-columns: 2fr 1fr"] {
    grid-template-columns: 1fr !important;
  }
}
</style>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
