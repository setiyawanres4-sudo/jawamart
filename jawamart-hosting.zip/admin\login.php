<?php
/**
 * JAWA MART - Login Administrator
 * File: admin/login.php
 */

declare(strict_types=1);

require_once __DIR__ . '/../includes/auth.php';

// Jika sudah login, redirect langsung ke dashboard
if (isAdminLoggedIn()) {
    header('Location: index.php');
    exit;
}

$error = null;
$storeName = getSetting('store_name', 'JAWA MART');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['csrf_token'] ?? '';
    if (!verifyCsrfToken($token)) {
        $error = 'Sesi form Anda telah kedaluwarsa. Silakan muat ulang halaman.';
    } else {
        $username = trim($_POST['username'] ?? '');
        $password = trim($_POST['password'] ?? '');

        if (empty($username) || empty($password)) {
            $error = 'Silakan masukkan username dan password.';
        } else {
            $loginResult = adminLogin($username, $password);
            if ($loginResult['success']) {
                $redirect = $_SESSION['redirect_after_login'] ?? 'index.php';
                unset($_SESSION['redirect_after_login']);
                header('Location: ' . $redirect);
                exit;
            } else {
                $error = $loginResult['message'];
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login Administrator | <?= htmlspecialchars($storeName) ?></title>
  <link rel="icon" type="image/svg+xml" href="../assets/images/favicon.svg">
  <link rel="stylesheet" href="../assets/css/admin.css">
  <style>
    body {
      background-color: #0f172a;
      display: flex;
      align-items: center;
      justify-content: center;
      min-height: 100vh;
      padding: 20px;
    }
    .login-card {
      background: #ffffff;
      border-radius: 12px;
      box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.3);
      width: 100%;
      max-width: 420px;
      overflow: hidden;
    }
    .login-header {
      background: #198754;
      color: #ffffff;
      padding: 28px 24px;
      text-align: center;
    }
    .login-body {
      padding: 30px 24px;
    }
  </style>
</head>
<body>

  <div class="login-card">
    <div class="login-header">
      <img src="../assets/images/logo.png" alt="<?= htmlspecialchars($storeName) ?>" style="height: 52px; margin: 0 auto 10px; object-fit: contain;">
      <h2 style="font-size: 19px; font-weight: 800;">Dashboard Administrator</h2>
      <p style="font-size: 12.5px; opacity: 0.9; margin-top: 4px;">Kelola Produk, Stok, Pesanan &amp; Laporan</p>
    </div>

    <div class="login-body">
      <?php if (!empty($error)): ?>
        <div style="background: #f8d7da; color: #842029; padding: 12px; border-radius: 6px; font-size: 13.5px; margin-bottom: 20px; font-weight: 600;">
          ⚠️ <?= htmlspecialchars($error) ?>
        </div>
      <?php endif; ?>

      <form action="login.php" method="POST">
        <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">

        <div class="form-group">
          <label class="form-label" for="username">Username atau Email</label>
          <input type="text" id="username" name="username" class="form-control" placeholder="admin" required autofocus value="<?= htmlspecialchars($_POST['username'] ?? '') ?>">
        </div>

        <div class="form-group">
          <label class="form-label" for="password">Password</label>
          <input type="password" id="password" name="password" class="form-control" placeholder="••••••••" required>
        </div>

        <div style="margin-bottom: 20px; font-size: 12.5px; color: #64748b; background: #f8fafc; padding: 10px; border-radius: 6px; border: 1px dashed #cbd5e1;">
          💡 Akun default awal:<br>
          Username: <strong>admin</strong> &nbsp;|&nbsp; Password: <strong>admin123</strong>
        </div>

        <button type="submit" class="btn btn-primary" style="width: 100%; padding: 11px; font-size: 14.5px;">
          Masuk ke Dashboard
        </button>
      </form>

      <div style="text-align: center; margin-top: 20px;">
        <a href="../index.php" style="font-size: 13px; color: #64748b; text-decoration: none;">
          &larr; Kembali ke Website Toko
        </a>
      </div>
    </div>
  </div>

</body>
</html>
