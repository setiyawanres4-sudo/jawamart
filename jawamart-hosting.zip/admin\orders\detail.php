<?php
/**
 * JAWA MART - Detail & Kelola Pesanan
 * File: admin/orders/detail.php
 */

declare(strict_types=1);

$adminTitle = 'Detail Pesanan Pelanggan';
require_once __DIR__ . '/../includes/header.php';

$id   = (int)($_GET['id'] ?? 0);
$code = trim($_GET['code'] ?? '');

$order = null;
if ($id > 0) {
    $stmt = $pdo->prepare("SELECT * FROM orders WHERE id = :id LIMIT 1");
    $stmt->execute(['id' => $id]);
    $order = $stmt->fetch();
} elseif (!empty($code)) {
    $stmt = $pdo->prepare("SELECT * FROM orders WHERE order_code = :c LIMIT 1");
    $stmt->execute(['c' => $code]);
    $order = $stmt->fetch();
}

if (!$order) {
    setFlash('danger', 'Pesanan tidak ditemukan.');
    header('Location: index.php');
    exit;
}

// Ambil Order Items (Snapshot)
$items = [];
try {
    $stmtItems = $pdo->prepare("SELECT * FROM order_items WHERE order_id = :oid ORDER BY id ASC");
    $stmtItems->execute(['oid' => $order['id']]);
    $items = $stmtItems->fetchAll();
} catch (Exception $e) {}

// Ambil Riwayat Perubahan Status (PRD Section 8.7)
$history = [];
try {
    $stmtHist = $pdo->prepare("
        SELECT osh.*, COALESCE(a.name, 'Sistem / Pelanggan') as admin_name 
        FROM order_status_history osh 
        LEFT JOIN admins a ON a.id = osh.admin_id 
        WHERE osh.order_id = :oid 
        ORDER BY osh.id DESC
    ");
    $stmtHist->execute(['oid' => $order['id']]);
    $history = $stmtHist->fetchAll();
} catch (Exception $e) {}

$statusList = [
    'Menunggu Konfirmasi',
    'Dikonfirmasi',
    'Diproses',
    'Dalam Pengiriman',
    'Selesai',
    'Dibatalkan'
];

$cleanCustPhone = cleanPhoneForWhatsApp($order['customer_phone']);
$waChatUrl = "https://wa.me/{$cleanCustPhone}?text=" . rawurlencode("Halo {$order['customer_name']}, kami dari JAWA MART mengonfirmasi pesanan Anda dengan Kode: {$order['order_code']}.");
?>

<div class="page-header">
  <div>
    <h1 class="page-title">Pesanan: <?= htmlspecialchars($order['order_code']) ?></h1>
    <p class="page-subtitle">Dibuat pada <?= formatDate($order['created_at']) ?></p>
  </div>
  <div style="display: flex; gap: 10px;">
    <a href="print.php?id=<?= $order['id'] ?>" target="_blank" class="btn btn-secondary">
      🖨️ Cetak Nota Pesanan
    </a>
    <a href="index.php" class="btn btn-secondary">
      &larr; Kembali ke Daftar Pesanan
    </a>
  </div>
</div>

<div style="display: grid; grid-template-columns: 2fr 1fr; gap: 24px; align-items: start;">
  
  <!-- Left Column: Customer Info & Items List -->
  <div>
    
    <!-- Customer Info Card -->
    <div class="admin-card">
      <div class="admin-card-header">
        <h3 class="admin-card-title">Informasi Pelanggan &amp; Pengiriman</h3>
        <a href="<?= $waChatUrl ?>" target="_blank" rel="noopener" class="btn btn-success btn-sm">
          💬 Chat WhatsApp Pelanggan
        </a>
      </div>
      <div class="admin-card-body">
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; font-size: 13.5px;">
          <div>
            <div style="color: #64748b; font-size: 12px;">Nama Pembeli:</div>
            <strong style="font-size: 15px; color: #1e293b;"><?= htmlspecialchars($order['customer_name']) ?></strong>
          </div>
          <div>
            <div style="color: #64748b; font-size: 12px;">WhatsApp Pelanggan:</div>
            <strong style="color: #25d366; font-size: 14.5px;"><?= htmlspecialchars($order['customer_phone']) ?></strong>
          </div>
          <div style="grid-column: 1 / -1;">
            <div style="color: #64748b; font-size: 12px;">Alamat Pengiriman:</div>
            <div style="color: #334155; line-height: 1.5; margin-top: 3px; font-weight: 500; background: #f8fafc; padding: 10px 14px; border-radius: 6px; border: 1px solid #e2e8f0;">
              <?= nl2br(htmlspecialchars($order['customer_address'])) ?>
            </div>
          </div>
          <?php if (!empty($order['customer_note'])): ?>
            <div style="grid-column: 1 / -1;">
              <div style="color: #64748b; font-size: 12px;">Catatan Pelanggan:</div>
              <div style="color: #856404; background: #fff3cd; padding: 8px 12px; border-radius: 6px; font-size: 13px; margin-top: 3px;">
                <?= htmlspecialchars($order['customer_note']) ?>
              </div>
            </div>
          <?php endif; ?>
        </div>
      </div>
    </div>

    <!-- Order Items Snapshot Table (PRD Section 10.8) -->
    <div class="admin-card">
      <div class="admin-card-header">
        <h3 class="admin-card-title">Daftar Barang Pesanan (Snapshot Data)</h3>
        <span style="font-size: 12px; color: #64748b;">Harga dan detail tersimpan tetap aman meski produk diedit</span>
      </div>
      <div class="table-responsive">
        <table class="admin-table">
          <thead>
            <tr>
              <th>Foto</th>
              <th>Nama Produk &amp; SKU</th>
              <th>Harga Satuan</th>
              <th>Jumlah</th>
              <th style="text-align: right;">Subtotal</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($items as $item): ?>
              <tr>
                <td style="width: 44px;">
                  <img src="../../<?= htmlspecialchars(!empty($item['product_image']) ? $item['product_image'] : 'assets/images/placeholder.svg') ?>" 
                       alt="<?= htmlspecialchars($item['product_name']) ?>" 
                       style="width: 40px; height: 40px; object-fit: contain; border-radius: 6px; background: #fff; border: 1px solid #e2e8f0; padding: 2px;">
                </td>
                <td>
                  <div style="font-weight: 700; color: #1e293b;"><?= htmlspecialchars($item['product_name']) ?></div>
                  <div style="font-size: 11px; color: #64748b;">SKU: <?= htmlspecialchars($item['product_sku']) ?></div>
                </td>
                <td><?= formatRupiah($item['unit_price']) ?></td>
                <td>
                  <strong style="color: #198754;"><?= $item['quantity'] ?></strong> <?= htmlspecialchars($item['unit']) ?>
                </td>
                <td style="text-align: right; font-weight: 700; color: #1e293b;">
                  <?= formatRupiah($item['subtotal']) ?>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>

      <!-- Financial Totals -->
      <div style="padding: 16px 20px; background: #f8fafc; border-top: 1px solid var(--admin-border); font-size: 14px;">
        <div style="display: flex; justify-content: space-between; margin-bottom: 6px;">
          <span style="color: #64748b;">Subtotal Belanja:</span>
          <span style="font-weight: 600;"><?= formatRupiah($order['subtotal']) ?></span>
        </div>
        <div style="display: flex; justify-content: space-between; margin-bottom: 8px;">
          <span style="color: #64748b;">Biaya Pengiriman:</span>
          <span style="font-weight: 600;"><?= $order['shipping_cost'] > 0 ? formatRupiah($order['shipping_cost']) : 'GRATIS (Rp 0)' ?></span>
        </div>
        <div style="display: flex; justify-content: space-between; font-size: 18px; font-weight: 800; color: #198754; border-top: 1.5px dashed var(--admin-border); padding-top: 10px;">
          <span>Total Pembayaran:</span>
          <span><?= formatRupiah($order['total']) ?></span>
        </div>
      </div>
    </div>

  </div>

  <!-- Right Column: Status Update & Status History -->
  <div>
    
    <!-- Status Update Form -->
    <div class="admin-card">
      <div class="admin-card-header">
        <h3 class="admin-card-title">Perbarui Status Pesanan</h3>
      </div>
      <div class="admin-card-body">
        <div style="margin-bottom: 16px;">
          <div style="color: #64748b; font-size: 12px; margin-bottom: 4px;">Status Saat Ini:</div>
          <span class="status-badge" style="font-size: 13px; padding: 6px 14px; background: #e8f5e9; color: #0f5132; font-weight: 800;">
            <?= htmlspecialchars($order['status']) ?>
          </span>
          <div style="font-size: 11.5px; color: #64748b; margin-top: 6px;">
            Stok Barang: <strong><?= $order['stock_deducted'] ? 'Sudah Dikurangi dari Gudang' : 'Belum Dikurangi' ?></strong>
          </div>
        </div>

        <form action="update-status.php" method="POST">
          <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
          <input type="hidden" name="order_id" value="<?= $order['id'] ?>">

          <div class="form-group">
            <label class="form-label" for="new_status">Ubah Status Menjadi:</label>
            <select name="new_status" id="new_status" class="form-control" required>
              <?php foreach ($statusList as $st): ?>
                <option value="<?= $st ?>" <?= $order['status'] === $st ? 'selected' : '' ?>>
                  <?= $st ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>

          <div class="form-group">
            <label class="form-label" for="status_note">Catatan Perubahan (Opsional):</label>
            <textarea name="status_note" id="status_note" class="form-control" rows="2" placeholder="Contoh: Pesanan telah dikemas dan diserahkan ke kurir"></textarea>
          </div>

          <div style="font-size: 12px; color: #64748b; margin-bottom: 14px; background: #f8fafc; padding: 8px; border-radius: 6px;">
            ℹ️ <strong>Aturan Stok Atomik (PRD 5.5):</strong> Mengubah status ke Dikonfirmasi/Diproses otomatis mengurangi stok barang. Jika pesanan dibatalkan, stok otomatis dikembalikan ke gudang.
          </div>

          <button type="submit" class="btn btn-primary" style="width: 100%; padding: 10px;">
            Simpan Perubahan Status
          </button>
        </form>
      </div>
    </div>

    <!-- Status History Audit Trail (PRD Section 8.7) -->
    <div class="admin-card">
      <div class="admin-card-header">
        <h3 class="admin-card-title">Riwayat Status Pesanan</h3>
      </div>
      <div class="admin-card-body" style="padding: 14px 16px;">
        <?php if (!empty($history)): ?>
          <ul style="list-style: none; display: flex; flex-direction: column; gap: 14px; position: relative; padding-left: 12px; border-left: 2px solid #e2e8f0; margin-left: 8px;">
            <?php foreach ($history as $h): ?>
              <li style="position: relative;">
                <div style="position: absolute; left: -19px; top: 2px; width: 12px; height: 12px; border-radius: 50%; background: #198754; border: 2px solid #fff;"></div>
                <div style="font-size: 13px; font-weight: 700; color: #1e293b;">
                  <?= htmlspecialchars($h['new_status']) ?>
                </div>
                <?php if (!empty($h['old_status'])): ?>
                  <div style="font-size: 11px; color: #64748b;">Sebelumnya: <?= htmlspecialchars($h['old_status']) ?></div>
                <?php endif; ?>
                <?php if (!empty($h['note'])): ?>
                  <div style="font-size: 12px; color: #475569; margin-top: 2px; font-style: italic;">
                    "<?= htmlspecialchars($h['note']) ?>"
                  </div>
                <?php endif; ?>
                <div style="font-size: 11px; color: #94a3b8; margin-top: 2px;">
                  Oleh: <?= htmlspecialchars($h['admin_name']) ?> &bull; <?= formatDate($h['created_at']) ?>
                </div>
              </li>
            <?php endforeach; ?>
          </ul>
        <?php else: ?>
          <div style="color: #64748b; font-size: 13px;">Belum ada riwayat status.</div>
        <?php endif; ?>
      </div>
    </div>

  </div>

</div>

<style>
@media (max-width: 900px) {
  div[style*="grid-template-columns: 2fr 1fr"] {
    grid-template-columns: 1fr !important;
  }
}
</style>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
