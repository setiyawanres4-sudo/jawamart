<?php
/**
 * JAWA MART - Manajemen Pesanan Toko
 * File: admin/orders/index.php
 */

declare(strict_types=1);

$adminTitle = 'Kelola Pesanan Pelanggan';
require_once __DIR__ . '/../includes/header.php';

// Parameter Filter & Pagination
$q          = trim($_GET['q'] ?? '');
$status     = trim($_GET['status'] ?? '');
$startDate  = trim($_GET['start_date'] ?? '');
$endDate    = trim($_GET['end_date'] ?? '');
$page       = max(1, (int)($_GET['page'] ?? 1));
$perPage    = 15;
$offset     = ($page - 1) * $perPage;

$where = ["1=1"];
$params = [];

if (!empty($q)) {
    $where[] = "(order_code LIKE :q OR customer_name LIKE :q OR customer_phone LIKE :q)";
    $params['q'] = '%' . $q . '%';
}

if (!empty($status)) {
    $where[] = "status = :st";
    $params['st'] = $status;
}

if (!empty($startDate)) {
    $where[] = "DATE(created_at) >= :sdate";
    $params['sdate'] = $startDate;
}

if (!empty($endDate)) {
    $where[] = "DATE(created_at) <= :edate";
    $params['edate'] = $endDate;
}

$whereClause = "WHERE " . implode(" AND ", $where);

// Total Count
$stmtCount = $pdo->prepare("SELECT COUNT(*) FROM orders $whereClause");
$stmtCount->execute($params);
$totalOrders = (int)$stmtCount->fetchColumn();
$totalPages = max(1, (int)ceil($totalOrders / $perPage));

// Ambil Data Pesanan
$sql = "
    SELECT * FROM orders 
    $whereClause 
    ORDER BY id DESC 
    LIMIT $perPage OFFSET $offset
";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$orders = $stmt->fetchAll();

// Status options (PRD Section 5.3)
$statusList = [
    'Menunggu Konfirmasi',
    'Dikonfirmasi',
    'Diproses',
    'Dalam Pengiriman',
    'Selesai',
    'Dibatalkan'
];
?>

<div class="page-header">
  <div>
    <h1 class="page-title">Kelola Pesanan Pelanggan</h1>
    <p class="page-subtitle">Periksa pesanan masuk, hubungi pembeli via WhatsApp, dan perbarui status pengiriman</p>
  </div>
</div>

<!-- Filter Bar -->
<div class="admin-card" style="margin-bottom: 20px;">
  <div class="admin-card-body" style="padding: 16px;">
    <form action="index.php" method="GET" style="display: flex; gap: 12px; flex-wrap: wrap; align-items: center;">
      
      <div style="flex: 1; min-width: 220px;">
        <input type="text" name="q" class="form-control" placeholder="Cari Kode Pesanan, Nama, atau No HP..." value="<?= htmlspecialchars($q) ?>">
      </div>

      <div style="min-width: 180px;">
        <select name="status" class="form-control" onchange="this.form.submit()">
          <option value="">-- Semua Status --</option>
          <?php foreach ($statusList as $st): ?>
            <option value="<?= $st ?>" <?= $status === $st ? 'selected' : '' ?>><?= $st ?></option>
          <?php endforeach; ?>
        </select>
      </div>

      <div style="display: flex; align-items: center; gap: 6px;">
        <input type="date" name="start_date" class="form-control" value="<?= htmlspecialchars($startDate) ?>" title="Tanggal Mulai">
        <span style="color: #64748b;">s/d</span>
        <input type="date" name="end_date" class="form-control" value="<?= htmlspecialchars($endDate) ?>" title="Tanggal Akhir">
      </div>

      <button type="submit" class="btn btn-secondary">Filter</button>
      <?php if (!empty($q) || !empty($status) || !empty($startDate) || !empty($endDate)): ?>
        <a href="index.php" class="btn btn-secondary" style="color: #dc3545;">Reset</a>
      <?php endif; ?>
    </form>
  </div>
</div>

<!-- Table Orders -->
<div class="admin-card">
  <div class="table-responsive">
    <table class="admin-table">
      <thead>
        <tr>
          <th>Kode Pesanan</th>
          <th>Nama Pelanggan</th>
          <th>WhatsApp Pelanggan</th>
          <th>Subtotal</th>
          <th>Ongkir</th>
          <th>Total Pesanan</th>
          <th>Status</th>
          <th>Waktu Pemesanan</th>
          <th style="text-align: right;">Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php if (!empty($orders)): ?>
          <?php foreach ($orders as $o): ?>
            <?php 
              $statusClass = 'badge-menunggu-konfirmasi';
              if ($o['status'] === 'Dikonfirmasi') $statusClass = 'badge-dikonfirmasi';
              elseif ($o['status'] === 'Diproses') $statusClass = 'badge-diproses';
              elseif ($o['status'] === 'Dalam Pengiriman') $statusClass = 'badge-dalam-pengiriman';
              elseif ($o['status'] === 'Selesai') $statusClass = 'badge-selesai';
              elseif ($o['status'] === 'Dibatalkan') $statusClass = 'badge-dibatalkan';

              $cleanCustPhone = cleanPhoneForWhatsApp($o['customer_phone']);
              $waChatUrl = "https://wa.me/{$cleanCustPhone}?text=" . rawurlencode("Halo {$o['customer_name']}, kami dari JAWA MART mengonfirmasi pesanan Anda dengan Kode: {$o['order_code']}.");
            ?>
            <tr>
              <td>
                <a href="detail.php?id=<?= $o['id'] ?>" style="font-weight: 800; color: #198754; font-size: 14px;">
                  <?= htmlspecialchars($o['order_code']) ?>
                </a>
              </td>
              <td>
                <div style="font-weight: 700; color: #1e293b;"><?= htmlspecialchars($o['customer_name']) ?></div>
                <div style="font-size: 11.5px; color: #64748b; max-width: 180px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                  <?= htmlspecialchars($o['customer_address']) ?>
                </div>
              </td>
              <td>
                <a href="<?= $waChatUrl ?>" target="_blank" rel="noopener" style="color: #25d366; font-weight: 700; display: inline-flex; align-items: center; gap: 4px;">
                  <span>💬 <?= htmlspecialchars($o['customer_phone']) ?></span>
                </a>
              </td>
              <td style="color: #475569;"><?= formatRupiah($o['subtotal']) ?></td>
              <td style="color: #475569;"><?= $o['shipping_cost'] > 0 ? formatRupiah($o['shipping_cost']) : 'GRATIS' ?></td>
              <td>
                <strong style="color: #198754; font-size: 15px;"><?= formatRupiah($o['total']) ?></strong>
              </td>
              <td>
                <span class="status-badge <?= $statusClass ?>"><?= htmlspecialchars($o['status']) ?></span>
              </td>
              <td style="color: #64748b; font-size: 12px; white-space: nowrap;">
                <?= formatDate($o['created_at']) ?>
              </td>
              <td style="text-align: right; white-space: nowrap;">
                <a href="detail.php?id=<?= $o['id'] ?>" class="btn btn-primary btn-sm">
                  Kelola &rarr;
                </a>
                <a href="print.php?id=<?= $o['id'] ?>" target="_blank" class="btn btn-secondary btn-sm" title="Cetak Nota">
                  🖨️
                </a>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php else: ?>
          <tr>
            <td colspan="9" style="text-align: center; color: #64748b; padding: 28px;">
              Tidak ada data pesanan yang sesuai dengan filter pencarian.
            </td>
          </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>

  <!-- Pagination -->
  <?php if ($totalPages > 1): ?>
    <div style="padding: 16px 20px; display: flex; justify-content: center; gap: 6px; border-top: 1px solid var(--admin-border);">
      <?php for ($i = 1; $i <= $totalPages; $i++): ?>
        <a href="index.php?<?= http_build_query(array_merge($_GET, ['page' => $i])) ?>" 
           class="btn btn-sm <?= $i === $page ? 'btn-primary' : 'btn-secondary' ?>">
          <?= $i ?>
        </a>
      <?php endfor; ?>
    </div>
  <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
