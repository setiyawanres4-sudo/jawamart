<?php
/**
 * JAWA MART - Cetak Nota Pesanan
 * File: admin/orders/print.php
 */

declare(strict_types=1);

require_once __DIR__ . '/../../includes/auth.php';
requireAdminAuth();

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    die('ID pesanan tidak valid.');
}

$stmt = $pdo->prepare("SELECT * FROM orders WHERE id = :id LIMIT 1");
$stmt->execute(['id' => $id]);
$order = $stmt->fetch();

if (!$order) {
    die('Pesanan tidak ditemukan.');
}

$stmtItems = $pdo->prepare("SELECT * FROM order_items WHERE order_id = :oid ORDER BY id ASC");
$stmtItems->execute(['oid' => $order['id']]);
$items = $stmtItems->fetchAll();

$storeName        = getSetting('store_name', 'JAWA MART');
$storeTagline     = getSetting('store_tagline', 'Belanja Sembako Mudah, Hemat, dan Praktis.');
$whatsappDisplay  = getSetting('whatsapp_display', '+62 878-1212-2735');
$storeAddress     = getSetting('store_address', 'Jl. Pasar Tradisional & Sembako Jaya No. 88, Jawa');
$storeEmail       = getSetting('store_email', 'kontak@jawamart.id');
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Nota Pesanan <?= htmlspecialchars($order['order_code']) ?> — <?= htmlspecialchars($storeName) ?></title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: Arial, sans-serif;
      font-size: 13px;
      color: #212529;
      background: #f8fafc;
      padding: 30px 15px;
    }
    .invoice-card {
      max-width: 750px;
      margin: 0 auto;
      background: #fff;
      padding: 35px;
      border: 1px solid #dee2e6;
      border-radius: 8px;
      box-shadow: 0 2px 10px rgba(0,0,0,0.05);
    }
    .header-table { width: 100%; margin-bottom: 25px; border-bottom: 2px solid #198754; padding-bottom: 15px; }
    .header-table td { vertical-align: top; }
    .store-brand h1 { font-size: 22px; color: #198754; font-weight: 800; margin-bottom: 4px; }
    .order-title { text-align: right; }
    .order-title h2 { font-size: 18px; color: #334155; }
    .order-code { font-size: 16px; font-weight: bold; color: #198754; margin-top: 4px; }
    .customer-info-box {
      background: #f8fafc;
      border: 1px solid #e2e8f0;
      border-radius: 6px;
      padding: 14px;
      margin-bottom: 25px;
      line-height: 1.6;
    }
    .items-table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
    .items-table th { background: #e8f5e9; color: #0f5132; text-align: left; padding: 10px 12px; font-size: 12px; text-transform: uppercase; border-bottom: 1.5px solid #c3e6cb; }
    .items-table td { padding: 10px 12px; border-bottom: 1px solid #e2e8f0; }
    .totals-box { width: 280px; margin-left: auto; margin-bottom: 30px; font-size: 13.5px; }
    .totals-row { display: flex; justify-content: space-between; margin-bottom: 6px; }
    .totals-grand { font-size: 16px; font-weight: bold; color: #198754; border-top: 1.5px dashed #cbd5e1; padding-top: 8px; margin-top: 8px; }
    .print-actions { text-align: center; margin-bottom: 20px; }
    .btn-print { background: #198754; color: #fff; border: none; padding: 10px 24px; font-size: 14px; font-weight: bold; border-radius: 6px; cursor: pointer; }
    @media print {
      body { background: #fff; padding: 0; }
      .invoice-card { border: none; box-shadow: none; padding: 10px; width: 100%; }
      .print-actions { display: none !important; }
    }
  </style>
</head>
<body>

  <div class="print-actions">
    <button onclick="window.print()" class="btn-print">🖨️ Cetak / Simpan sebagai PDF</button>
  </div>

  <div class="invoice-card">
    
    <table class="header-table">
      <tr>
        <td class="store-brand" style="width: 60%;">
          <h1><?= htmlspecialchars($storeName) ?></h1>
          <p style="font-size: 11.5px; color: #64748b; font-style: italic; margin-bottom: 6px;"><?= htmlspecialchars($storeTagline) ?></p>
          <p style="font-size: 12px; line-height: 1.4; color: #475569;">
            <?= htmlspecialchars($storeAddress) ?><br>
            WhatsApp: <strong><?= htmlspecialchars($whatsappDisplay) ?></strong> &bull; Email: <?= htmlspecialchars($storeEmail) ?>
          </p>
        </td>
        <td class="order-title">
          <h2>NOTA PESANAN</h2>
          <div class="order-code"><?= htmlspecialchars($order['order_code']) ?></div>
          <div style="font-size: 12px; color: #64748b; margin-top: 4px;">Tanggal: <?= formatDate($order['created_at'], true) ?></div>
          <div style="margin-top: 6px;">
            Status: <span style="font-weight: bold; padding: 2px 8px; background: #e8f5e9; border-radius: 4px; color: #198754;"><?= htmlspecialchars($order['status']) ?></span>
          </div>
        </td>
      </tr>
    </table>

    <div class="customer-info-box">
      <strong>Penerima Pesanan:</strong><br>
      Nama: <strong><?= htmlspecialchars($order['customer_name']) ?></strong><br>
      WhatsApp: <?= htmlspecialchars($order['customer_phone']) ?><br>
      Alamat: <?= nl2br(htmlspecialchars($order['customer_address'])) ?><br>
      <?php if (!empty($order['customer_note'])): ?>
        Catatan: <em><?= htmlspecialchars($order['customer_note']) ?></em>
      <?php endif; ?>
    </div>

    <table class="items-table">
      <thead>
        <tr>
          <th>No</th>
          <th>Nama Barang</th>
          <th>SKU</th>
          <th>Harga Satuan</th>
          <th style="text-align: center;">Jumlah</th>
          <th style="text-align: right;">Subtotal</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($items as $idx => $item): ?>
          <tr>
            <td style="width: 30px;"><?= $idx + 1 ?></td>
            <td style="font-weight: 600;"><?= htmlspecialchars($item['product_name']) ?></td>
            <td><code style="font-size: 11px;"><?= htmlspecialchars($item['product_sku']) ?></code></td>
            <td><?= formatRupiah($item['unit_price']) ?></td>
            <td style="text-align: center;"><?= $item['quantity'] ?> <?= htmlspecialchars($item['unit']) ?></td>
            <td style="text-align: right; font-weight: 600;"><?= formatRupiah($item['subtotal']) ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>

    <div class="totals-box">
      <div class="totals-row">
        <span>Subtotal Barang:</span>
        <span><?= formatRupiah($order['subtotal']) ?></span>
      </div>
      <div class="totals-row">
        <span>Biaya Pengiriman:</span>
        <span><?= $order['shipping_cost'] > 0 ? formatRupiah($order['shipping_cost']) : 'GRATIS' ?></span>
      </div>
      <div class="totals-row totals-grand">
        <span>Total Tagihan:</span>
        <span><?= formatRupiah($order['total']) ?></span>
      </div>
    </div>

    <div style="display: flex; justify-content: space-between; margin-top: 40px; border-top: 1px solid #e2e8f0; padding-top: 20px; font-size: 12px; color: #64748b;">
      <div style="text-align: center; width: 200px;">
        <p>Penerima,</p>
        <div style="height: 60px;"></div>
        <p>( .................................... )</p>
      </div>
      <div style="text-align: center; width: 200px;">
        <p><?= htmlspecialchars($storeName) ?>,</p>
        <div style="height: 60px;"></div>
        <p style="font-weight: bold;">( Petugas Toko )</p>
      </div>
    </div>

    <div style="text-align: center; margin-top: 25px; font-size: 11.5px; color: #94a3b8;">
      Terima kasih telah mempercayakan kebutuhan sembako keluarga Anda kepada <?= htmlspecialchars($storeName) ?>.
    </div>

  </div>

</body>
</html>
