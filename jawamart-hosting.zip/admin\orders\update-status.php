<?php
/**
 * JAWA MART - Handler Perubahan Status Pesanan & Aturan Stok Atomik
 * File: admin/orders/update-status.php
 */

declare(strict_types=1);

require_once __DIR__ . '/../../includes/auth.php';
requireAdminAuth();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php');
    exit;
}

$token = $_POST['csrf_token'] ?? '';
if (!verifyCsrfToken($token)) {
    setFlash('danger', 'Token sesi form tidak valid.');
    header('Location: index.php');
    exit;
}

$orderId   = (int)($_POST['order_id'] ?? 0);
$newStatus = trim($_POST['new_status'] ?? '');
$note      = trim($_POST['status_note'] ?? '');
$admin     = getLoggedInAdmin();

if ($orderId <= 0 || empty($newStatus)) {
    setFlash('danger', 'Data parameter perubahan status tidak lengkap.');
    header('Location: index.php');
    exit;
}

$validStatuses = [
    'Menunggu Konfirmasi',
    'Dikonfirmasi',
    'Diproses',
    'Dalam Pengiriman',
    'Selesai',
    'Dibatalkan'
];

if (!in_array($newStatus, $validStatuses, true)) {
    setFlash('danger', 'Status pesanan tidak valid.');
    header("Location: detail.php?id=$orderId");
    exit;
}

try {
    $pdo->beginTransaction();

    // Ambil data order dengan FOR UPDATE untuk mencegah race conditions
    $stmtOrder = $pdo->prepare("SELECT * FROM orders WHERE id = :id FOR UPDATE");
    $stmtOrder->execute(['id' => $orderId]);
    $order = $stmtOrder->fetch();

    if (!$order) {
        throw new Exception('Pesanan tidak ditemukan.');
    }

    $oldStatus = $order['status'];
    $stockDeducted = (int)$order['stock_deducted'];

    // Ambil order items
    $stmtItems = $pdo->prepare("SELECT * FROM order_items WHERE order_id = :oid");
    $stmtItems->execute(['oid' => $orderId]);
    $items = $stmtItems->fetchAll();

    // 1. ATURAN PENGURANGAN STOK ATOMIK (PRD Section 5.5)
    // Stok dikurangi ketika pesanan beralih ke Dikonfirmasi / Diproses / Dalam Pengiriman / Selesai
    $requiresStockDeduction = in_array($newStatus, ['Dikonfirmasi', 'Diproses', 'Dalam Pengiriman', 'Selesai'], true);
    
    if ($requiresStockDeduction && $stockDeducted === 0) {
        foreach ($items as $item) {
            $pid = (int)($item['product_id'] ?? 0);
            $qty = (int)$item['quantity'];

            if ($pid > 0) {
                // Ambil stok saat ini dengan lock
                $stmtStock = $pdo->prepare("SELECT id, name, stock FROM products WHERE id = :pid FOR UPDATE");
                $stmtStock->execute(['pid' => $pid]);
                $prod = $stmtStock->fetch();

                if ($prod) {
                    $stockBefore = (int)$prod['stock'];
                    if ($stockBefore < $qty) {
                        throw new Exception("Stok untuk produk '{$prod['name']}' tidak mencukupi (Tersisa {$stockBefore}, dibutuhkan {$qty}). Gagal mengonfirmasi pesanan.");
                    }

                    $stockAfter = $stockBefore - $qty;

                    // Kurangi stok produk secara atomik
                    $stmtDeduct = $pdo->prepare("UPDATE products SET stock = :s, updated_at = NOW() WHERE id = :pid");
                    $stmtDeduct->execute(['s' => $stockAfter, 'pid' => $pid]);

                    // Catat riwayat mutasi stok (PRD Section 8.5)
                    recordStockMovement(
                        $pdo,
                        $pid,
                        $admin['id'] ?? 1,
                        $orderId,
                        'Pengurangan karena Pesanan',
                        $qty,
                        $stockBefore,
                        $stockAfter,
                        "Pengurangan otomatis untuk pesanan #{$order['order_code']}"
                    );
                }
            }
        }

        $stockDeducted = 1;
    }

    // 2. ATURAN PENGEMBALIAN STOK ATOMIK (PRD Section 5.5)
    // Pembatalan pesanan yang stoknya sudah dikurangi harus mengembalikan stok. Pengembalian tidak boleh dilakukan > 1 kali.
    if ($newStatus === 'Dibatalkan' && $stockDeducted === 1) {
        foreach ($items as $item) {
            $pid = (int)($item['product_id'] ?? 0);
            $qty = (int)$item['quantity'];

            if ($pid > 0) {
                $stmtStock = $pdo->prepare("SELECT id, stock FROM products WHERE id = :pid FOR UPDATE");
                $stmtStock->execute(['pid' => $pid]);
                $prod = $stmtStock->fetch();

                if ($prod) {
                    $stockBefore = (int)$prod['stock'];
                    $stockAfter = $stockBefore + $qty;

                    $stmtRestore = $pdo->prepare("UPDATE products SET stock = :s, updated_at = NOW() WHERE id = :pid");
                    $stmtRestore->execute(['s' => $stockAfter, 'pid' => $pid]);

                    // Catat riwayat mutasi stok pengembalian
                    recordStockMovement(
                        $pdo,
                        $pid,
                        $admin['id'] ?? 1,
                        $orderId,
                        'Pengembalian karena Pembatalan',
                        $qty,
                        $stockBefore,
                        $stockAfter,
                        "Pengembalian stok akibat pembatalan pesanan #{$order['order_code']}"
                    );
                }
            }
        }

        $stockDeducted = 0;
    }

    // 3. Update Status di Tabel orders
    $stmtUpOrder = $pdo->prepare("
        UPDATE orders 
        SET status = :st, stock_deducted = :sd, updated_at = NOW() 
        WHERE id = :id
    ");
    $stmtUpOrder->execute([
        'st' => $newStatus,
        'sd' => $stockDeducted,
        'id' => $orderId
    ]);

    // 4. Catat ke Tabel order_status_history (Audit Trail)
    $stmtHist = $pdo->prepare("
        INSERT INTO order_status_history (
            order_id, admin_id, old_status, new_status, note, created_at
        ) VALUES (
            :oid, :aid, :old_st, :new_st, :note, NOW()
        )
    ");
    $stmtHist->execute([
        'oid'    => $orderId,
        'aid'    => $admin['id'] ?? 1,
        'old_st' => $oldStatus,
        'new_st' => $newStatus,
        'note'   => $note ?: "Status diubah dari '{$oldStatus}' menjadi '{$newStatus}'"
    ]);

    $pdo->commit();
    setFlash('success', "Status pesanan #{$order['order_code']} berhasil diperbarui menjadi '{$newStatus}'.");
} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log("Error updating order status: " . $e->getMessage());
    setFlash('danger', 'Gagal memperbarui status: ' . $e->getMessage());
}

header("Location: detail.php?id=$orderId");
exit;
