<?php
/**
 * JAWA MART - Tambah Produk Baru
 * File: admin/products/create.php
 */

declare(strict_types=1);

$adminTitle = 'Tambah Produk Sembako';
require_once __DIR__ . '/../includes/header.php';

$errors = [];

// Ambil Kategori Aktif
$categories = $pdo->query("SELECT id, name FROM categories WHERE status = 1 ORDER BY name ASC")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['csrf_token'] ?? '';
    if (!verifyCsrfToken($token)) {
        $errors[] = 'Sesi form Anda telah kedaluwarsa. Silakan coba kembali.';
    } else {
        $categoryId    = (int)($_POST['category_id'] ?? 0);
        $sku           = strtoupper(trim($_POST['sku'] ?? ''));
        $name          = trim($_POST['name'] ?? '');
        $description   = trim($_POST['description'] ?? '');
        $price         = (float)($_POST['price'] ?? 0);
        $discountPrice = !empty($_POST['discount_price']) ? (float)$_POST['discount_price'] : null;
        $stock         = max(0, (int)($_POST['stock'] ?? 0));
        $minStock      = max(1, (int)($_POST['minimum_stock'] ?? 5));
        $unit          = trim($_POST['unit'] ?? 'pcs');
        $isFeatured    = isset($_POST['is_featured']) ? 1 : 0;
        $status        = isset($_POST['status']) ? 1 : 0;

        if ($categoryId <= 0) $errors[] = 'Pilih kategori produk.';
        if (empty($name)) $errors[] = 'Nama produk wajib diisi.';
        if (empty($sku)) {
            // Auto generate SKU jika kosong
            $sku = 'JM-' . strtoupper(substr(preg_replace('/[^A-Za-z]/', '', $name), 0, 3)) . '-' . rand(100, 999);
        }
        if ($price <= 0) $errors[] = 'Harga normal harus lebih besar dari 0.';
        if ($discountPrice !== null && $discountPrice >= $price) {
            $errors[] = 'Harga diskon harus lebih kecil dari harga normal.';
        }

        // Cek Keunikan SKU
        $checkSku = $pdo->prepare("SELECT id FROM products WHERE sku = :sku AND deleted_at IS NULL LIMIT 1");
        $checkSku->execute(['sku' => $sku]);
        if ($checkSku->fetch()) {
            $errors[] = 'SKU "' . htmlspecialchars($sku) . '" sudah digunakan oleh produk lain.';
        }

        // Slug
        $baseSlug = slugify($name);
        $slug = $baseSlug;
        $counter = 1;
        while (true) {
            $chkSlug = $pdo->prepare("SELECT id FROM products WHERE slug = :s LIMIT 1");
            $chkSlug->execute(['s' => $slug]);
            if (!$chkSlug->fetch()) break;
            $slug = $baseSlug . '-' . (++$counter);
        }

        // Upload Foto Produk
        $imagePath = 'assets/images/placeholder.svg';
        if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
            $uploadRes = uploadImage($_FILES['image'], 'products', 'prod');
            if ($uploadRes['success']) {
                $imagePath = $uploadRes['path'];
            } else {
                $errors[] = $uploadRes['message'];
            }
        }

        if (empty($errors)) {
            try {
                $pdo->beginTransaction();

                $stmt = $pdo->prepare("
                    INSERT INTO products (
                        category_id, sku, name, slug, description, price, discount_price, 
                        stock, minimum_stock, unit, image, is_featured, status, created_at, updated_at
                    ) VALUES (
                        :category_id, :sku, :name, :slug, :description, :price, :discount_price, 
                        :stock, :minimum_stock, :unit, :image, :is_featured, :status, NOW(), NOW()
                    )
                ");

                $stmt->execute([
                    'category_id'    => $categoryId,
                    'sku'            => $sku,
                    'name'           => $name,
                    'slug'           => $slug,
                    'description'    => $description,
                    'price'          => $price,
                    'discount_price' => $discountPrice,
                    'stock'          => $stock,
                    'minimum_stock'  => $minStock,
                    'unit'           => $unit,
                    'image'          => $imagePath,
                    'is_featured'    => $isFeatured,
                    'status'         => $status
                ]);

                $newProductId = (int)$pdo->lastInsertId();

                // Catat Stok Awal di stock_movements (PRD Section 8.5)
                recordStockMovement(
                    $pdo,
                    $newProductId,
                    $currentAdmin['id'] ?? 1,
                    null,
                    'Stok Awal',
                    $stock,
                    0,
                    $stock,
                    'Inisialisasi stok produk baru saat ditambahkan ke sistem'
                );

                $pdo->commit();
                setFlash('success', 'Produk "' . $name . '" berhasil ditambahkan ke katalog!');
                header('Location: index.php');
                exit;
            } catch (Exception $e) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }
                error_log("Error creating product: " . $e->getMessage());
                $errors[] = 'Gagal menyimpan produk ke database: ' . $e->getMessage();
            }
        }
    }
}
?>

<div class="page-header">
  <div>
    <h1 class="page-title">Tambah Produk Sembako Baru</h1>
    <p class="page-subtitle">Masukkan data informasi produk, harga, stok, dan foto barang</p>
  </div>
  <a href="index.php" class="btn btn-secondary">
    &larr; Kembali ke Daftar Produk
  </a>
</div>

<?php if (!empty($errors)): ?>
  <div class="flash-alert danger">
    <div>
      <strong>Terjadi kesalahan:</strong>
      <ul style="margin-left: 20px; margin-top: 4px;">
        <?php foreach ($errors as $err): ?>
          <li><?= htmlspecialchars($err) ?></li>
        <?php endforeach; ?>
      </ul>
    </div>
  </div>
<?php endif; ?>

<div class="admin-card">
  <div class="admin-card-body">
    <form action="create.php" method="POST" enctype="multipart/form-data">
      <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">

      <div class="form-row">
        <!-- Kategori -->
        <div class="form-group">
          <label class="form-label" for="category_id">Kategori Sembako <span style="color:red;">*</span></label>
          <select name="category_id" id="category_id" class="form-control" required>
            <option value="">-- Pilih Kategori --</option>
            <?php foreach ($categories as $cat): ?>
              <option value="<?= $cat['id'] ?>" <?= (($_POST['category_id'] ?? '') == $cat['id']) ? 'selected' : '' ?>>
                <?= htmlspecialchars($cat['name']) ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>

        <!-- SKU -->
        <div class="form-group">
          <label class="form-label" for="sku">SKU (Kode Barang Unik)</label>
          <input type="text" name="sku" id="sku" class="form-control" placeholder="Kosongkan untuk auto-generate (contoh: BR-PRM-005)" value="<?= htmlspecialchars($_POST['sku'] ?? '') ?>">
        </div>
      </div>

      <div class="form-group">
        <label class="form-label" for="name">Nama Produk Sembako <span style="color:red;">*</span></label>
        <input type="text" name="name" id="name" class="form-control" placeholder="Contoh: Beras Premium Ramos Wangi 5 Kg" required value="<?= htmlspecialchars($_POST['name'] ?? '') ?>">
      </div>

      <div class="form-group">
        <label class="form-label" for="description">Deskripsi Produk</label>
        <textarea name="description" id="description" class="form-control" rows="4" placeholder="Jelaskan kualitas, kelebihan, spesifikasi, atau anjuran penyimpanan produk..."><?= htmlspecialchars($_POST['description'] ?? '') ?></textarea>
      </div>

      <div class="form-row">
        <!-- Harga Normal -->
        <div class="form-group">
          <label class="form-label" for="price">Harga Normal (Rp) <span style="color:red;">*</span></label>
          <input type="number" step="100" min="0" name="price" id="price" class="form-control" placeholder="75000" required value="<?= htmlspecialchars($_POST['price'] ?? '') ?>">
        </div>

        <!-- Harga Diskon -->
        <div class="form-group">
          <label class="form-label" for="discount_price">Harga Diskon (Rp) (Opsional)</label>
          <input type="number" step="100" min="0" name="discount_price" id="discount_price" class="form-control" placeholder="Kosongkan jika tidak ada promo diskon" value="<?= htmlspecialchars($_POST['discount_price'] ?? '') ?>">
        </div>

        <!-- Satuan -->
        <div class="form-group">
          <label class="form-label" for="unit">Satuan Barang <span style="color:red;">*</span></label>
          <select name="unit" id="unit" class="form-control" required>
            <?php 
              $units = ['Kg', 'Gram', 'Liter', 'Ml', 'Pcs', 'Pack', 'Dus', 'Botol', 'Karung', 'Kaleng', 'Lainnya'];
              $selectedUnit = $_POST['unit'] ?? 'Pcs';
              foreach ($units as $u):
            ?>
              <option value="<?= $u ?>" <?= $selectedUnit === $u ? 'selected' : '' ?>><?= $u ?></option>
            <?php endforeach; ?>
          </select>
        </div>
      </div>

      <div class="form-row">
        <!-- Stok Awal -->
        <div class="form-group">
          <label class="form-label" for="stock">Stok Awal <span style="color:red;">*</span></label>
          <input type="number" min="0" name="stock" id="stock" class="form-control" placeholder="50" required value="<?= htmlspecialchars($_POST['stock'] ?? '50') ?>">
        </div>

        <!-- Stok Minimum -->
        <div class="form-group">
          <label class="form-label" for="minimum_stock">Batas Minimum Stok (Peringatan)</label>
          <input type="number" min="1" name="minimum_stock" id="minimum_stock" class="form-control" placeholder="5" value="<?= htmlspecialchars($_POST['minimum_stock'] ?? '5') ?>">
          <small style="color: #64748b;">Notifikasi stok menipis akan muncul saat sisa stok &le; angka ini.</small>
        </div>
      </div>

      <!-- Upload Foto Produk -->
      <div class="form-group">
        <label class="form-label" for="image">Foto Produk (Rasio 1:1, JPG/PNG/WebP/SVG, Maks 2MB)</label>
        <input type="file" name="image" id="image" class="form-control" accept="image/*" data-preview="prodImgPreview">
        <div class="img-preview-box">
          <img id="prodImgPreview" src="../../assets/images/placeholder.svg" alt="Preview Gambar">
        </div>
      </div>

      <!-- Checkboxes -->
      <div style="display: flex; gap: 24px; margin: 20px 0;">
        <label style="display: flex; align-items: center; gap: 8px; cursor: pointer; font-weight: 600;">
          <input type="checkbox" name="is_featured" value="1" <?= isset($_POST['is_featured']) ? 'checked' : '' ?>>
          <span>Tandai sebagai Produk Unggulan / Rekomendasi (Muncul di Beranda)</span>
        </label>

        <label style="display: flex; align-items: center; gap: 8px; cursor: pointer; font-weight: 600;">
          <input type="checkbox" name="status" value="1" <?= (!isset($_POST['status']) || $_POST['status'] == '1') ? 'checked' : '' ?>>
          <span>Status Aktif (Ditampilkan di Katalog Pembeli)</span>
        </label>
      </div>

      <div style="display: flex; gap: 12px; margin-top: 24px;">
        <button type="submit" class="btn btn-primary" style="padding: 10px 24px;">
          Simpan Produk Baru
        </button>
        <a href="index.php" class="btn btn-secondary">Batal</a>
      </div>
    </form>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
