<?php
/**
 * JAWA MART - Hapus / Arsipkan Produk Sembako (Soft Delete)
 * File: admin/products/delete.php
 */

declare(strict_types=1);

require_once __DIR__ . '/../../includes/auth.php';
requireAdminAuth();

$id    = (int)($_GET['id'] ?? 0);
$token = $_GET['csrf_token'] ?? '';

if (!verifyCsrfToken($token)) {
    setFlash('danger', 'Token keamanan tidak valid atau telah kedaluwarsa.');
    header('Location: index.php');
    exit;
}

if ($id <= 0) {
    setFlash('danger', 'ID produk tidak valid.');
    header('Location: index.php');
    exit;
}

try {
    // Cek apakah produk pernah digunakan dalam transaksi pesanan (PRD 8.3 & 10.5)
    $stmtCheck = $pdo->prepare("SELECT COUNT(*) FROM order_items WHERE product_id = :pid");
    $stmtCheck->execute(['pid' => $id]);
    $orderCount = (int)$stmtCheck->fetchColumn();

    // Selalu gunakan soft delete untuk menjaga keutuhan riwayat transaksi dan database integrity
    $stmtDelete = $pdo->prepare("
        UPDATE products 
        SET deleted_at = NOW(), status = 0 
        WHERE id = :id AND deleted_at IS NULL
    ");
    $stmtDelete->execute(['id' => $id]);

    if ($stmtDelete->rowCount() > 0) {
        $msg = $orderCount > 0 
            ? 'Produk berhasil diarsipkan secara aman (soft delete) tanpa merusak ' . $orderCount . ' riwayat transaksi pesanan.'
            : 'Produk berhasil dihapus dari katalog aktif.';
        setFlash('success', $msg);
    } else {
        setFlash('warning', 'Produk tidak ditemukan atau sudah dihapus sebelumnya.');
    }
} catch (Exception $e) {
    error_log("Error deleting product: " . $e->getMessage());
    setFlash('danger', 'Gagal menghapus produk: ' . $e->getMessage());
}

header('Location: index.php');
exit;
