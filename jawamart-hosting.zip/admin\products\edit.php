<?php
/**
 * JAWA MART - Edit Produk Sembako
 * File: admin/products/edit.php
 */

declare(strict_types=1);

$adminTitle = 'Edit Produk Sembako';
require_once __DIR__ . '/../includes/header.php';

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    header('Location: index.php');
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM products WHERE id = :id AND deleted_at IS NULL LIMIT 1");
$stmt->execute(['id' => $id]);
$product = $stmt->fetch();

if (!$product) {
    setFlash('danger', 'Produk tidak ditemukan atau telah dihapus.');
    header('Location: index.php');
    exit;
}

$categories = $pdo->query("SELECT id, name FROM categories WHERE status = 1 ORDER BY name ASC")->fetchAll();
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['csrf_token'] ?? '';
    if (!verifyCsrfToken($token)) {
        $errors[] = 'Sesi form Anda telah kedaluwarsa. Silakan coba kembali.';
    } else {
        $categoryId    = (int)($_POST['category_id'] ?? 0);
        $sku           = strtoupper(trim($_POST['sku'] ?? ''));
        $name          = trim($_POST['name'] ?? '');
        $description   = trim($_POST['description'] ?? '');
        $price         = (float)($_POST['price'] ?? 0);
        $discountPrice = !empty($_POST['discount_price']) ? (float)$_POST['discount_price'] : null;
        $stock         = max(0, (int)($_POST['stock'] ?? 0));
        $minStock      = max(1, (int)($_POST['minimum_stock'] ?? 5));
        $unit          = trim($_POST['unit'] ?? 'pcs');
        $isFeatured    = isset($_POST['is_featured']) ? 1 : 0;
        $status        = isset($_POST['status']) ? 1 : 0;

        if ($categoryId <= 0) $errors[] = 'Pilih kategori produk.';
        if (empty($name)) $errors[] = 'Nama produk wajib diisi.';
        if (empty($sku)) $errors[] = 'SKU tidak boleh kosong.';
        if ($price <= 0) $errors[] = 'Harga normal harus lebih besar dari 0.';
        if ($discountPrice !== null && $discountPrice >= $price) {
            $errors[] = 'Harga diskon harus lebih kecil dari harga normal.';
        }

        // Cek Keunikan SKU jika diubah
        $checkSku = $pdo->prepare("SELECT id FROM products WHERE sku = :sku AND id != :id AND deleted_at IS NULL LIMIT 1");
        $checkSku->execute(['sku' => $sku, 'id' => $id]);
        if ($checkSku->fetch()) {
            $errors[] = 'SKU "' . htmlspecialchars($sku) . '" sudah digunakan oleh produk lain.';
        }

        // Cek Upload Gambar Pengganti (PRD Section 7.5: jangan hapus foto lama sebelum foto baru berhasil disimpan)
        $newImagePath = null;
        if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
            $uploadRes = uploadImage($_FILES['image'], 'products', 'prod');
            if ($uploadRes['success']) {
                $newImagePath = $uploadRes['path'];
            } else {
                $errors[] = $uploadRes['message'];
            }
        }

        if (empty($errors)) {
            try {
                $pdo->beginTransaction();

                $oldStock = (int)$product['stock'];
                $finalImagePath = $newImagePath ?? $product['image'];

                // Update Data Produk
                $stmtUp = $pdo->prepare("
                    UPDATE products SET 
                        category_id = :category_id,
                        sku = :sku,
                        name = :name,
                        description = :description,
                        price = :price,
                        discount_price = :discount_price,
                        stock = :stock,
                        minimum_stock = :minimum_stock,
                        unit = :unit,
                        image = :image,
                        is_featured = :is_featured,
                        status = :status,
                        updated_at = NOW()
                    WHERE id = :id
                ");

                $stmtUp->execute([
                    'category_id'    => $categoryId,
                    'sku'            => $sku,
                    'name'           => $name,
                    'description'    => $description,
                    'price'          => $price,
                    'discount_price' => $discountPrice,
                    'stock'          => $stock,
                    'minimum_stock'  => $minStock,
                    'unit'           => $unit,
                    'image'          => $finalImagePath,
                    'is_featured'    => $isFeatured,
                    'status'         => $status,
                    'id'             => $id
                ]);

                // Jika stok berubah melalui form edit, catat ke riwayat stok
                if ($oldStock !== $stock) {
                    $diff = $stock - $oldStock;
                    $movementType = $diff > 0 ? 'Penyesuaian Stok (Tambah)' : 'Penyesuaian Stok (Kurang)';
                    recordStockMovement(
                        $pdo,
                        $id,
                        $currentAdmin['id'] ?? 1,
                        null,
                        $movementType,
                        abs($diff),
                        $oldStock,
                        $stock,
                        'Penyesuaian stok langsung melalui form edit produk'
                    );
                }

                $pdo->commit();
                setFlash('success', 'Produk "' . $name . '" berhasil diperbarui!');
                header('Location: index.php');
                exit;
            } catch (Exception $e) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }
                error_log("Error updating product: " . $e->getMessage());
                $errors[] = 'Gagal menyimpan perubahan produk: ' . $e->getMessage();
            }
        }
    }
}
?>

<div class="page-header">
  <div>
    <h1 class="page-title">Edit Produk: <?= htmlspecialchars($product['name']) ?></h1>
    <p class="page-subtitle">Ubah informasi harga, foto, kategori, dan stok barang</p>
  </div>
  <a href="index.php" class="btn btn-secondary">
    &larr; Kembali ke Daftar Produk
  </a>
</div>

<?php if (!empty($errors)): ?>
  <div class="flash-alert danger">
    <div>
      <strong>Terjadi kesalahan:</strong>
      <ul style="margin-left: 20px; margin-top: 4px;">
        <?php foreach ($errors as $err): ?>
          <li><?= htmlspecialchars($err) ?></li>
        <?php endforeach; ?>
      </ul>
    </div>
  </div>
<?php endif; ?>

<div class="admin-card">
  <div class="admin-card-body">
    <form action="edit.php?id=<?= $product['id'] ?>" method="POST" enctype="multipart/form-data">
      <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">

      <div class="form-row">
        <!-- Kategori -->
        <div class="form-group">
          <label class="form-label" for="category_id">Kategori Sembako <span style="color:red;">*</span></label>
          <select name="category_id" id="category_id" class="form-control" required>
            <?php foreach ($categories as $cat): ?>
              <option value="<?= $cat['id'] ?>" <?= ($product['category_id'] == $cat['id']) ? 'selected' : '' ?>>
                <?= htmlspecialchars($cat['name']) ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>

        <!-- SKU -->
        <div class="form-group">
          <label class="form-label" for="sku">SKU (Kode Barang Unik) <span style="color:red;">*</span></label>
          <input type="text" name="sku" id="sku" class="form-control" required value="<?= htmlspecialchars($product['sku']) ?>">
        </div>
      </div>

      <div class="form-group">
        <label class="form-label" for="name">Nama Produk Sembako <span style="color:red;">*</span></label>
        <input type="text" name="name" id="name" class="form-control" required value="<?= htmlspecialchars($product['name']) ?>">
      </div>

      <div class="form-group">
        <label class="form-label" for="description">Deskripsi Produk</label>
        <textarea name="description" id="description" class="form-control" rows="4"><?= htmlspecialchars($product['description'] ?? '') ?></textarea>
      </div>

      <div class="form-row">
        <!-- Harga Normal -->
        <div class="form-group">
          <label class="form-label" for="price">Harga Normal (Rp) <span style="color:red;">*</span></label>
          <input type="number" step="100" min="0" name="price" id="price" class="form-control" required value="<?= (float)$product['price'] ?>">
        </div>

        <!-- Harga Diskon -->
        <div class="form-group">
          <label class="form-label" for="discount_price">Harga Diskon (Rp) (Opsional)</label>
          <input type="number" step="100" min="0" name="discount_price" id="discount_price" class="form-control" placeholder="Kosongkan jika tidak ada promo diskon" value="<?= $product['discount_price'] ? (float)$product['discount_price'] : '' ?>">
        </div>

        <!-- Satuan -->
        <div class="form-group">
          <label class="form-label" for="unit">Satuan Barang <span style="color:red;">*</span></label>
          <select name="unit" id="unit" class="form-control" required>
            <?php 
              $units = ['Kg', 'Gram', 'Liter', 'Ml', 'Pcs', 'Pack', 'Dus', 'Botol', 'Karung', 'Kaleng', 'Lainnya'];
              foreach ($units as $u):
            ?>
              <option value="<?= $u ?>" <?= strcasecmp($product['unit'], $u) === 0 ? 'selected' : '' ?>><?= $u ?></option>
            <?php endforeach; ?>
          </select>
        </div>
      </div>

      <div class="form-row">
        <!-- Stok -->
        <div class="form-group">
          <label class="form-label" for="stock">Stok Tersedia <span style="color:red;">*</span></label>
          <input type="number" min="0" name="stock" id="stock" class="form-control" required value="<?= (int)$product['stock'] ?>">
          <small style="color: #64748b;">Perubahan stok di sini akan otomatis dicatat dalam riwayat mutasi stok.</small>
        </div>

        <!-- Stok Minimum -->
        <div class="form-group">
          <label class="form-label" for="minimum_stock">Batas Minimum Stok (Peringatan)</label>
          <input type="number" min="1" name="minimum_stock" id="minimum_stock" class="form-control" value="<?= (int)$product['minimum_stock'] ?>">
        </div>
      </div>

      <!-- Upload Foto Produk -->
      <div class="form-group">
        <label class="form-label" for="image">Ganti Foto Produk (Kosongkan jika tetap menggunakan foto lama)</label>
        <input type="file" name="image" id="image" class="form-control" accept="image/*" data-preview="prodImgPreview">
        <div style="display: flex; gap: 16px; align-items: center; margin-top: 8px;">
          <div>
            <div style="font-size: 11.5px; color: #64748b; margin-bottom: 4px;">Foto Saat Ini / Preview:</div>
            <div class="img-preview-box">
              <img id="prodImgPreview" src="../../<?= htmlspecialchars(!empty($product['image']) ? $product['image'] : 'assets/images/placeholder.svg') ?>" alt="Preview">
            </div>
          </div>
        </div>
      </div>

      <!-- Checkboxes -->
      <div style="display: flex; gap: 24px; margin: 20px 0;">
        <label style="display: flex; align-items: center; gap: 8px; cursor: pointer; font-weight: 600;">
          <input type="checkbox" name="is_featured" value="1" <?= $product['is_featured'] ? 'checked' : '' ?>>
          <span>Tandai sebagai Produk Unggulan / Rekomendasi</span>
        </label>

        <label style="display: flex; align-items: center; gap: 8px; cursor: pointer; font-weight: 600;">
          <input type="checkbox" name="status" value="1" <?= $product['status'] ? 'checked' : '' ?>>
          <span>Status Aktif</span>
        </label>
      </div>

      <div style="display: flex; gap: 12px; margin-top: 24px;">
        <button type="submit" class="btn btn-primary" style="padding: 10px 24px;">
          Simpan Perubahan
        </button>
        <a href="index.php" class="btn btn-secondary">Batal</a>
      </div>
    </form>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
