<?php
/**
 * JAWA MART - Kelola Produk
 * File: admin/products/index.php
 */

declare(strict_types=1);

$adminTitle = 'Kelola Produk Sembako';
require_once __DIR__ . '/../includes/header.php';

// Parameter Filter & Pagination
$q          = trim($_GET['q'] ?? '');
$catId      = (int)($_GET['category_id'] ?? 0);
$stockState = trim($_GET['stock_state'] ?? '');
$page       = max(1, (int)($_GET['page'] ?? 1));
$perPage    = 15;
$offset     = ($page - 1) * $perPage;

$where = ["p.deleted_at IS NULL"];
$params = [];

if (!empty($q)) {
    $where[] = "(p.name LIKE :q OR p.sku LIKE :q)";
    $params['q'] = '%' . $q . '%';
}

if ($catId > 0) {
    $where[] = "p.category_id = :cid";
    $params['cid'] = $catId;
}

if ($stockState === 'low') {
    $where[] = "p.stock > 0 AND p.stock <= p.minimum_stock";
} elseif ($stockState === 'out') {
    $where[] = "p.stock <= 0";
}

$whereClause = "WHERE " . implode(" AND ", $where);

// Hitung Total
$stmtCount = $pdo->prepare("SELECT COUNT(*) FROM products p $whereClause");
$stmtCount->execute($params);
$totalProducts = (int)$stmtCount->fetchColumn();
$totalPages = max(1, (int)ceil($totalProducts / $perPage));

// Ambil Data Produk
$sql = "
    SELECT p.*, c.name AS category_name 
    FROM products p 
    JOIN categories c ON c.id = p.category_id 
    $whereClause 
    ORDER BY p.id DESC 
    LIMIT $perPage OFFSET $offset
";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$products = $stmt->fetchAll();

// Ambil Kategori untuk dropdown filter
$categories = [];
try {
    $categories = $pdo->query("SELECT id, name FROM categories WHERE status = 1 ORDER BY name ASC")->fetchAll();
} catch (Exception $e) {}
?>

<div class="page-header">
  <div>
    <h1 class="page-title">Kelola Produk Sembako</h1>
    <p class="page-subtitle">Daftar seluruh katalog sembako aktif, harga, stok, dan pengaturan unggulan</p>
  </div>
  <a href="create.php" class="btn btn-primary">
    + Tambah Produk Baru
  </a>
</div>

<!-- Filter Bar -->
<div class="admin-card" style="margin-bottom: 20px;">
  <div class="admin-card-body" style="padding: 16px;">
    <form action="index.php" method="GET" style="display: flex; gap: 12px; flex-wrap: wrap; align-items: center;">
      <div style="flex: 1; min-width: 200px;">
        <input type="text" name="q" class="form-control" placeholder="Cari nama produk atau SKU..." value="<?= htmlspecialchars($q) ?>">
      </div>

      <div style="min-width: 180px;">
        <select name="category_id" class="form-control" onchange="this.form.submit()">
          <option value="">Semua Kategori</option>
          <?php foreach ($categories as $cat): ?>
            <option value="<?= $cat['id'] ?>" <?= $catId === (int)$cat['id'] ? 'selected' : '' ?>>
              <?= htmlspecialchars($cat['name']) ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>

      <div style="min-width: 160px;">
        <select name="stock_state" class="form-control" onchange="this.form.submit()">
          <option value="">Semua Kondisi Stok</option>
          <option value="low" <?= $stockState === 'low' ? 'selected' : '' ?>>Stok Menipis (&le; Min)</option>
          <option value="out" <?= $stockState === 'out' ? 'selected' : '' ?>>Stok Habis (0)</option>
        </select>
      </div>

      <button type="submit" class="btn btn-secondary">Filter</button>
      <?php if (!empty($q) || $catId > 0 || !empty($stockState)): ?>
        <a href="index.php" class="btn btn-secondary" style="color: #dc3545;">Reset</a>
      <?php endif; ?>
    </form>
  </div>
</div>

<!-- Table Produk -->
<div class="admin-card">
  <div class="table-responsive">
    <table class="admin-table">
      <thead>
        <tr>
          <th>Foto</th>
          <th>Nama Produk &amp; SKU</th>
          <th>Kategori</th>
          <th>Harga Normal</th>
          <th>Harga Diskon</th>
          <th>Stok</th>
          <th>Status</th>
          <th>Unggulan</th>
          <th style="text-align: right;">Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php if (!empty($products)): ?>
          <?php foreach ($products as $p): ?>
            <?php 
              $isOut = $p['stock'] <= 0;
              $isLow = !$isOut && $p['stock'] <= $p['minimum_stock'];
            ?>
            <tr>
              <td style="width: 50px;">
                <img src="../../<?= htmlspecialchars(!empty($p['image']) ? $p['image'] : 'assets/images/placeholder.svg') ?>" 
                     alt="<?= htmlspecialchars($p['name']) ?>" 
                     style="width: 44px; height: 44px; object-fit: contain; border-radius: 6px; background: #fff; border: 1px solid #e2e8f0; padding: 2px;">
              </td>
              <td>
                <div style="font-weight: 700; color: #1e293b;"><?= htmlspecialchars($p['name']) ?></div>
                <div style="font-size: 11.5px; color: #64748b;">SKU: <?= htmlspecialchars($p['sku']) ?></div>
              </td>
              <td>
                <span style="font-size: 12.5px; font-weight: 600; color: #475569;"><?= htmlspecialchars($p['category_name']) ?></span>
              </td>
              <td style="font-weight: 600;"><?= formatRupiah($p['price']) ?></td>
              <td>
                <?php if (!empty($p['discount_price']) && $p['discount_price'] < $p['price']): ?>
                  <span style="color: #198754; font-weight: 700;"><?= formatRupiah($p['discount_price']) ?></span>
                <?php else: ?>
                  <span style="color: #94a3b8;">-</span>
                <?php endif; ?>
              </td>
              <td>
                <?php if ($isOut): ?>
                  <span class="status-badge badge-dibatalkan">Habis (0)</span>
                <?php elseif ($isLow): ?>
                  <span class="status-badge badge-menunggu-konfirmasi">Sisa <?= $p['stock'] ?> <?= htmlspecialchars($p['unit']) ?></span>
                <?php else: ?>
                  <span style="font-weight: 700; color: #198754;"><?= $p['stock'] ?></span> <span style="font-size: 11px; color: #64748b;"><?= htmlspecialchars($p['unit']) ?></span>
                <?php endif; ?>
              </td>
              <td>
                <?php if ($p['status'] == 1): ?>
                  <span class="status-badge badge-active">Aktif</span>
                <?php else: ?>
                  <span class="status-badge badge-inactive">Nonaktif</span>
                <?php endif; ?>
              </td>
              <td style="text-align: center;">
                <?= $p['is_featured'] ? '⭐' : '-' ?>
              </td>
              <td style="text-align: right; white-space: nowrap;">
                <a href="../../product-detail.php?slug=<?= urlencode($p['slug']) ?>" target="_blank" class="btn btn-secondary btn-sm" title="Lihat di web">
                  👁️
                </a>
                <a href="edit.php?id=<?= $p['id'] ?>" class="btn btn-primary btn-sm" title="Edit produk">
                  Edit
                </a>
                <a href="delete.php?id=<?= $p['id'] ?>&csrf_token=<?= generateCsrfToken() ?>" 
                   class="btn btn-danger btn-sm" 
                   data-confirm="Apakah Anda yakin ingin menghapus produk '<?= htmlspecialchars(addslashes($p['name'])) ?>'? Produk akan diarsipkan dengan aman tanpa merusak riwayat transaksi pesanan."
                   title="Hapus produk">
                  Hapus
                </a>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php else: ?>
          <tr>
            <td colspan="9" style="text-align: center; color: #64748b; padding: 28px;">
              Tidak ada produk yang sesuai dengan filter.
            </td>
          </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>

  <!-- Pagination -->
  <?php if ($totalPages > 1): ?>
    <div style="padding: 16px 20px; display: flex; justify-content: center; gap: 6px; border-top: 1px solid var(--admin-border);">
      <?php for ($i = 1; $i <= $totalPages; $i++): ?>
        <a href="index.php?<?= http_build_query(array_merge($_GET, ['page' => $i])) ?>" 
           class="btn btn-sm <?= $i === $page ? 'btn-primary' : 'btn-secondary' ?>">
          <?= $i ?>
        </a>
      <?php endfor; ?>
    </div>
  <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
