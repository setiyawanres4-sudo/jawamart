<?php
/**
 * JAWA MART - Export Laporan Penjualan Excel / CSV
 * File: admin/reports/export-excel.php
 */

declare(strict_types=1);

require_once __DIR__ . '/../../includes/auth.php';
requireAdminAuth();

$startDate = trim($_GET['start_date'] ?? date('Y-m-01'));
$endDate   = trim($_GET['end_date'] ?? date('Y-m-d'));

try {
    $stmt = $pdo->prepare("
        SELECT order_code, created_at, customer_name, customer_phone, customer_address, 
               subtotal, shipping_cost, total, status
        FROM orders
        WHERE status = 'Selesai'
          AND DATE(created_at) >= :sdate
          AND DATE(created_at) <= :edate
        ORDER BY id DESC
    ");
    $stmt->execute(['sdate' => $startDate, 'edate' => $endDate]);
    $orders = $stmt->fetchAll();

    $filename = "Laporan-Penjualan-JAWAMART_{$startDate}_sd_{$endDate}.csv";

    // Set headers untuk force download file CSV/Excel
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Pragma: no-cache');
    header('Expires: 0');

    $output = fopen('php://output', 'w');

    // Tulis UTF-8 BOM agar Excel menampilkan format karakter Indonesia dengan sempurna
    fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));

    // Judul & Periode
    fputcsv($output, ['LAPORAN PENJUALAN JAWA MART']);
    fputcsv($output, ['Periode:', $startDate . ' s/d ' . $endDate]);
    fputcsv($output, ['Filter Status:', 'Hanya Pesanan Selesai']);
    fputcsv($output, []); // Baris kosong

    // Header Kolom
    fputcsv($output, [
        'No',
        'Kode Pesanan',
        'Tanggal & Waktu',
        'Nama Pelanggan',
        'No WhatsApp',
        'Alamat Pengiriman',
        'Subtotal (Rp)',
        'Ongkos Kirim (Rp)',
        'Total Transaksi (Rp)',
        'Status'
    ]);

    $totalSubtotal = 0;
    $totalShipping = 0;
    $totalGrand    = 0;

    foreach ($orders as $idx => $row) {
        $totalSubtotal += (float)$row['subtotal'];
        $totalShipping += (float)$row['shipping_cost'];
        $totalGrand    += (float)$row['total'];

        fputcsv($output, [
            $idx + 1,
            $row['order_code'],
            $row['created_at'],
            $row['customer_name'],
            "'" . $row['customer_phone'], // Kutip agar angka 0 di depan tidak hilang di Excel
            str_replace(["\r", "\n"], " ", $row['customer_address']),
            $row['subtotal'],
            $row['shipping_cost'],
            $row['total'],
            $row['status']
        ]);
    }

    // Baris Total Akumulasi
    fputcsv($output, []);
    fputcsv($output, [
        '', '', '', '', '', 'TOTAL AKUMULASI:',
        $totalSubtotal,
        $totalShipping,
        $totalGrand,
        count($orders) . ' Transaksi Selesai'
    ]);

    fclose($output);
    exit;
} catch (Exception $e) {
    error_log("Error exporting report: " . $e->getMessage());
    die("Terjadi kesalahan saat mengekspor laporan: " . $e->getMessage());
}
