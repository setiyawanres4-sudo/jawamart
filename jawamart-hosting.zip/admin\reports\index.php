<?php
/**
 * JAWA MART - Laporan & Analisis Penjualan Sembako
 * File: admin/reports/index.php
 */

declare(strict_types=1);

$adminTitle = 'Laporan & Analisis Penjualan';
require_once __DIR__ . '/../includes/header.php';

// Parameter Filter Tanggal (PRD Section 9.2)
$preset = trim($_GET['preset'] ?? 'this_month');
$startDate = trim($_GET['start_date'] ?? '');
$endDate   = trim($_GET['end_date'] ?? '');

$today = date('Y-m-d');

if ($preset === 'today') {
    $startDate = $today;
    $endDate = $today;
} elseif ($preset === 'yesterday') {
    $startDate = date('Y-m-d', strtotime('-1 day'));
    $endDate = date('Y-m-d', strtotime('-1 day'));
} elseif ($preset === 'this_week') {
    $startDate = date('Y-m-d', strtotime('monday this week'));
    $endDate = $today;
} elseif ($preset === 'this_month') {
    $startDate = date('Y-m-01');
    $endDate = date('Y-m-t');
} elseif ($preset === 'last_month') {
    $startDate = date('Y-m-01', strtotime('first day of last month'));
    $endDate = date('Y-m-t', strtotime('last day of last month'));
} elseif ($preset === 'this_year') {
    $startDate = date('Y-01-01');
    $endDate = date('Y-12-31');
} elseif ($preset === 'custom') {
    if (empty($startDate)) $startDate = date('Y-m-01');
    if (empty($endDate)) $endDate = $today;
}

// 1. Metrik Utama Penjualan (Hanya Pesanan 'Selesai', PRD 9.1)
$totalRevenue   = 0.0;
$totalOrders    = 0;
$totalItemsSold = 0;
$avgOrderValue  = 0.0;

try {
    $stmtSummary = $pdo->prepare("
        SELECT 
            COALESCE(SUM(o.total), 0) AS total_revenue,
            COUNT(o.id) AS total_orders,
            COALESCE(SUM(oi.quantity), 0) AS total_items
        FROM orders o
        LEFT JOIN order_items oi ON oi.order_id = o.id
        WHERE o.status = 'Selesai'
          AND DATE(o.created_at) >= :sdate
          AND DATE(o.created_at) <= :edate
    ");
    $stmtSummary->execute(['sdate' => $startDate, 'edate' => $endDate]);
    $res = $stmtSummary->fetch();

    if ($res) {
        $totalRevenue = (float)$res['total_revenue'];
        $totalOrders  = (int)$res['total_orders'];
        $totalItemsSold = (int)$res['total_items'];
        $avgOrderValue = $totalOrders > 0 ? ($totalRevenue / $totalOrders) : 0.0;
    }
} catch (Exception $e) {
    error_log("Error report summary: " . $e->getMessage());
}

// 2. Produk Terlaris (Best Sellers)
$topProducts = [];
try {
    $stmtTop = $pdo->prepare("
        SELECT oi.product_name, oi.product_sku, oi.unit,
               SUM(oi.quantity) AS total_qty,
               SUM(oi.subtotal) AS total_amount
        FROM order_items oi
        JOIN orders o ON o.id = oi.order_id
        WHERE o.status = 'Selesai'
          AND DATE(o.created_at) >= :sdate
          AND DATE(o.created_at) <= :edate
        GROUP BY oi.product_name, oi.product_sku, oi.unit
        ORDER BY total_qty DESC
        LIMIT 5
    ");
    $stmtTop->execute(['sdate' => $startDate, 'edate' => $endDate]);
    $topProducts = $stmtTop->fetchAll();
} catch (Exception $e) {}

// 3. Produk Paling Sedikit Terjual
$leastProducts = [];
try {
    $stmtLeast = $pdo->prepare("
        SELECT oi.product_name, oi.product_sku, oi.unit,
               SUM(oi.quantity) AS total_qty,
               SUM(oi.subtotal) AS total_amount
        FROM order_items oi
        JOIN orders o ON o.id = oi.order_id
        WHERE o.status = 'Selesai'
          AND DATE(o.created_at) >= :sdate
          AND DATE(o.created_at) <= :edate
        GROUP BY oi.product_name, oi.product_sku, oi.unit
        ORDER BY total_qty ASC
        LIMIT 5
    ");
    $stmtLeast->execute(['sdate' => $startDate, 'edate' => $endDate]);
    $leastProducts = $stmtLeast->fetchAll();
} catch (Exception $e) {}

// 4. Daftar Transaksi Selesai Pada Periode
$reportOrders = [];
try {
    $stmtRo = $pdo->prepare("
        SELECT * FROM orders 
        WHERE status = 'Selesai'
          AND DATE(created_at) >= :sdate
          AND DATE(created_at) <= :edate
        ORDER BY id DESC
    ");
    $stmtRo->execute(['sdate' => $startDate, 'edate' => $endDate]);
    $reportOrders = $stmtRo->fetchAll();
} catch (Exception $e) {}
?>

<div class="page-header">
  <div>
    <h1 class="page-title">Laporan &amp; Analisis Penjualan</h1>
    <p class="page-subtitle">Rekapitulasi omzet, volume transaksi, dan performa penjualan sembako</p>
  </div>
  <div style="display: flex; gap: 10px;">
    <a href="export-excel.php?<?= http_build_query(['start_date' => $startDate, 'end_date' => $endDate]) ?>" class="btn btn-success">
      📥 Unduh Excel / CSV
    </a>
    <a href="print.php?<?= http_build_query(['start_date' => $startDate, 'end_date' => $endDate]) ?>" target="_blank" class="btn btn-secondary">
      🖨️ Cetak Laporan
    </a>
  </div>
</div>

<!-- Filter Bar (PRD Section 9.2) -->
<div class="admin-card" style="margin-bottom: 24px;">
  <div class="admin-card-body" style="padding: 16px;">
    <form action="index.php" method="GET" style="display: flex; gap: 12px; flex-wrap: wrap; align-items: center;">
      <div style="min-width: 180px;">
        <select name="preset" class="form-control" onchange="this.form.submit()">
          <option value="today" <?= $preset === 'today' ? 'selected' : '' ?>>Hari Ini</option>
          <option value="yesterday" <?= $preset === 'yesterday' ? 'selected' : '' ?>>Kemarin</option>
          <option value="this_week" <?= $preset === 'this_week' ? 'selected' : '' ?>>Minggu Ini</option>
          <option value="this_month" <?= $preset === 'this_month' ? 'selected' : '' ?>>Bulan Ini</option>
          <option value="last_month" <?= $preset === 'last_month' ? 'selected' : '' ?>>Bulan Sebelumnya</option>
          <option value="this_year" <?= $preset === 'this_year' ? 'selected' : '' ?>>Tahun Ini</option>
          <option value="custom" <?= $preset === 'custom' ? 'selected' : '' ?>>Rentang Tanggal Khusus</option>
        </select>
      </div>

      <div style="display: flex; align-items: center; gap: 6px;">
        <input type="date" name="start_date" class="form-control" value="<?= htmlspecialchars($startDate) ?>" required>
        <span style="color: #64748b;">s/d</span>
        <input type="date" name="end_date" class="form-control" value="<?= htmlspecialchars($endDate) ?>" required>
      </div>

      <input type="hidden" name="preset" value="custom">
      <button type="submit" class="btn btn-secondary">Terapkan Rentang</button>
      
      <div style="margin-left: auto; font-size: 13px; color: #64748b;">
        Periode aktif: <strong><?= formatDate($startDate, false) ?></strong> s/d <strong><?= formatDate($endDate, false) ?></strong>
      </div>
    </form>
  </div>
</div>

<!-- Statistik Laporan Grid (PRD Section 9.1) -->
<div class="stats-grid">
  <div class="stat-card">
    <div class="stat-card-info">
      <p>Total Omzet Penjualan</p>
      <h3 style="color: #198754; font-size: 22px;"><?= formatRupiah($totalRevenue) ?></h3>
      <small style="color: #64748b; font-size: 11px;">Pesanan status selesai</small>
    </div>
    <div class="stat-card-icon stat-icon-green">💰</div>
  </div>

  <div class="stat-card">
    <div class="stat-card-info">
      <p>Jumlah Transaksi</p>
      <h3><?= $totalOrders ?></h3>
      <small style="color: #64748b; font-size: 11px;">Pesanan berhasil</small>
    </div>
    <div class="stat-card-icon stat-icon-blue">🧾</div>
  </div>

  <div class="stat-card">
    <div class="stat-card-info">
      <p>Produk Terjual</p>
      <h3><?= $totalItemsSold ?></h3>
      <small style="color: #64748b; font-size: 11px;">Total kuantitas barang</small>
    </div>
    <div class="stat-card-icon stat-icon-purple">📦</div>
  </div>

  <div class="stat-card">
    <div class="stat-card-info">
      <p>Rata-rata Transaksi (AOV)</p>
      <h3 style="font-size: 18px;"><?= formatRupiah($avgOrderValue) ?></h3>
      <small style="color: #64748b; font-size: 11px;">Nilai rata-rata keranjang</small>
    </div>
    <div class="stat-card-icon stat-icon-yellow">📊</div>
  </div>
</div>

<!-- Produk Terlaris & Produk Paling Sedikit Terjual -->
<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 24px; margin-bottom: 24px;">
  
  <!-- Best Sellers -->
  <div class="admin-card">
    <div class="admin-card-header">
      <h3 class="admin-card-title">🏆 5 Produk Paling Laris Terjual</h3>
    </div>
    <div class="table-responsive">
      <table class="admin-table">
        <thead>
          <tr>
            <th>Produk</th>
            <th style="text-align: center;">Jumlah Terjual</th>
            <th style="text-align: right;">Total Nilai</th>
          </tr>
        </thead>
        <tbody>
          <?php if (!empty($topProducts)): ?>
            <?php foreach ($topProducts as $tp): ?>
              <tr>
                <td>
                  <div style="font-weight: 700; color: #1e293b;"><?= htmlspecialchars($tp['product_name']) ?></div>
                  <div style="font-size: 11px; color: #64748b;">SKU: <?= htmlspecialchars($tp['product_sku']) ?></div>
                </td>
                <td style="text-align: center;">
                  <strong style="color: #198754; font-size: 14px;"><?= $tp['total_qty'] ?></strong> <?= htmlspecialchars($tp['unit']) ?>
                </td>
                <td style="text-align: right; font-weight: 700;">
                  <?= formatRupiah($tp['total_amount']) ?>
                </td>
              </tr>
            <?php endforeach; ?>
          <?php else: ?>
            <tr><td colspan="3" style="text-align: center; color: #64748b; padding: 20px;">Belum ada data penjualan pada periode ini.</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>

  <!-- Least Sold -->
  <div class="admin-card">
    <div class="admin-card-header">
      <h3 class="admin-card-title">📉 5 Produk Paling Sedikit Terjual</h3>
    </div>
    <div class="table-responsive">
      <table class="admin-table">
        <thead>
          <tr>
            <th>Produk</th>
            <th style="text-align: center;">Jumlah Terjual</th>
            <th style="text-align: right;">Total Nilai</th>
          </tr>
        </thead>
        <tbody>
          <?php if (!empty($leastProducts)): ?>
            <?php foreach ($leastProducts as $lp): ?>
              <tr>
                <td>
                  <div style="font-weight: 700; color: #1e293b;"><?= htmlspecialchars($lp['product_name']) ?></div>
                  <div style="font-size: 11px; color: #64748b;">SKU: <?= htmlspecialchars($lp['product_sku']) ?></div>
                </td>
                <td style="text-align: center;">
                  <strong style="color: #b45309; font-size: 14px;"><?= $lp['total_qty'] ?></strong> <?= htmlspecialchars($lp['unit']) ?>
                </td>
                <td style="text-align: right; font-weight: 700;">
                  <?= formatRupiah($lp['total_amount']) ?>
                </td>
              </tr>
            <?php endforeach; ?>
          <?php else: ?>
            <tr><td colspan="3" style="text-align: center; color: #64748b; padding: 20px;">Belum ada data penjualan pada periode ini.</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>

</div>

<!-- Daftar Transaksi Selesai Table -->
<div class="admin-card">
  <div class="admin-card-header">
    <h3 class="admin-card-title">Rincian Transaksi Selesai Periode Ini</h3>
    <span style="font-size: 13px; color: #64748b;">Total: <?= count($reportOrders) ?> pesanan sukses</span>
  </div>
  <div class="table-responsive">
    <table class="admin-table">
      <thead>
        <tr>
          <th>Kode Pesanan</th>
          <th>Nama Pelanggan</th>
          <th>WhatsApp</th>
          <th>Subtotal</th>
          <th>Ongkos Kirim</th>
          <th>Total Omzet</th>
          <th>Waktu Transaksi</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php if (!empty($reportOrders)): ?>
          <?php foreach ($reportOrders as $ro): ?>
            <tr>
              <td>
                <a href="../orders/detail.php?id=<?= $ro['id'] ?>" style="font-weight: 800; color: #198754;">
                  <?= htmlspecialchars($ro['order_code']) ?>
                </a>
              </td>
              <td style="font-weight: 600;"><?= htmlspecialchars($ro['customer_name']) ?></td>
              <td><?= htmlspecialchars($ro['customer_phone']) ?></td>
              <td><?= formatRupiah($ro['subtotal']) ?></td>
              <td><?= $ro['shipping_cost'] > 0 ? formatRupiah($ro['shipping_cost']) : 'GRATIS' ?></td>
              <td><strong style="color: #198754;"><?= formatRupiah($ro['total']) ?></strong></td>
              <td style="color: #64748b; font-size: 12px;"><?= formatDate($ro['created_at']) ?></td>
              <td>
                <a href="../orders/detail.php?id=<?= $ro['id'] ?>" class="btn btn-secondary btn-sm">
                  Lihat Detail &rarr;
                </a>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php else: ?>
          <tr><td colspan="8" style="text-align: center; color: #64748b; padding: 24px;">Tidak ada pesanan dengan status 'Selesai' pada periode ini.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<style>
@media (max-width: 900px) {
  div[style*="grid-template-columns: 1fr 1fr"] {
    grid-template-columns: 1fr !important;
  }
}
</style>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
