<?php
/**
 * JAWA MART - Cetak Ringkasan Laporan Penjualan
 * File: admin/reports/print.php
 */

declare(strict_types=1);

require_once __DIR__ . '/../../includes/auth.php';
requireAdminAuth();

$startDate = trim($_GET['start_date'] ?? date('Y-m-01'));
$endDate   = trim($_GET['end_date'] ?? date('Y-m-d'));

$storeName = getSetting('store_name', 'JAWA MART');
$admin = getLoggedInAdmin();

$stmt = $pdo->prepare("
    SELECT * FROM orders
    WHERE status = 'Selesai'
      AND DATE(created_at) >= :sdate
      AND DATE(created_at) <= :edate
    ORDER BY id ASC
");
$stmt->execute(['sdate' => $startDate, 'edate' => $endDate]);
$orders = $stmt->fetchAll();

$totalRevenue = 0;
foreach ($orders as $o) {
    $totalRevenue += (float)$o['total'];
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Laporan Penjualan <?= htmlspecialchars($storeName) ?> (<?= $startDate ?> s/d <?= $endDate ?>)</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: Arial, sans-serif; font-size: 13px; color: #212529; background: #fff; padding: 25px; }
    .header { border-bottom: 2px solid #198754; padding-bottom: 12px; margin-bottom: 20px; }
    .header h1 { font-size: 20px; color: #198754; font-weight: 800; }
    .info-bar { margin-bottom: 20px; font-size: 13.5px; line-height: 1.6; }
    table { width: 100%; border-collapse: collapse; margin-bottom: 25px; font-size: 12.5px; }
    th { background: #e8f5e9; color: #0f5132; text-align: left; padding: 8px 10px; border: 1px solid #c3e6cb; }
    td { padding: 8px 10px; border: 1px solid #dee2e6; }
    .total-row { font-weight: bold; background: #f8fafc; }
    .btn-print { background: #198754; color: #fff; border: none; padding: 8px 18px; font-size: 13px; font-weight: bold; border-radius: 4px; cursor: pointer; margin-bottom: 20px; }
    @media print {
      .btn-print { display: none !important; }
      body { padding: 0; }
    }
  </style>
</head>
<body>

  <button onclick="window.print()" class="btn-print">🖨️ Cetak Dokumen</button>

  <div class="header">
    <h1>REKAPITULASI LAPORAN PENJUALAN — <?= htmlspecialchars($storeName) ?></h1>
    <p style="color: #64748b; font-size: 12px; margin-top: 4px;">Sistem Toko Online Sembako &amp; Kebutuhan Pokok</p>
  </div>

  <div class="info-bar">
    <div><strong>Periode Penjualan:</strong> <?= formatDate($startDate, false) ?> s/d <?= formatDate($endDate, false) ?></div>
    <div><strong>Filter Status:</strong> Hanya Pesanan Berstatus "Selesai"</div>
    <div><strong>Dicetak Oleh:</strong> <?= htmlspecialchars($admin['name'] ?? 'Administrator') ?> pada <?= date('d/m/Y H:i') ?> WIB</div>
  </div>

  <table>
    <thead>
      <tr>
        <th style="width: 30px;">No</th>
        <th>Kode Pesanan</th>
        <th>Tanggal</th>
        <th>Pelanggan</th>
        <th>No WhatsApp</th>
        <th style="text-align: right;">Subtotal</th>
        <th style="text-align: right;">Ongkir</th>
        <th style="text-align: right;">Total Nilai</th>
      </tr>
    </thead>
    <tbody>
      <?php if (!empty($orders)): ?>
        <?php foreach ($orders as $idx => $row): ?>
          <tr>
            <td><?= $idx + 1 ?></td>
            <td><strong><?= htmlspecialchars($row['order_code']) ?></strong></td>
            <td><?= date('d/m/Y H:i', strtotime($row['created_at'])) ?></td>
            <td><?= htmlspecialchars($row['customer_name']) ?></td>
            <td><?= htmlspecialchars($row['customer_phone']) ?></td>
            <td style="text-align: right;"><?= formatRupiah($row['subtotal']) ?></td>
            <td style="text-align: right;"><?= formatRupiah($row['shipping_cost']) ?></td>
            <td style="text-align: right; font-weight: bold;"><?= formatRupiah($row['total']) ?></td>
          </tr>
        <?php endforeach; ?>
        <tr class="total-row">
          <td colspan="7" style="text-align: right;">TOTAL OMZET PENJUALAN:</td>
          <td style="text-align: right; color: #198754; font-size: 14px;"><?= formatRupiah($totalRevenue) ?></td>
        </tr>
      <?php else: ?>
        <tr>
          <td colspan="8" style="text-align: center; color: #64748b; padding: 20px;">
            Tidak ada transaksi pesanan selesai pada periode tanggal ini.
          </td>
        </tr>
      <?php endif; ?>
    </tbody>
  </table>

  <div style="display: flex; justify-content: flex-end; margin-top: 40px;">
    <div style="text-align: center; width: 220px; font-size: 13px;">
      <p>Penanggung Jawab Toko,</p>
      <div style="height: 65px;"></div>
      <p style="font-weight: bold;">( <?= htmlspecialchars($admin['name'] ?? 'Administrator') ?> )</p>
    </div>
  </div>

</body>
</html>
