<?php
/**
 * JAWA MART - Penyesuaian / Restock Stok Barang
 * File: admin/stock/adjust.php
 */

declare(strict_types=1);

$adminTitle = 'Atur Penyesuaian Stok';
require_once __DIR__ . '/../includes/header.php';

$selectedPid = (int)($_GET['product_id'] ?? 0);
$products = $pdo->query("
    SELECT id, sku, name, stock, unit 
    FROM products 
    WHERE status = 1 AND deleted_at IS NULL 
    ORDER BY name ASC
")->fetchAll();

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['csrf_token'] ?? '';
    if (!verifyCsrfToken($token)) {
        $errors[] = 'Sesi form Anda telah kedaluwarsa. Silakan muat ulang halaman.';
    } else {
        $productId = (int)($_POST['product_id'] ?? 0);
        $type      = trim($_POST['adjustment_type'] ?? '');
        $qty       = (int)($_POST['quantity'] ?? 0);
        $note      = trim($_POST['note'] ?? '');

        if ($productId <= 0) $errors[] = 'Pilih produk yang ingin disesuaikan stoknya.';
        if (!in_array($type, ['add', 'subtract', 'set'], true)) $errors[] = 'Jenis penyesuaian stok tidak valid.';
        if ($qty <= 0 && $type !== 'set') $errors[] = 'Jumlah perubahan stok harus lebih besar dari 0.';
        if ($qty < 0 && $type === 'set') $errors[] = 'Stok tidak boleh bernilai negatif.';

        if (empty($errors)) {
            try {
                $pdo->beginTransaction();

                // Ambil stok saat ini dengan lock
                $stmtCheck = $pdo->prepare("SELECT id, name, sku, stock, unit FROM products WHERE id = :pid FOR UPDATE");
                $stmtCheck->execute(['pid' => $productId]);
                $prod = $stmtCheck->fetch();

                if (!$prod) {
                    throw new Exception('Produk tidak ditemukan di database.');
                }

                $stockBefore = (int)$prod['stock'];
                $stockAfter = $stockBefore;
                $movementType = '';
                $movementQty = $qty;

                if ($type === 'add') {
                    $stockAfter = $stockBefore + $qty;
                    $movementType = 'Penambahan Stok';
                } elseif ($type === 'subtract') {
                    if ($qty > $stockBefore) {
                        throw new Exception("Pengurangan stok ($qty) melebihi stok yang tersedia saat ini ($stockBefore).");
                    }
                    $stockAfter = $stockBefore - $qty;
                    $movementType = 'Pengurangan Stok';
                } elseif ($type === 'set') {
                    $stockAfter = $qty;
                    $movementType = 'Penyesuaian Stok';
                    $movementQty = abs($stockAfter - $stockBefore);
                }

                // Update Stok Produk
                $stmtUp = $pdo->prepare("UPDATE products SET stock = :s, updated_at = NOW() WHERE id = :id");
                $stmtUp->execute(['s' => $stockAfter, 'id' => $productId]);

                // Catat Riwayat Mutasi (PRD Section 8.5)
                recordStockMovement(
                    $pdo,
                    $productId,
                    $currentAdmin['id'] ?? 1,
                    null,
                    $movementType,
                    $movementQty,
                    $stockBefore,
                    $stockAfter,
                    $note ?: 'Penyesuaian stok manual oleh administrator'
                );

                $pdo->commit();
                setFlash('success', "Stok {$prod['name']} berhasil diperbarui menjadi {$stockAfter} {$prod['unit']}.");
                header('Location: index.php');
                exit;
            } catch (Exception $e) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }
                error_log("Stock adjustment error: " . $e->getMessage());
                $errors[] = $e->getMessage();
            }
        }
    }
}
?>

<div class="page-header">
  <div>
    <h1 class="page-title">Penyesuaian / Restock Stok Barang</h1>
    <p class="page-subtitle">Tambah stok masuk, catat barang susut/rusak, atau sinkronisasi stok fisik gudang</p>
  </div>
  <a href="index.php" class="btn btn-secondary">&larr; Kembali ke Riwayat Stok</a>
</div>

<?php if (!empty($errors)): ?>
  <div class="flash-alert danger">
    <div>
      <strong>Terjadi kesalahan:</strong>
      <ul style="margin-left: 20px; margin-top: 4px;">
        <?php foreach ($errors as $err): ?>
          <li><?= htmlspecialchars($err) ?></li>
        <?php endforeach; ?>
      </ul>
    </div>
  </div>
<?php endif; ?>

<div class="admin-card" style="max-width: 650px;">
  <div class="admin-card-body">
    <form action="adjust.php" method="POST">
      <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">

      <div class="form-group">
        <label class="form-label" for="product_id">Pilih Produk Sembako <span style="color:red;">*</span></label>
        <select name="product_id" id="product_id" class="form-control" required onchange="updateProductStockInfo(this)">
          <option value="">-- Pilih Produk --</option>
          <?php foreach ($products as $p): ?>
            <option value="<?= $p['id'] ?>" 
                    data-stock="<?= $p['stock'] ?>" 
                    data-unit="<?= htmlspecialchars($p['unit']) ?>"
                    <?= ($selectedPid === (int)$p['id'] || (($_POST['product_id'] ?? 0) == $p['id'])) ? 'selected' : '' ?>>
              <?= htmlspecialchars($p['name']) ?> (Stok saat ini: <?= $p['stock'] ?> <?= htmlspecialchars($p['unit']) ?>)
            </option>
          <?php endforeach; ?>
        </select>
      </div>

      <!-- Current Stock Badge Display -->
      <div id="currentStockDisplay" style="margin-bottom: 20px; background: #f8fafc; border: 1px solid #e2e8f0; padding: 12px 16px; border-radius: 8px;">
        <span>Stok saat ini: </span>
        <strong id="stockNumDisplay" style="color: #198754; font-size: 16px;">-</strong>
      </div>

      <div class="form-group">
        <label class="form-label" for="adjustment_type">Jenis Penyesuaian <span style="color:red;">*</span></label>
        <select name="adjustment_type" id="adjustment_type" class="form-control" required>
          <option value="add" <?= (($_POST['adjustment_type'] ?? '') === 'add') ? 'selected' : '' ?>>
            + Penambahan Stok (Barang Masuk / Restock Distributor)
          </option>
          <option value="subtract" <?= (($_POST['adjustment_type'] ?? '') === 'subtract') ? 'selected' : '' ?>>
            - Pengurangan Stok (Barang Rusak / Kadaluarsa / Retur)
          </option>
          <option value="set" <?= (($_POST['adjustment_type'] ?? '') === 'set') ? 'selected' : '' ?>>
            = Tetapkan Stok Baru (Hasil Stock Opname / Hitung Fisik)
          </option>
        </select>
      </div>

      <div class="form-group">
        <label class="form-label" for="quantity">Jumlah Perubahan / Nilai Baru <span style="color:red;">*</span></label>
        <input type="number" min="0" name="quantity" id="quantity" class="form-control" placeholder="Contoh: 20" required value="<?= htmlspecialchars($_POST['quantity'] ?? '') ?>">
      </div>

      <div class="form-group">
        <label class="form-label" for="note">Catatan / Alasan Perubahan</label>
        <input type="text" name="note" id="note" class="form-control" placeholder="Contoh: Kiriman stok baru dari gudang pusat / penyesuaian opname akhir bulan" value="<?= htmlspecialchars($_POST['note'] ?? '') ?>">
      </div>

      <div style="display: flex; gap: 12px; margin-top: 24px;">
        <button type="submit" class="btn btn-primary" style="padding: 10px 24px;">
          Simpan Penyesuaian Stok
        </button>
        <a href="index.php" class="btn btn-secondary">Batal</a>
      </div>
    </form>
  </div>
</div>

<script>
function updateProductStockInfo(select) {
  const opt = select.options[select.selectedIndex];
  if (opt && opt.value) {
    const stock = opt.getAttribute('data-stock') || '0';
    const unit = opt.getAttribute('data-unit') || 'pcs';
    document.getElementById('stockNumDisplay').textContent = stock + ' ' + unit;
  } else {
    document.getElementById('stockNumDisplay').textContent = '-';
  }
}
document.addEventListener('DOMContentLoaded', () => {
  const select = document.getElementById('product_id');
  if (select) updateProductStockInfo(select);
});
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
