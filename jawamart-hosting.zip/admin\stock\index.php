<?php
/**
 * JAWA MART - Manajemen Stok & Riwayat Mutasi
 * File: admin/stock/index.php
 */

declare(strict_types=1);

$adminTitle = 'Manajemen Stok & Mutasi';
require_once __DIR__ . '/../includes/header.php';

// Parameter Filter Log Mutasi
$filterProductId    = (int)($_GET['product_id'] ?? 0);
$filterMovementType = trim($_GET['movement_type'] ?? '');
$page               = max(1, (int)($_GET['page'] ?? 1));
$perPage            = 20;
$offset             = ($page - 1) * $perPage;

// 1. Ringkasan Kondisi Stok Seluruh Produk
$productsSummary = [];
try {
    $stmtProd = $pdo->query("
        SELECT id, sku, name, unit, stock, minimum_stock 
        FROM products 
        WHERE status = 1 AND deleted_at IS NULL 
        ORDER BY stock ASC, name ASC
    ");
    $productsSummary = $stmtProd->fetchAll();
} catch (Exception $e) {}

// 2. Query Riwayat Pergerakan Stok (stock_movements)
$whereLog = ["1=1"];
$logParams = [];

if ($filterProductId > 0) {
    $whereLog[] = "sm.product_id = :pid";
    $logParams['pid'] = $filterProductId;
}

if (!empty($filterMovementType)) {
    $whereLog[] = "sm.movement_type = :mtype";
    $logParams['mtype'] = $filterMovementType;
}

$whereLogSql = "WHERE " . implode(" AND ", $whereLog);

// Total Count
$stmtCount = $pdo->prepare("SELECT COUNT(*) FROM stock_movements sm $whereLogSql");
$stmtCount->execute($logParams);
$totalLogs = (int)$stmtCount->fetchColumn();
$totalPages = max(1, (int)ceil($totalLogs / $perPage));

// Ambil Riwayat Mutasi Stok
$sqlLogs = "
    SELECT sm.*, p.name AS product_name, p.sku AS product_sku, p.unit AS product_unit,
           COALESCE(a.name, 'Sistem / Pelanggan') AS admin_name,
           o.order_code
    FROM stock_movements sm
    JOIN products p ON p.id = sm.product_id
    LEFT JOIN admins a ON a.id = sm.admin_id
    LEFT JOIN orders o ON o.id = sm.order_id
    $whereLogSql
    ORDER BY sm.id DESC
    LIMIT $perPage OFFSET $offset
";
$stmtLogs = $pdo->prepare($sqlLogs);
$stmtLogs->execute($logParams);
$stockLogs = $stmtLogs->fetchAll();

// Movement Types list for filter
$movementTypes = [
    'Stok Awal',
    'Penambahan Stok',
    'Pengurangan Stok',
    'Penyesuaian Stok',
    'Pengurangan karena Pesanan',
    'Pengembalian karena Pembatalan'
];
?>

<div class="page-header">
  <div>
    <h1 class="page-title">Manajemen Stok &amp; Riwayat Mutasi</h1>
    <p class="page-subtitle">Pantau stok fisik barang, lakukan penyesuaian/restock, dan telusuri riwayat mutasi stok</p>
  </div>
  <a href="adjust.php" class="btn btn-primary">
    + Penyesuaian / Tambah Stok Baru
  </a>
</div>

<!-- Tabs / Split Layout: Ringkasan Stok & Riwayat Mutasi -->
<div style="display: grid; grid-template-columns: 1fr; gap: 24px;">
  
  <!-- Section 1: Overview Stok Produk -->
  <div class="admin-card">
    <div class="admin-card-header">
      <h3 class="admin-card-title">Kondisi Stok Produk Aktif (Diurutkan dari Stok Paling Menipis)</h3>
      <a href="adjust.php" class="btn btn-secondary btn-sm">Restock Barang &rarr;</a>
    </div>

    <div class="table-responsive" style="max-height: 380px; overflow-y: auto;">
      <table class="admin-table">
        <thead style="position: sticky; top: 0; background: #f8fafc; z-index: 2;">
          <tr>
            <th>SKU</th>
            <th>Nama Produk Sembako</th>
            <th>Stok Saat Ini</th>
            <th>Batas Minimum</th>
            <th>Status Peringatan</th>
            <th style="text-align: right;">Aksi Cepat</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($productsSummary as $ps): ?>
            <?php 
              $isOut = $ps['stock'] <= 0;
              $isLow = !$isOut && $ps['stock'] <= $ps['minimum_stock'];
            ?>
            <tr style="<?= $isOut ? 'background: #fff5f5;' : ($isLow ? 'background: #fffdf5;' : '') ?>">
              <td><code style="font-size: 12px;"><?= htmlspecialchars($ps['sku']) ?></code></td>
              <td style="font-weight: 700; color: #1e293b;"><?= htmlspecialchars($ps['name']) ?></td>
              <td>
                <strong style="font-size: 15px; color: <?= $isOut ? '#dc3545' : ($isLow ? '#b45309' : '#198754') ?>;">
                  <?= $ps['stock'] ?>
                </strong>
                <span style="font-size: 12px; color: #64748b;"><?= htmlspecialchars($ps['unit']) ?></span>
              </td>
              <td><?= $ps['minimum_stock'] ?> <?= htmlspecialchars($ps['unit']) ?></td>
              <td>
                <?php if ($isOut): ?>
                  <span class="status-badge badge-dibatalkan">⚠️ Habis (0)</span>
                <?php elseif ($isLow): ?>
                  <span class="status-badge badge-menunggu-konfirmasi">⚠️ Menipis (&le; Min)</span>
                <?php else: ?>
                  <span class="status-badge badge-selesai">✓ Aman</span>
                <?php endif; ?>
              </td>
              <td style="text-align: right;">
                <a href="adjust.php?product_id=<?= $ps['id'] ?>" class="btn btn-secondary btn-sm" title="Sesuaikan Stok">
                  Atur Stok &rarr;
                </a>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>

  <!-- Section 2: Log Riwayat Mutasi Stok (PRD Section 8.5 & 10.10) -->
  <div class="admin-card">
    <div class="admin-card-header">
      <h3 class="admin-card-title">Riwayat Lengkap Pergerakan Stok (Audit Trail)</h3>
      <span style="font-size: 12.5px; color: #64748b;">Total: <?= $totalLogs ?> catatan</span>
    </div>

    <!-- Filter Form -->
    <div style="padding: 16px; border-bottom: 1px solid var(--admin-border); background: #f8fafc;">
      <form action="index.php" method="GET" style="display: flex; gap: 12px; flex-wrap: wrap; align-items: center;">
        <div style="flex: 1; min-width: 220px;">
          <select name="product_id" class="form-control" onchange="this.form.submit()">
            <option value="">-- Semua Produk --</option>
            <?php foreach ($productsSummary as $ps): ?>
              <option value="<?= $ps['id'] ?>" <?= $filterProductId === (int)$ps['id'] ? 'selected' : '' ?>>
                <?= htmlspecialchars($ps['name']) ?> (<?= htmlspecialchars($ps['sku']) ?>)
              </option>
            <?php endforeach; ?>
          </select>
        </div>

        <div style="min-width: 200px;">
          <select name="movement_type" class="form-control" onchange="this.form.submit()">
            <option value="">-- Semua Jenis Transaksi Stok --</option>
            <?php foreach ($movementTypes as $mt): ?>
              <option value="<?= $mt ?>" <?= $filterMovementType === $mt ? 'selected' : '' ?>><?= $mt ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <button type="submit" class="btn btn-secondary">Filter Riwayat</button>
        <?php if ($filterProductId > 0 || !empty($filterMovementType)): ?>
          <a href="index.php" class="btn btn-secondary" style="color: #dc3545;">Reset</a>
        <?php endif; ?>
      </form>
    </div>

    <div class="table-responsive">
      <table class="admin-table">
        <thead>
          <tr>
            <th>Waktu</th>
            <th>Produk</th>
            <th>Jenis Transaksi Stok</th>
            <th>Jumlah Perubahan</th>
            <th>Stok Sebelum</th>
            <th>Stok Sesudah</th>
            <th>Catatan / Order</th>
            <th>Petugas / Eksekutor</th>
          </tr>
        </thead>
        <tbody>
          <?php if (!empty($stockLogs)): ?>
            <?php foreach ($stockLogs as $log): ?>
              <?php 
                $isPlus = str_contains($log['movement_type'], 'Tambah') || str_contains($log['movement_type'], 'Awal') || str_contains($log['movement_type'], 'Pengembalian');
                $isMinus = str_contains($log['movement_type'], 'Kurang') || str_contains($log['movement_type'], 'Pesanan');
              ?>
              <tr>
                <td style="color: #64748b; font-size: 12px; white-space: nowrap;">
                  <?= formatDate($log['created_at']) ?>
                </td>
                <td>
                  <div style="font-weight: 700; color: #1e293b;"><?= htmlspecialchars($log['product_name']) ?></div>
                  <div style="font-size: 11px; color: #64748b;">SKU: <?= htmlspecialchars($log['product_sku']) ?></div>
                </td>
                <td>
                  <span class="status-badge" style="background: #e2e8f0; color: #1e293b; font-size: 11.5px;">
                    <?= htmlspecialchars($log['movement_type']) ?>
                  </span>
                </td>
                <td>
                  <strong style="color: <?= $isPlus ? '#198754' : ($isMinus ? '#dc3545' : '#1e293b') ?>; font-size: 14.5px;">
                    <?= $isPlus ? '+' : ($isMinus ? '-' : '') ?><?= abs($log['quantity']) ?>
                  </strong>
                  <span style="font-size: 11px; color: #64748b;"><?= htmlspecialchars($log['product_unit']) ?></span>
                </td>
                <td style="color: #64748b;"><?= $log['stock_before'] ?></td>
                <td><strong style="color: #198754;"><?= $log['stock_after'] ?></strong></td>
                <td style="font-size: 12.5px; color: #475569;">
                  <?= htmlspecialchars($log['note'] ?? '-') ?>
                  <?php if (!empty($log['order_code'])): ?>
                    <br><a href="../orders/detail.php?code=<?= urlencode($log['order_code']) ?>" style="color: #198754; font-weight: 700;">Pesanan #<?= htmlspecialchars($log['order_code']) ?></a>
                  <?php endif; ?>
                </td>
                <td style="font-size: 12.5px; color: #475569;">
                  <?= htmlspecialchars($log['admin_name']) ?>
                </td>
              </tr>
            <?php endforeach; ?>
          <?php else: ?>
            <tr>
              <td colspan="8" style="text-align: center; color: #64748b; padding: 24px;">
                Belum ada catatan mutasi stok untuk filter ini.
              </td>
            </tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>

    <!-- Pagination -->
    <?php if ($totalPages > 1): ?>
      <div style="padding: 16px 20px; display: flex; justify-content: center; gap: 6px; border-top: 1px solid var(--admin-border);">
        <?php for ($i = 1; $i <= $totalPages; $i++): ?>
          <a href="index.php?<?= http_build_query(array_merge($_GET, ['page' => $i])) ?>" 
             class="btn btn-sm <?= $i === $page ? 'btn-primary' : 'btn-secondary' ?>">
            <?= $i ?>
          </a>
        <?php endfor; ?>
      </div>
    <?php endif; ?>
  </div>

</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
