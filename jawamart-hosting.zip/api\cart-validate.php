<?php
/**
 * JAWA MART - API Validasi Keranjang Real-Time
 * File: api/cart-validate.php
 */

declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../includes/functions.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Metode HTTP tidak diizinkan.']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$items = $input['items'] ?? [];

if (!is_array($items) || empty($items)) {
    echo json_encode([
        'success' => true,
        'valid'   => true,
        'items'   => [],
        'subtotal'=> 0
    ]);
    exit;
}

try {
    $productIds = array_column($items, 'id');
    $placeholders = implode(',', array_fill(0, count($productIds), '?'));

    $stmt = $pdo->prepare("
        SELECT id, name, sku, price, discount_price, stock, unit, image, status, deleted_at 
        FROM products 
        WHERE id IN ($placeholders)
    ");
    $stmt->execute($productIds);
    $dbProducts = [];
    while ($row = $stmt->fetch()) {
        $dbProducts[$row['id']] = $row;
    }

    $verifiedItems = [];
    $subtotal = 0.0;
    $hasIssues = false;
    $messages = [];

    foreach ($items as $item) {
        $id = (int)($item['id'] ?? 0);
        $qty = max(1, (int)($item['quantity'] ?? 1));

        if (!isset($dbProducts[$id]) || $dbProducts[$id]['status'] != 1 || $dbProducts[$id]['deleted_at'] !== null) {
            $hasIssues = true;
            $messages[] = "Produk '" . ($item['name'] ?? 'Pilihan') . "' sudah tidak tersedia.";
            continue;
        }

        $p = $dbProducts[$id];
        $effectivePrice = (!empty($p['discount_price']) && $p['discount_price'] < $p['price']) 
            ? (float)$p['discount_price'] 
            : (float)$p['price'];

        $stock = (int)$p['stock'];

        if ($qty > $stock) {
            $hasIssues = true;
            $messages[] = "Stok untuk '{$p['name']}' tersisa {$stock} {$p['unit']}.";
            $qty = $stock; // sesuaikan ke stok maksimal
        }

        if ($qty > 0) {
            $itemSubtotal = $effectivePrice * $qty;
            $subtotal += $itemSubtotal;

            $verifiedItems[] = [
                'id'       => (int)$p['id'],
                'name'     => $p['name'],
                'sku'      => $p['sku'],
                'price'    => $effectivePrice,
                'stock'    => $stock,
                'unit'     => $p['unit'],
                'image'    => $p['image'],
                'quantity' => $qty,
                'subtotal' => $itemSubtotal
            ];
        }
    }

    echo json_encode([
        'success'  => true,
        'valid'    => !$hasIssues,
        'messages' => $messages,
        'items'    => $verifiedItems,
        'subtotal' => $subtotal
    ], JSON_UNESCAPED_UNICODE);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Terjadi kesalahan sistem saat memvalidasi keranjang.'
    ]);
}
