/**
 * JAWA MART - Admin Dashboard JavaScript
 * Zero external dependencies
 */

document.addEventListener('DOMContentLoaded', () => {
  // Mobile sidebar toggle
  const toggleBtn = document.querySelector('.sidebar-toggle-btn');
  const sidebar = document.querySelector('.admin-sidebar');

  if (toggleBtn && sidebar) {
    toggleBtn.addEventListener('click', () => {
      sidebar.classList.toggle('show');
    });

    // Close when clicking outside on mobile
    document.addEventListener('click', (e) => {
      if (window.innerWidth <= 768 && 
          !sidebar.contains(e.target) && 
          !toggleBtn.contains(e.target) && 
          sidebar.classList.contains('show')) {
        sidebar.classList.remove('show');
      }
    });
  }

  // File Upload Image Preview
  const imageInputs = document.querySelectorAll('input[type="file"][data-preview]');
  imageInputs.forEach(input => {
    input.addEventListener('change', function () {
      const targetId = this.getAttribute('data-preview');
      const previewImg = document.getElementById(targetId);
      if (previewImg && this.files && this.files[0]) {
        const reader = new FileReader();
        reader.onload = function (e) {
          previewImg.src = e.target.result;
        };
        reader.readAsDataURL(this.files[0]);
      }
    });
  });

  // Confirm Actions
  const confirmElements = document.querySelectorAll('[data-confirm]');
  confirmElements.forEach(el => {
    el.addEventListener('click', function (e) {
      const msg = this.getAttribute('data-confirm') || 'Apakah Anda yakin ingin melanjutkan tindakan ini?';
      if (!confirm(msg)) {
        e.preventDefault();
        return false;
      }
    });
  });

  // Initialize Canvas Sales Chart if canvas exists
  const chartCanvas = document.getElementById('salesChartCanvas');
  if (chartCanvas && window.salesChartData) {
    renderSalesChart(chartCanvas, window.salesChartData);
  }
});

/**
 * Render lightweight responsive HTML5 canvas bar/line chart
 */
function renderSalesChart(canvas, data) {
  const ctx = canvas.getContext('2d');
  const width = canvas.width = canvas.parentElement.clientWidth || 800;
  const height = canvas.height = 260;

  const labels = data.labels || [];
  const values = data.values || [];

  if (labels.length === 0 || values.length === 0) {
    ctx.font = '14px sans-serif';
    ctx.fillStyle = '#64748b';
    ctx.textAlign = 'center';
    ctx.fillText('Belum ada data transaksi penjualan pada periode ini.', width / 2, height / 2);
    return;
  }

  const paddingLeft = 60;
  const paddingRight = 20;
  const paddingTop = 25;
  const paddingBottom = 40;

  const plotWidth = width - paddingLeft - paddingRight;
  const plotHeight = height - paddingTop - paddingBottom;

  const maxValue = Math.max(...values, 100000);
  const roundedMax = Math.ceil(maxValue / 50000) * 50000;

  // Clear
  ctx.clearRect(0, 0, width, height);

  // Draw Grid Lines & Y Axis Labels
  const gridLines = 4;
  ctx.strokeStyle = '#e2e8f0';
  ctx.lineWidth = 1;
  ctx.font = '11px sans-serif';
  ctx.fillStyle = '#64748b';
  ctx.textAlign = 'right';

  for (let i = 0; i <= gridLines; i++) {
    const yVal = (roundedMax / gridLines) * i;
    const yPos = paddingTop + plotHeight - (plotHeight / gridLines) * i;

    ctx.beginPath();
    ctx.moveTo(paddingLeft, yPos);
    ctx.lineTo(width - paddingRight, yPos);
    ctx.stroke();

    const formattedVal = yVal >= 1000000 
      ? (yVal / 1000000).toFixed(1) + 'M' 
      : (yVal >= 1000 ? (yVal / 1000).toFixed(0) + 'k' : yVal);
    ctx.fillText(formattedVal, paddingLeft - 8, yPos + 4);
  }

  // Draw Bars
  const barSpacing = plotWidth / labels.length;
  const barWidth = Math.min(barSpacing * 0.55, 40);

  labels.forEach((label, i) => {
    const val = values[i] || 0;
    const barHeight = (val / roundedMax) * plotHeight;
    const xPos = paddingLeft + (i * barSpacing) + (barSpacing - barWidth) / 2;
    const yPos = paddingTop + plotHeight - barHeight;

    // Bar fill
    ctx.fillStyle = '#198754';
    ctx.beginPath();
    ctx.roundRect 
      ? ctx.roundRect(xPos, yPos, barWidth, barHeight, [4, 4, 0, 0])
      : ctx.rect(xPos, yPos, barWidth, barHeight);
    ctx.fill();

    // X Label
    ctx.fillStyle = '#475569';
    ctx.textAlign = 'center';
    ctx.fillText(label, xPos + barWidth / 2, height - 15);
  });
}
