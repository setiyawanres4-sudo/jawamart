/**
 * JAWA MART - Shopping Cart Engine (LocalStorage + Event-Driven)
 * PRD Section 4.5 Compliance
 */

const JawaCart = (() => {
  const STORAGE_KEY = 'jawa_mart_cart_v2';

  // Read items from LocalStorage
  const getCart = () => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      return stored ? JSON.parse(stored) : [];
    } catch (e) {
      console.error('Error reading cart from localStorage', e);
      return [];
    }
  };

  // Save items to LocalStorage and trigger event
  const saveCart = (items) => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
      notifyCartUpdated();
    } catch (e) {
      console.error('Error saving cart to localStorage', e);
    }
  };

  const notifyCartUpdated = () => {
    updateBadges();
    window.dispatchEvent(new CustomEvent('jawa_cart:updated', { detail: { cart: getCart() } }));
  };

  // Update header and navigation cart counters
  const updateBadges = () => {
    const items = getCart();
    const totalCount = items.reduce((sum, item) => sum + (parseInt(item.quantity) || 1), 0);
    const badges = document.querySelectorAll('.cart-badge, [data-cart-count]');
    badges.forEach(badge => {
      badge.textContent = totalCount;
      if (totalCount > 0) {
        badge.style.display = 'inline-block';
      } else {
        badge.style.display = 'none';
      }
    });
  };

  // Add Item to cart
  const addItem = (product, quantity = 1) => {
    quantity = parseInt(quantity) || 1;
    const items = getCart();
    const existingIndex = items.findIndex(item => item.id == product.id);

    const availableStock = parseInt(product.stock) || 0;
    if (availableStock <= 0) {
      showToast('Stok produk ini sedang habis.', 'danger');
      return false;
    }

    if (existingIndex > -1) {
      const newQty = items[existingIndex].quantity + quantity;
      if (newQty > availableStock) {
        items[existingIndex].quantity = availableStock;
        saveCart(items);
        showToast(`Maksimal stok tercapai (${availableStock} ${product.unit || 'pcs'}).`, 'warning');
        return true;
      }
      items[existingIndex].quantity = newQty;
    } else {
      if (quantity > availableStock) {
        quantity = availableStock;
        showToast(`Jumlah disesuaikan dengan stok tersedia (${availableStock} ${product.unit || 'pcs'}).`, 'warning');
      }
      items.push({
        id: product.id,
        name: product.name,
        price: parseFloat(product.price),
        unit: product.unit || 'pcs',
        image: product.image || 'assets/images/placeholder.svg',
        stock: availableStock,
        sku: product.sku || '',
        quantity: quantity
      });
    }

    saveCart(items);
    showToast(`"${product.name}" berhasil ditambahkan ke keranjang!`, 'success');
    return true;
  };

  // Update Item Quantity
  const updateQuantity = (productId, newQuantity) => {
    newQuantity = parseInt(newQuantity);
    let items = getCart();
    const itemIndex = items.findIndex(item => item.id == productId);

    if (itemIndex > -1) {
      const item = items[itemIndex];
      const maxStock = parseInt(item.stock) || 999;

      if (newQuantity <= 0) {
        return removeItem(productId);
      } else if (newQuantity > maxStock) {
        items[itemIndex].quantity = maxStock;
        showToast(`Jumlah tidak boleh melebihi stok yang tersedia (${maxStock} ${item.unit}).`, 'warning');
      } else {
        items[itemIndex].quantity = newQuantity;
      }
      saveCart(items);
    }
  };

  // Remove Item
  const removeItem = (productId) => {
    let items = getCart();
    items = items.filter(item => item.id != productId);
    saveCart(items);
    showToast('Produk dihapus dari keranjang.', 'info');
  };

  // Clear Cart
  const clear = () => {
    localStorage.removeItem(STORAGE_KEY);
    notifyCartUpdated();
  };

  // Calculate Subtotal
  const getSubtotal = () => {
    const items = getCart();
    return items.reduce((total, item) => total + (item.price * item.quantity), 0);
  };

  // Toast Notification Helper
  const showToast = (message, type = 'success') => {
    let toastContainer = document.getElementById('toast-container');
    if (!toastContainer) {
      toastContainer = document.createElement('div');
      toastContainer.id = 'toast-container';
      toastContainer.style.position = 'fixed';
      toastContainer.style.bottom = '24px';
      toastContainer.style.left = '24px';
      toastContainer.style.zIndex = '9999';
      toastContainer.style.display = 'flex';
      toastContainer.style.flexDirection = 'column';
      toastContainer.style.gap = '8px';
      document.body.appendChild(toastContainer);
    }

    const toast = document.createElement('div');
    toast.className = `cart-toast toast-${type}`;
    toast.style.padding = '12px 18px';
    toast.style.borderRadius = '8px';
    toast.style.fontSize = '14px';
    toast.style.fontWeight = '600';
    toast.style.boxShadow = '0 4px 12px rgba(0,0,0,0.15)';
    toast.style.transition = 'all 0.3s ease';
    toast.style.display = 'flex';
    toast.style.alignItems = 'center';
    toast.style.gap = '8px';

    if (type === 'success') {
      toast.style.backgroundColor = '#198754';
      toast.style.color = '#ffffff';
    } else if (type === 'warning') {
      toast.style.backgroundColor = '#ffc107';
      toast.style.color = '#212529';
    } else if (type === 'danger') {
      toast.style.backgroundColor = '#dc3545';
      toast.style.color = '#ffffff';
    } else {
      toast.style.backgroundColor = '#0d6efd';
      toast.style.color = '#ffffff';
    }

    toast.textContent = message;
    toastContainer.appendChild(toast);

    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateY(10px)';
      setTimeout(() => toast.remove(), 300);
    }, 3200);
  };

  // Init badge on page load
  document.addEventListener('DOMContentLoaded', updateBadges);

  return {
    getItems: getCart,
    addItem,
    updateQuantity,
    removeItem,
    clear,
    getSubtotal,
    updateBadges,
    showToast
  };
})();
