<?php
/**
 * JAWA MART - Database Configuration
 * Platform: PHP 8.1+ & MySQL / MariaDB (PDO)
 * File: config/database.php
 */

declare(strict_types=1);

// Prevent direct execution outside of PHP include if desired
if (!defined('JAWA_MART_APP') && basename($_SERVER['PHP_SELF']) === 'database.php') {
    http_response_code(403);
    exit('Akses langsung ditolak.');
}

// Konfigurasi Database - Sesuaikan dengan kredensial cPanel / Localhost Anda
$db_config = [
    'host'     => getenv('DB_HOST')     ?: 'localhost',
    'port'     => getenv('DB_PORT')     ?: '3306',
    'dbname'   => getenv('DB_NAME')     ?: 'jawa_mart',
    'username' => getenv('DB_USER')     ?: 'root',
    'password' => getenv('DB_PASS') !== false ? getenv('DB_PASS') : '',
    'charset'  => 'utf8mb4'
];

/**
 * Mendapatkan instance koneksi database PDO (Singleton)
 *
 * @return PDO
 */
function getDBConnection(): PDO {
    static $pdoInstance = null;

    if ($pdoInstance !== null) {
        return $pdoInstance;
    }

    global $db_config;

    $dsn = sprintf(
        "mysql:host=%s;port=%s;dbname=%s;charset=%s",
        $db_config['host'],
        $db_config['port'],
        $db_config['dbname'],
        $db_config['charset']
    );

    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
        PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci"
    ];

    try {
        $pdoInstance = new PDO($dsn, $db_config['username'], $db_config['password'], $options);
        return $pdoInstance;
    } catch (PDOException $e) {
        // Jangan tampilkan detail kredensial ke pengunjung publik
        error_log("Database connection error: " . $e->getMessage());
        
        // Cek jika request adalah API / JSON
        if (!empty($_SERVER['HTTP_ACCEPT']) && str_contains($_SERVER['HTTP_ACCEPT'], 'application/json')) {
            http_response_code(500);
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode([
                'success' => false,
                'message' => 'Gagal terhubung ke database. Pastikan konfigurasi database sudah benar.'
            ], JSON_UNESCAPED_UNICODE);
            exit;
        }

        die("
            <div style='font-family: -apple-system, BlinkMacSystemFont, Segoe UI, Roboto, Helvetica, Arial, sans-serif; max-width: 600px; margin: 60px auto; padding: 25px; border: 1px solid #ffccd5; background: #fff5f7; border-radius: 8px; color: #842029;'>
                <h2 style='margin-top: 0;'>Koneksi Database JAWA MART Belum Siap</h2>
                <p>Website belum dapat terhubung ke database MySQL. Silakan periksa pengaturan database pada file <code>config/database.php</code> atau pastikan database <strong>jawa_mart</strong> sudah dibuat dan file <code>database/jawa_mart.sql</code> sudah diimpor.</p>
                <hr style='border: none; border-top: 1px solid #ffd6de; margin: 15px 0;'>
                <small style='color: #6c757d;'>Pesan teknis: " . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8') . "</small>
            </div>
        ");
    }
}

// Inisialisasi variabel global $pdo agar mudah digunakan di seluruh skrip
$pdo = getDBConnection();
