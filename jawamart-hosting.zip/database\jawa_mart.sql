-- JAWA MART Database Schema & Seed Data
-- Version: 2.0
-- Charset: utf8mb4, Engine: InnoDB
-- Compatible with MySQL 8.0+ and MariaDB
-- Note: Does NOT include CREATE DATABASE or USE statements for smooth cPanel / phpMyAdmin import

SET FOREIGN_KEY_CHECKS = 0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+07:00";

-- --------------------------------------------------------
-- Table: admins
-- --------------------------------------------------------
DROP TABLE IF EXISTS `admins`;
CREATE TABLE `admins` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(150) NOT NULL,
  `username` VARCHAR(100) NOT NULL,
  `email` VARCHAR(150) NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  `role` VARCHAR(30) NOT NULL DEFAULT 'admin',
  `status` TINYINT NOT NULL DEFAULT 1,
  `last_login` DATETIME NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_admins_username` (`username`),
  UNIQUE KEY `uk_admins_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table: categories
-- --------------------------------------------------------
DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(150) NOT NULL,
  `slug` VARCHAR(180) NOT NULL,
  `description` TEXT NULL,
  `image` VARCHAR(255) NULL,
  `status` TINYINT NOT NULL DEFAULT 1,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_categories_slug` (`slug`),
  KEY `idx_categories_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table: products
-- --------------------------------------------------------
DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `category_id` BIGINT UNSIGNED NOT NULL,
  `sku` VARCHAR(100) NOT NULL,
  `name` VARCHAR(255) NOT NULL,
  `slug` VARCHAR(255) NOT NULL,
  `description` TEXT,
  `price` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `discount_price` DECIMAL(12,2) NULL DEFAULT NULL,
  `stock` INT NOT NULL DEFAULT 0,
  `minimum_stock` INT NOT NULL DEFAULT 5,
  `unit` VARCHAR(50) NOT NULL DEFAULT 'pcs',
  `image` VARCHAR(255) NULL,
  `is_featured` TINYINT NOT NULL DEFAULT 0,
  `status` TINYINT NOT NULL DEFAULT 1,
  `deleted_at` TIMESTAMP NULL DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_products_sku` (`sku`),
  UNIQUE KEY `uk_products_slug` (`slug`),
  KEY `idx_products_category_id` (`category_id`),
  KEY `idx_products_status` (`status`),
  KEY `idx_products_is_featured` (`is_featured`),
  KEY `idx_products_deleted_at` (`deleted_at`),
  CONSTRAINT `fk_products_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table: product_images
-- --------------------------------------------------------
DROP TABLE IF EXISTS `product_images`;
CREATE TABLE `product_images` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `product_id` BIGINT UNSIGNED NOT NULL,
  `image` VARCHAR(255) NOT NULL,
  `is_primary` TINYINT NOT NULL DEFAULT 0,
  `sort_order` INT NOT NULL DEFAULT 0,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_product_images_product_id` (`product_id`),
  CONSTRAINT `fk_product_images_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table: orders
-- --------------------------------------------------------
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `order_code` VARCHAR(50) NOT NULL,
  `customer_name` VARCHAR(150) NOT NULL,
  `customer_phone` VARCHAR(30) NOT NULL,
  `customer_address` TEXT NOT NULL,
  `customer_note` TEXT NULL,
  `subtotal` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `shipping_cost` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `total` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `status` VARCHAR(40) NOT NULL DEFAULT 'Menunggu Konfirmasi',
  `stock_deducted` TINYINT NOT NULL DEFAULT 0,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_orders_order_code` (`order_code`),
  KEY `idx_orders_status` (`status`),
  KEY `idx_orders_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table: order_items
-- --------------------------------------------------------
DROP TABLE IF EXISTS `order_items`;
CREATE TABLE `order_items` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `order_id` BIGINT UNSIGNED NOT NULL,
  `product_id` BIGINT UNSIGNED NULL DEFAULT NULL,
  `product_name` VARCHAR(255) NOT NULL,
  `product_sku` VARCHAR(100) NOT NULL,
  `product_image` VARCHAR(255) NULL,
  `unit` VARCHAR(50) NOT NULL DEFAULT 'pcs',
  `quantity` INT NOT NULL DEFAULT 1,
  `unit_price` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `subtotal` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_order_items_order_id` (`order_id`),
  KEY `idx_order_items_product_id` (`product_id`),
  CONSTRAINT `fk_order_items_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_order_items_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table: order_status_history
-- --------------------------------------------------------
DROP TABLE IF EXISTS `order_status_history`;
CREATE TABLE `order_status_history` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `order_id` BIGINT UNSIGNED NOT NULL,
  `admin_id` BIGINT UNSIGNED NULL DEFAULT NULL,
  `old_status` VARCHAR(40) NULL DEFAULT NULL,
  `new_status` VARCHAR(40) NOT NULL,
  `note` TEXT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_order_status_history_order_id` (`order_id`),
  KEY `idx_order_status_history_admin_id` (`admin_id`),
  CONSTRAINT `fk_order_history_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_order_history_admin` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table: stock_movements
-- --------------------------------------------------------
DROP TABLE IF EXISTS `stock_movements`;
CREATE TABLE `stock_movements` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `product_id` BIGINT UNSIGNED NOT NULL,
  `admin_id` BIGINT UNSIGNED NULL DEFAULT NULL,
  `order_id` BIGINT UNSIGNED NULL DEFAULT NULL,
  `movement_type` VARCHAR(40) NOT NULL,
  `quantity` INT NOT NULL,
  `stock_before` INT NOT NULL,
  `stock_after` INT NOT NULL,
  `note` TEXT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_stock_movements_product_id` (`product_id`),
  KEY `idx_stock_movements_admin_id` (`admin_id`),
  KEY `idx_stock_movements_order_id` (`order_id`),
  CONSTRAINT `fk_stock_movements_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_stock_movements_admin` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_stock_movements_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table: banners
-- --------------------------------------------------------
DROP TABLE IF EXISTS `banners`;
CREATE TABLE `banners` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` VARCHAR(255) NOT NULL,
  `description` TEXT NULL,
  `image` VARCHAR(255) NOT NULL,
  `button_text` VARCHAR(100) NULL,
  `button_link` VARCHAR(255) NULL,
  `status` TINYINT NOT NULL DEFAULT 1,
  `sort_order` INT NOT NULL DEFAULT 0,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_banners_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table: settings
-- --------------------------------------------------------
DROP TABLE IF EXISTS `settings`;
CREATE TABLE `settings` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `setting_key` VARCHAR(150) NOT NULL,
  `setting_value` TEXT NULL,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_settings_key` (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;

-- --------------------------------------------------------
-- SEED DATA
-- --------------------------------------------------------

-- Default Administrator
-- Username: admin
-- Password default: admin123 (Encrypted using bcrypt PASSWORD_DEFAULT)
-- Hash below corresponds to 'admin123'
INSERT INTO `admins` (`id`, `name`, `username`, `email`, `password`, `role`, `status`) VALUES
(1, 'Administrator JAWA MART', 'admin', 'admin@jawamart.id', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 1)
ON DUPLICATE KEY UPDATE `id`=`id`;

-- Default Settings
INSERT INTO `settings` (`setting_key`, `setting_value`) VALUES
('store_name', 'JAWA MART'),
('store_tagline', 'Belanja Sembako Mudah, Hemat, dan Praktis.'),
('whatsapp_number', '6287812122735'),
('whatsapp_display', '+62 878-1212-2735'),
('store_email', 'kontak@jawamart.id'),
('store_address', 'Jl. Pasar Tradisional & Sembako Jaya No. 88, Jawa, Indonesia'),
('store_description', 'JAWA MART menyediakan aneka kebutuhan sembako dan keperluan rumah tangga lengkap berkualitas dengan harga hemat dan pengiriman cepat langsung ke rumah Anda.'),
('operating_hours', 'Senin - Minggu: 07.00 - 20.00 WIB'),
('default_shipping_cost', '10000.00'),
('free_shipping_minimum', '150000.00'),
('social_facebook', 'https://facebook.com/jawamart'),
('social_instagram', 'https://instagram.com/jawamart.id'),
('logo_path', 'assets/images/logo.png')
ON DUPLICATE KEY UPDATE `setting_value`=VALUES(`setting_value`);

-- Default Categories (10 Initial Categories as specified in PRD Section 4.3)
INSERT INTO `categories` (`id`, `name`, `slug`, `description`, `image`, `status`) VALUES
(1, 'Beras dan Padi-padian', 'beras-dan-padi-padian', 'Pilihan beras pulen premium, beras merah, dan aneka hasil padi berkualitas tinggi.', 'uploads/categories/beras.svg', 1),
(2, 'Minyak Goreng', 'minyak-goreng', 'Minyak goreng kelapa sawit higienis kemasan pouch dan botol.', 'uploads/categories/minyak.svg', 1),
(3, 'Gula dan Garam', 'gula-dan-garam', 'Gula pasir kristal putih murni dan garam dapur beryodium.', 'uploads/categories/gula-garam.svg', 1),
(4, 'Tepung', 'tepung', 'Tepung terigu protein tinggi, sedang, tepung beras, dan tepung tapioka.', 'uploads/categories/tepung.svg', 1),
(5, 'Mie Instan', 'mie-instan', 'Aneka rasa mie instan favorit keluarga, bihun, dan pasta.', 'uploads/categories/mie-instan.svg', 1),
(6, 'Telur', 'telur', 'Telur ayam negeri dan kampung pilihan segar langsung dari peternak.', 'uploads/categories/telur.svg', 1),
(7, 'Susu dan Minuman', 'susu-dan-minuman', 'Susu kental manis, susu UHT, teh celup wangi, dan kopi bubuk nusantara.', 'uploads/categories/susu-minuman.svg', 1),
(8, 'Bumbu Dapur', 'bumbu-dapur', 'Kecap manis gurih, saus sambal, penyedap rasa, dan rempah bumbu pilihan.', 'uploads/categories/bumbu.svg', 1),
(9, 'Makanan Kaleng', 'makanan-kaleng', 'Ikan sarden kaleng, kornet sapi, dan sayuran kaleng praktis bergizi.', 'uploads/categories/makanan-kaleng.svg', 1),
(10, 'Kebutuhan Rumah Tangga', 'kebutuhan-rumah-tangga', 'Sabun cuci piring, deterjen konsentrat, pembersih lantai, dan tisu.', 'uploads/categories/kebutuhan-rumah.svg', 1)
ON DUPLICATE KEY UPDATE `id`=`id`;

-- Default Products (Initial Sembako Products as specified in PRD Section 7.2)
INSERT INTO `products` (`id`, `category_id`, `sku`, `name`, `slug`, `description`, `price`, `discount_price`, `stock`, `minimum_stock`, `unit`, `image`, `is_featured`, `status`) VALUES
(1, 1, 'BR-PRM-005', 'Beras Premium Ramos Wangi 5 Kg', 'beras-premium-ramos-wangi-5-kg', 'Beras premium kualitas pilihan, pulen alami, tanpa pemutih, tanpa pewangi buatan. Dikemas rapi 5 Kg.', 75000.00, 69500.00, 45, 5, 'Karung', 'uploads/products/beras-premium-5kg.jpg', 1, 1),
(2, 2, 'MY-BIM-002', 'Minyak Goreng Sawit 2 Liter', 'minyak-goreng-sawit-2-liter', 'Minyak goreng kelapa sawit murni berkualitas tinggi, jernih, tahan panas, dan membuat gorengan lebih renyah.', 38000.00, 34500.00, 80, 10, 'Pcs', 'uploads/products/minyak-goreng-2l.jpg', 1, 1),
(3, 3, 'GL-GLK-001', 'Gula Pasir Kristal Putih 1 Kg', 'gula-pasir-kristal-putih-1-kg', 'Gula pasir kristal murni dari tebu alami pilihan. Manis pas, bersih, dan higienis untuk minuman serta aneka masakan.', 18500.00, 17200.00, 60, 10, 'Pack', 'uploads/products/gula-pasir-1kg.jpg', 1, 1),
(4, 4, 'TP-SGT-001', 'Tepung Terigu Serbaguna 1 Kg', 'tepung-terigu-serbaguna-1-kg', 'Tepung terigu protein sedang serbaguna, sangat cocok untuk aneka kue, martabak, donat, dan gorengan renyah.', 14500.00, 13000.00, 40, 5, 'Pack', 'uploads/products/tepung-terigu-1kg.jpg', 1, 1),
(5, 5, 'MI-IND-001', 'Mie Instan Goreng Spesial 85g', 'mie-instan-goreng-spesial-85g', 'Mie instan goreng favorit keluarga dengan bumbu rempah pilihan, bawang goreng renyah, dan kecap manis khas.', 3500.00, 3100.00, 250, 20, 'Pcs', 'uploads/products/indomie-goreng.jpg', 1, 1),
(6, 6, 'TL-AYM-001', 'Telur Ayam Negeri Fresh 1 Kg', 'telur-ayam-negeri-fresh-1-kg', 'Telur ayam ras negeri segar berkualitas grade A, cangkang bersih, kaya protein dan omega untuk nutrisi harian.', 30000.00, 28000.00, 35, 5, 'Kg', 'uploads/products/telur-ayam-1kg.jpg', 1, 1),
(7, 7, 'SS-FFG-001', 'Susu Kental Manis 370g', 'susu-kental-manis-370g', 'Susu kental manis gurih legit mengandung vitamin dan mineral. Pas untuk pelengkap kopi, teh tarik, martabak, dan es buah.', 14000.00, 12500.00, 50, 8, 'Kaleng', 'uploads/products/susu-kental-manis.jpg', 1, 1),
(8, 3, 'GR-KPL-001', 'Garam Dapur Beryodium Halus 250g', 'garam-dapur-beryodium-halus-250g', 'Garam konsumsi beryodium halus, putih bersih, menambah kelezatan masakan sekaligus memenuhi kebutuhan yodium harian.', 4500.00, NULL, 90, 10, 'Pack', 'uploads/products/garam-dapur-1kg.jpg', 0, 1),
(9, 8, 'BM-KCP-520', 'Kecap Manis Tradisional 520ml', 'kecap-manis-tradisional-520ml', 'Kecap manis kental gurih dibuat dari kedelai hitam pilihan dan gula aren alami, memperkaya cita rasa masakan Nusantara.', 23000.00, 20500.00, 45, 5, 'Botol', 'uploads/products/kecap-manis-abc.jpg', 1, 1),
(10, 9, 'MK-ABC-425', 'Ikan Sarden Saus Tomat Segar 425g', 'ikan-sarden-saus-tomat-segar-425g', 'Ikan sarden segar gurih kaya omega-3 dalam paduan saus tomat kental lezat, siap dimasak cepat dan lezat.', 25000.00, 23000.00, 40, 5, 'Kaleng', 'uploads/products/sarden-abc.jpg', 1, 1),
(11, 10, 'RT-SNL-700', 'Sabun Cuci Piring Jeruk Nipis 700ml', 'sabun-cuci-piring-jeruk-nipis-700ml', 'Cairan pencuci piring formula ekstrak jeruk nipis asli, ampuh angkat lemak membandel dan bau amis seketika.', 16500.00, 14900.00, 65, 10, 'Pcs', 'uploads/products/sabun-cuci-piring.jpg', 0, 1),
(12, 7, 'MN-SRW-025', 'Teh Celup Wangi Alami Isi 25', 'teh-celup-wangi-alami-isi-25', 'Teh celup aroma melati wangi dan pekat, dipetik dari pucuk daun teh terbaik pegunungan nusantara.', 8500.00, NULL, 60, 10, 'Pack', 'uploads/products/teh-celup-kotak.jpg', 0, 1)
ON DUPLICATE KEY UPDATE `id`=`id`;

-- Initial Stock Movements Log (Stok Awal)
INSERT INTO `stock_movements` (`product_id`, `admin_id`, `order_id`, `movement_type`, `quantity`, `stock_before`, `stock_after`, `note`, `created_at`) VALUES
(1, 1, NULL, 'Stok Awal', 45, 0, 45, 'Inisialisasi stok awal sistem JAWA MART', NOW()),
(2, 1, NULL, 'Stok Awal', 80, 0, 80, 'Inisialisasi stok awal sistem JAWA MART', NOW()),
(3, 1, NULL, 'Stok Awal', 60, 0, 60, 'Inisialisasi stok awal sistem JAWA MART', NOW()),
(4, 1, NULL, 'Stok Awal', 40, 0, 40, 'Inisialisasi stok awal sistem JAWA MART', NOW()),
(5, 1, NULL, 'Stok Awal', 250, 0, 250, 'Inisialisasi stok awal sistem JAWA MART', NOW()),
(6, 1, NULL, 'Stok Awal', 35, 0, 35, 'Inisialisasi stok awal sistem JAWA MART', NOW()),
(7, 1, NULL, 'Stok Awal', 50, 0, 50, 'Inisialisasi stok awal sistem JAWA MART', NOW()),
(8, 1, NULL, 'Stok Awal', 90, 0, 90, 'Inisialisasi stok awal sistem JAWA MART', NOW()),
(9, 1, NULL, 'Stok Awal', 45, 0, 45, 'Inisialisasi stok awal sistem JAWA MART', NOW()),
(10, 1, NULL, 'Stok Awal', 40, 0, 40, 'Inisialisasi stok awal sistem JAWA MART', NOW()),
(11, 1, NULL, 'Stok Awal', 65, 0, 65, 'Inisialisasi stok awal sistem JAWA MART', NOW()),
(12, 1, NULL, 'Stok Awal', 60, 0, 60, 'Inisialisasi stok awal sistem JAWA MART', NOW());

-- Initial Banners
INSERT INTO `banners` (`id`, `title`, `description`, `image`, `button_text`, `button_link`, `status`, `sort_order`) VALUES
(1, 'Belanja Sembako Hemat, Langsung Antar ke Rumah!', 'Kebutuhan pokok beras, minyak, gula, tepung lengkap dengan harga terbaik dan terpercaya.', 'uploads/banners/banner-1.svg', 'Belanja Sekarang', 'products.php', 1, 1),
(2, 'Pesan Mudah & Praktis Cukup via WhatsApp', 'Pilih sembako di website, checkout otomatis tersimpan dan terhubung ke WhatsApp toko kami.', 'uploads/banners/banner-2.svg', 'Lihat Katalog', 'products.php', 1, 2)
ON DUPLICATE KEY UPDATE `id`=`id`;

COMMIT;
