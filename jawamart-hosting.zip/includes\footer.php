<?php
/**
 * JAWA MART - Frontend Footer Component
 * File: includes/footer.php
 */

declare(strict_types=1);

$storeName        = getSetting('store_name', 'JAWA MART');
$storeTagline     = getSetting('store_tagline', 'Belanja Sembako Mudah, Hemat, dan Praktis.');
$whatsappDisplay  = getSetting('whatsapp_display', '+62 878-1212-2735');
$whatsappOfficial = getStoreWhatsApp();
$storeEmail       = getSetting('store_email', 'kontak@jawamart.id');
$storeAddress     = getSetting('store_address', 'Jl. Pasar Tradisional & Sembako Jaya No. 88, Jawa, Indonesia');
$operatingHours   = getSetting('operating_hours', 'Senin - Minggu: 07.00 - 20.00 WIB');
?>

  <!-- Floating WhatsApp Action Button (PRD Section 1.4) -->
  <a href="https://wa.me/<?= $whatsappOfficial ?>?text=Halo%20<?= urlencode($storeName) ?>%2C%20saya%20ingin%20belanja%20sembako." 
     class="floating-wa-btn" 
     target="_blank" 
     rel="noopener" 
     title="Hubungi Toko via WhatsApp (<?= htmlspecialchars($whatsappDisplay) ?>)"
     aria-label="Chat WhatsApp JAWA MART">
    <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" fill="currentColor" viewBox="0 0 16 16">
      <path d="M13.601 2.326A7.854 7.854 0 0 0 7.994 0C3.627 0 .068 3.558.064 7.926c0 1.399.366 2.76 1.057 3.965L0 16l4.204-1.102a7.933 7.933 0 0 0 3.79.965h.004c4.368 0 7.926-3.558 7.93-7.93A7.898 7.898 0 0 0 13.6 2.326zM7.994 14.521a6.573 6.573 0 0 1-3.356-.92l-.24-.144-2.494.654.666-2.433-.156-.251a6.56 6.56 0 0 1-1.007-3.505c0-3.626 2.957-6.584 6.591-6.584a6.56 6.56 0 0 1 4.66 1.931 6.557 6.557 0 0 1 1.928 4.66c-.004 3.639-2.961 6.592-6.592 6.592zm3.615-4.934c-.197-.099-1.17-.578-1.353-.646-.182-.065-.315-.099-.445.099-.133.197-.513.646-.627.775-.114.133-.232.148-.43.05-.197-.1-.836-.308-1.592-.985-.59-.525-.985-1.175-1.103-1.372-.114-.198-.011-.304.088-.403.087-.088.197-.232.296-.346.1-.114.133-.198.198-.33.065-.134.034-.248-.016-.347-.05-.099-.445-1.076-.612-1.47-.16-.389-.323-.335-.445-.34-.114-.007-.247-.007-.38-.007a.729.729 0 0 0-.529.247c-.182.198-.691.677-.691 1.654 0 .977.71 1.916.81 2.049.098.133 1.394 2.132 3.383 2.992.47.205.84.326 1.129.418.475.152.904.129 1.246.08.38-.058 1.171-.48 1.338-.943.164-.464.164-.86.114-.943-.049-.084-.182-.133-.38-.232z"/>
    </svg>
  </a>

  <!-- Footer -->
  <footer class="footer">
    <div class="container">
      <div class="footer-grid">
        
        <!-- Brand Info -->
        <div class="footer-brand">
          <img src="<?= getBaseUrl('assets/images/logo.png') ?>" alt="<?= htmlspecialchars($storeName) ?>" style="height: 50px; width: auto; object-fit: contain;">
          <p style="margin-bottom: 12px; line-height: 1.6; color: #cbd5e1;">
            <?= htmlspecialchars(getSetting('store_description')) ?>
          </p>
          <div style="margin-top: 14px; color: #20c997; font-weight: 600;">
            ✓ Sembako Berkualitas &nbsp;|&nbsp; ✓ Harga Hemat &nbsp;|&nbsp; ✓ Pengiriman Cepat
          </div>
        </div>

        <!-- Quick Links -->
        <div>
          <h4 class="footer-title">Navigasi Toko</h4>
          <ul class="footer-links">
            <li><a href="<?= getBaseUrl('index.php') ?>">Beranda</a></li>
            <li><a href="<?= getBaseUrl('products.php') ?>">Semua Produk</a></li>
            <li><a href="<?= getBaseUrl('categories.php') ?>">Kategori Sembako</a></li>
            <li><a href="<?= getBaseUrl('cart.php') ?>">Keranjang Belanja</a></li>
            <li><a href="<?= getBaseUrl('about.php') ?>">Tentang JAWA MART</a></li>
            <li><a href="<?= getBaseUrl('contact.php') ?>">Hubungi Kami</a></li>
          </ul>
        </div>

        <!-- Kategori Pilihan -->
        <div>
          <h4 class="footer-title">Kategori Utama</h4>
          <ul class="footer-links">
            <li><a href="<?= getBaseUrl('products.php?category=beras-dan-padi-padian') ?>">Beras &amp; Padi</a></li>
            <li><a href="<?= getBaseUrl('products.php?category=minyak-goreng') ?>">Minyak Goreng</a></li>
            <li><a href="<?= getBaseUrl('products.php?category=gula-dan-garam') ?>">Gula &amp; Garam</a></li>
            <li><a href="<?= getBaseUrl('products.php?category=tepung') ?>">Tepung Terigu</a></li>
            <li><a href="<?= getBaseUrl('products.php?category=mie-instan') ?>">Mie Instan</a></li>
            <li><a href="<?= getBaseUrl('products.php?category=telur') ?>">Telur Ayam Segar</a></li>
          </ul>
        </div>

        <!-- Kontak & Jam Layanan -->
        <div>
          <h4 class="footer-title">Kontak &amp; Alamat</h4>
          <ul class="footer-links" style="line-height: 1.6;">
            <li>📍 <?= htmlspecialchars($storeAddress) ?></li>
            <li>💬 WhatsApp: <a href="https://wa.me/<?= $whatsappOfficial ?>" target="_blank" rel="noopener" style="color: #25d366; font-weight: bold;"><?= htmlspecialchars($whatsappDisplay) ?></a></li>
            <li>✉️ Email: <?= htmlspecialchars($storeEmail) ?></li>
            <li>🕒 Jam Buka: <?= htmlspecialchars($operatingHours) ?></li>
          </ul>
        </div>

      </div>

      <!-- Bottom Bar -->
      <div class="footer-bottom">
        <p>&copy; <?= date('Y') ?> <strong><?= htmlspecialchars($storeName) ?></strong>. Seluruh Hak Cipta Dilindungi. Belanja Sembako Mudah, Hemat, dan Praktis.</p>
        <p style="margin-top: 6px; font-size: 11px;">
          <a href="<?= getBaseUrl('admin/login.php') ?>" style="color: #64748b; text-decoration: underline;">Portal Administrator Toko</a>
        </p>
      </div>
    </div>
  </footer>

  <!-- Scripts -->
  <script src="<?= getBaseUrl('assets/js/cart.js') ?>"></script>
  <script src="<?= getBaseUrl('assets/js/main.js') ?>"></script>
</body>
</html>
