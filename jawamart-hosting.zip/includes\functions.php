<?php
/**
 * JAWA MART - Core Helper Functions
 * File: includes/functions.php
 */

declare(strict_types=1);

if (!defined('JAWA_MART_APP')) {
    define('JAWA_MART_APP', true);
}

require_once __DIR__ . '/../config/database.php';

// Inisialisasi koneksi database PDO global
$pdo = getDBConnection();

/**
 * Inisialisasi PHP Session dengan parameter keamanan
 */
function initSession(): void {
    if (session_status() === PHP_SESSION_NONE) {
        $lifetime = 86400 * 7; // 7 hari
        $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == 443);
        
        session_set_cookie_params([
            'lifetime' => $lifetime,
            'path'     => '/',
            'domain'   => '',
            'secure'   => $secure,
            'httponly' => true,
            'samesite' => 'Lax'
        ]);
        
        session_start();
    }
}

// Inisialisasi session otomatis
initSession();

/**
 * Mengambil seluruh pengaturan toko dari database (cached memory)
 *
 * @return array<string, string>
 */
function getAllSettings(): array {
    static $settingsCache = null;

    if ($settingsCache !== null) {
        return $settingsCache;
    }

    $pdo = getDBConnection();
    try {
        $stmt = $pdo->query("SELECT setting_key, setting_value FROM settings");
        $results = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
        $settingsCache = $results ?: [];
    } catch (Exception $e) {
        $settingsCache = [];
    }

    // Default fallback values
    $defaults = [
        'store_name'            => 'JAWA MART',
        'store_tagline'         => 'Belanja Sembako Mudah, Hemat, dan Praktis.',
        'whatsapp_number'       => '6287812122735',
        'whatsapp_display'      => '+62 878-1212-2735',
        'store_email'           => 'kontak@jawamart.id',
        'store_address'         => 'Jl. Pasar Tradisional & Sembako Jaya No. 88, Jawa, Indonesia',
        'store_description'     => 'JAWA MART menyediakan aneka kebutuhan sembako dan keperluan rumah tangga lengkap berkualitas dengan harga hemat dan pengiriman cepat.',
        'operating_hours'       => 'Senin - Minggu: 07.00 - 20.00 WIB',
        'default_shipping_cost' => '10000',
        'free_shipping_minimum' => '150000',
        'social_facebook'       => 'https://facebook.com/jawamart',
        'social_instagram'      => 'https://instagram.com/jawamart.id',
        'logo_path'             => 'assets/images/logo.png'
    ];

    $settingsCache = array_merge($defaults, $settingsCache);
    return $settingsCache;
}

/**
 * Mengambil satu nilai pengaturan toko
 *
 * @param string $key
 * @param string $default
 * @return string
 */
function getSetting(string $key, string $default = ''): string {
    $settings = getAllSettings();
    return $settings[$key] ?? $default;
}

/**
 * Memperbarui nilai pengaturan toko
 *
 * @param string $key
 * @param string $value
 * @return bool
 */
function updateSetting(string $key, string $value): bool {
    $pdo = getDBConnection();
    try {
        $stmt = $pdo->prepare("
            INSERT INTO settings (setting_key, setting_value, updated_at) 
            VALUES (:key, :val, NOW()) 
            ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = NOW()
        ");
        return $stmt->execute(['key' => $key, 'val' => $value]);
    } catch (Exception $e) {
        error_log("Error updating setting: " . $e->getMessage());
        return false;
    }
}

/**
 * Format mata uang Rupiah
 *
 * @param float|int|string|null $amount
 * @return string Contoh: Rp 75.000
 */
function formatRupiah($amount): string {
    $num = is_numeric($amount) ? (float)$amount : 0.0;
    return 'Rp ' . number_format($num, 0, ',', '.');
}

/**
 * Format tanggal Indonesia
 *
 * @param string|null $datetime
 * @param bool $withTime
 * @return string
 */
function formatDate(?string $datetime, bool $withTime = true): string {
    if (!$datetime || $datetime === '0000-00-00 00:00:00') {
        return '-';
    }

    $timestamp = strtotime($datetime);
    if ($timestamp === false) {
        return $datetime;
    }

    $bulan = [
        1 => 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
        'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
    ];

    $d = date('j', $timestamp);
    $m = (int)date('n', $timestamp);
    $y = date('Y', $timestamp);
    $monthName = $bulan[$m] ?? date('M', $timestamp);

    $dateStr = "$d $monthName $y";
    if ($withTime) {
        $dateStr .= ' ' . date('H:i', $timestamp) . ' WIB';
    }

    return $dateStr;
}

/**
 * Membersihkan nomor telepon untuk integrasi link WhatsApp (hanya digit, awali dengan 62)
 *
 * @param string $phone
 * @return string Contoh: 6287812122735
 */
function cleanPhoneForWhatsApp(string $phone): string {
    // Hapus karakter non-digit
    $cleaned = preg_replace('/[^0-9]/', '', $phone);

    // Jika diawali 0, ganti dengan 62
    if (str_starts_with($cleaned, '0')) {
        $cleaned = '62' . substr($cleaned, 1);
    }
    // Jika diawali +62
    elseif (str_starts_with($cleaned, '62')) {
        // sudah benar
    } else {
        // default tambahkan 62 jika lokal
        $cleaned = '62' . $cleaned;
    }

    return $cleaned;
}

/**
 * Format nomor telepon untuk tampilan visual yang rapi
 *
 * @param string $phone
 * @return string Contoh: +62 878-1212-2735
 */
function formatPhoneDisplay(string $phone): string {
    $clean = cleanPhoneForWhatsApp($phone);
    if (str_starts_with($clean, '62') && strlen($clean) >= 10) {
        $prefix = '+62 ';
        $rest = substr($clean, 2);
        if (strlen($rest) >= 10) {
            return $prefix . substr($rest, 0, 3) . '-' . substr($rest, 3, 4) . '-' . substr($rest, 7);
        } elseif (strlen($rest) >= 9) {
            return $prefix . substr($rest, 0, 3) . '-' . substr($rest, 3, 3) . '-' . substr($rest, 6);
        }
    }
    return $phone;
}

/**
 * Mengambil nomor WhatsApp resmi toko dari Pengaturan Database
 *
 * @return string
 */
function getStoreWhatsApp(): string {
    $wa = getSetting('whatsapp_number', '6287812122735');
    return cleanPhoneForWhatsApp($wa);
}

/**
 * Membuat kode pesanan unik dengan format: JM-XXXXXXXX
 *
 * @return string
 */
function generateOrderCode(): string {
    $chars = '23456789ABCDEFGHJKLMNPQRSTUVWXYZ'; // Hindari karakter membingungkan seperti 0, 1, O, I
    $rand = '';
    for ($i = 0; $i < 8; $i++) {
        $rand .= $chars[random_int(0, strlen($chars) - 1)];
    }
    return 'JM-' . $rand;
}

/**
 * Membuat teks pesan WhatsApp pemesanan sesuai format standar PRD Section 5.4
 *
 * @param array $order Data order dari tabel orders
 * @param array $items Daftar item dari tabel order_items
 * @return string
 */
function buildWhatsAppOrderMessage(array $order, array $items): string {
    $storeName = getSetting('store_name', 'JAWA MART');
    
    $msg = "Halo *{$storeName}*, saya ingin melakukan pemesanan dengan rincian berikut.\n\n";
    $msg .= "*Kode Pesanan:* " . $order['order_code'] . "\n\n";
    $msg .= "*Nama:* " . $order['customer_name'] . "\n";
    $msg .= "*Nomor WhatsApp:* " . $order['customer_phone'] . "\n";
    $msg .= "*Alamat Pengiriman:* " . $order['customer_address'] . "\n\n";
    
    $msg .= "*Daftar Produk:*\n";
    foreach ($items as $item) {
        $priceFormatted = formatRupiah($item['unit_price']);
        $subtotalFormatted = formatRupiah($item['subtotal']);
        $unit = !empty($item['unit']) ? ' ' . $item['unit'] : '';
        $msg .= "• {$item['product_name']} — {$item['quantity']}{$unit} × {$priceFormatted} = {$subtotalFormatted}\n";
    }
    $msg .= "\n";
    
    $msg .= "*Subtotal:* " . formatRupiah($order['subtotal']) . "\n";
    $msg .= "*Ongkir:* " . formatRupiah($order['shipping_cost']) . "\n";
    $msg .= "*Total:* *" . formatRupiah($order['total']) . "*\n\n";
    
    if (!empty($order['customer_note'])) {
        $msg .= "*Catatan:* " . $order['customer_note'] . "\n\n";
    }
    
    $msg .= "Mohon konfirmasi pesanan saya. Terima kasih.";
    return $msg;
}

/**
 * Membuat URL WhatsApp lengkap yang siap dibuka oleh browser / aplikasi WhatsApp
 *
 * @param array $order
 * @param array $items
 * @return string
 */
function buildWhatsAppOrderUrl(array $order, array $items): string {
    $waNumber = getStoreWhatsApp();
    $message = buildWhatsAppOrderMessage($order, $items);
    return "https://wa.me/{$waNumber}?text=" . rawurlencode($message);
}

/**
 * Membuat link WhatsApp untuk konsultasi atau tanya produk
 *
 * @param string $customMessage
 * @return string
 */
function buildWhatsAppDirectUrl(string $customMessage = ''): string {
    $waNumber = getStoreWhatsApp();
    if (empty($customMessage)) {
        $storeName = getSetting('store_name', 'JAWA MART');
        $customMessage = "Halo {$storeName}, saya ingin bertanya seputar produk sembako dan ketersediaan barang.";
    }
    return "https://wa.me/{$waNumber}?text=" . rawurlencode($customMessage);
}

/**
 * Catat riwayat pergerakan stok (Stock Movement)
 *
 * @param PDO $pdo
 * @param int $productId
 * @param int|null $adminId
 * @param int|null $orderId
 * @param string $type
 * @param int $quantity
 * @param int $stockBefore
 * @param int $stockAfter
 * @param string|null $note
 * @return bool
 */
function recordStockMovement(
    PDO $pdo,
    int $productId,
    ?int $adminId,
    ?int $orderId,
    string $type,
    int $quantity,
    int $stockBefore,
    int $stockAfter,
    ?string $note = null
): bool {
    try {
        $stmt = $pdo->prepare("
            INSERT INTO stock_movements (
                product_id, admin_id, order_id, movement_type, 
                quantity, stock_before, stock_after, note, created_at
            ) VALUES (
                :product_id, :admin_id, :order_id, :movement_type, 
                :quantity, :stock_before, :stock_after, :note, NOW()
            )
        ");
        return $stmt->execute([
            'product_id'    => $productId,
            'admin_id'      => $adminId,
            'order_id'      => $orderId,
            'movement_type' => $type,
            'quantity'      => $quantity,
            'stock_before'  => $stockBefore,
            'stock_after'   => $stockAfter,
            'note'          => $note
        ]);
    } catch (Exception $e) {
        error_log("Failed to record stock movement: " . $e->getMessage());
        return false;
    }
}

/**
 * CSRF Protection Helpers
 */
function generateCsrfToken(): string {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verifyCsrfToken(?string $token): bool {
    if (empty($_SESSION['csrf_token']) || empty($token)) {
        return false;
    }
    return hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * Flash Notification Messages
 */
function setFlash(string $type, string $message): void {
    $_SESSION['flash'] = [
        'type'    => $type, // 'success', 'danger', 'warning', 'info'
        'message' => $message
    ];
}

function getFlash(): ?array {
    if (isset($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}

/**
 * Helper Keamanan Sanitasi Input
 *
 * @param mixed $input
 * @return mixed
 */
function sanitize($input) {
    if (is_array($input)) {
        return array_map('sanitize', $input);
    }
    return htmlspecialchars(trim((string)$input), ENT_QUOTES, 'UTF-8');
}

/**
 * Upload gambar dengan validasi ketat (MIME, size, extension)
 *
 * @param array $file
 * @param string $subDirectory Contoh: 'products', 'categories', 'banners'
 * @param string $prefix
 * @return array ['success' => bool, 'path' => string, 'message' => string]
 */
function uploadImage(array $file, string $subDirectory, string $prefix = 'img'): array {
    if (!isset($file['error']) || is_array($file['error'])) {
        return ['success' => false, 'message' => 'Parameter file tidak valid.'];
    }

    if ($file['error'] !== UPLOAD_ERR_OK) {
        return ['success' => false, 'message' => 'Gagal mengunggah file. Kode error: ' . $file['error']];
    }

    // Batas maksimal ukuran 2MB (2 * 1024 * 1024 = 2097152 bytes)
    if ($file['size'] > 2097152) {
        return ['success' => false, 'message' => 'Ukuran file melebihi batas maksimal 2 MB.'];
    }

    // Validasi ekstensi
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $allowedExts = ['jpg', 'jpeg', 'png', 'webp', 'svg'];
    if (!in_array($ext, $allowedExts, true)) {
        return ['success' => false, 'message' => 'Format file tidak diizinkan. Gunakan JPG, PNG, WEBP, atau SVG.'];
    }

    // Validasi MIME Type jika fungsi finfo tersedia
    if (class_exists('finfo')) {
        $finfo = new finfo(FILEINFO_MIME_TYPE);
        $mime = $finfo->file($file['tmp_name']);
        $allowedMimes = ['image/jpeg', 'image/png', 'image/webp', 'image/svg+xml'];
        if (!in_array($mime, $allowedMimes, true)) {
            return ['success' => false, 'message' => 'Tipe konten file tidak valid sebagai gambar.'];
        }
    }

    $targetDir = __DIR__ . '/../uploads/' . trim($subDirectory, '/') . '/';
    if (!is_dir($targetDir)) {
        @mkdir($targetDir, 0755, true);
    }

    // Buat nama file unik acak
    $filename = $prefix . '_' . bin2hex(random_bytes(8)) . '_' . time() . '.' . $ext;
    $targetPath = $targetDir . $filename;

    if (move_uploaded_file($file['tmp_name'], $targetPath)) {
        return [
            'success'  => true,
            'path'     => 'uploads/' . trim($subDirectory, '/') . '/' . $filename,
            'filename' => $filename,
            'message'  => 'Gambar berhasil diunggah.'
        ];
    }

    return ['success' => false, 'message' => 'Gagal memindahkan file ke direktori uploads.'];
}

/**
 * Slugify text
 */
function slugify(string $text): string {
    $text = preg_replace('~[^\pL\d]+~u', '-', $text);
    $text = iconv('utf-8', 'us-ascii//TRANSLIT', $text) ?: $text;
    $text = preg_replace('~[^-\w]+~', '', $text);
    $text = trim($text, '-');
    $text = preg_replace('~-+~', '-', $text);
    $text = strtolower($text);
    return empty($text) ? 'item-' . time() : $text;
}
