<?php
/**
 * JAWA MART - Frontend Header Component
 * File: includes/header.php
 */

declare(strict_types=1);

require_once __DIR__ . '/functions.php';

$storeName        = getSetting('store_name', 'JAWA MART');
$storeTagline     = getSetting('store_tagline', 'Belanja Sembako Mudah, Hemat, dan Praktis.');
$whatsappDisplay  = getSetting('whatsapp_display', '+62 878-1212-2735');
$whatsappOfficial = getStoreWhatsApp();
$operatingHours   = getSetting('operating_hours', 'Senin - Minggu: 07.00 - 20.00 WIB');
$pageTitle        = isset($pageTitle) ? htmlspecialchars($pageTitle) . ' | ' . htmlspecialchars($storeName) : htmlspecialchars($storeName) . ' — ' . htmlspecialchars($storeTagline);
$metaDesc         = isset($metaDesc) ? htmlspecialchars($metaDesc) : htmlspecialchars(getSetting('store_description'));
$currentScript    = basename($_SERVER['PHP_SELF']);

// Ambil kategori untuk dropdown atau nav jika diperlukan
$headerCategories = [];
try {
    $stmtHdr = $pdo->query("SELECT id, name, slug FROM categories WHERE status = 1 ORDER BY name ASC LIMIT 10");
    $headerCategories = $stmtHdr->fetchAll();
} catch (Throwable $e) {
    // fallback
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= $pageTitle ?></title>
  <meta name="description" content="<?= $metaDesc ?>">
  <meta name="keywords" content="sembako online, beras murah, minyak goreng, gula, tepung, telur, belanja sembako, jawa mart">
  <meta name="author" content="JAWA MART">
  
  <!-- Open Graph -->
  <meta property="og:title" content="<?= $pageTitle ?>">
  <meta property="og:description" content="<?= $metaDesc ?>">
  <meta property="og:type" content="website">
  <meta property="og:image" content="<?= getBaseUrl('assets/images/logo.png') ?>">

  <!-- Favicon -->
  <link rel="icon" type="image/svg+xml" href="<?= getBaseUrl('assets/images/favicon.svg') ?>">

  <!-- Stylesheets -->
  <link rel="stylesheet" href="<?= getBaseUrl('assets/css/style.css') ?>">
</head>
<body>

  <!-- Topbar -->
  <div class="topbar">
    <div class="container">
      <div class="topbar-left">
        <span>🕒 <?= htmlspecialchars($operatingHours) ?></span>
        <span>📍 Melayani Pengiriman Cepat ke Rumah Anda</span>
      </div>
      <div class="topbar-right">
        <a href="https://wa.me/<?= $whatsappOfficial ?>" target="_blank" rel="noopener">
          <span>💬 Layanan WhatsApp: <strong><?= htmlspecialchars($whatsappDisplay) ?></strong></span>
        </a>
      </div>
    </div>
  </div>

  <!-- Header Main -->
  <header class="header">
    <div class="header-main">
      <div class="container">
        <div class="header-row">
          
          <!-- Brand Logo -->
          <a href="<?= getBaseUrl('index.php') ?>" class="brand-logo" title="<?= htmlspecialchars($storeName) ?>">
            <img src="<?= getBaseUrl('assets/images/logo.png') ?>" alt="<?= htmlspecialchars($storeName) ?>" style="height: 52px; width: auto; object-fit: contain;">
          </a>

          <!-- Search Bar -->
          <div class="header-search">
            <form action="<?= getBaseUrl('products.php') ?>" method="GET" class="search-form">
              <input type="text" name="q" class="search-input" placeholder="Cari sembako (beras, minyak, gula, mie...)" value="<?= htmlspecialchars($_GET['q'] ?? '') ?>" autocomplete="off" required>
              <button type="submit" class="search-btn" aria-label="Cari">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
                  <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z"/>
                </svg>
                <span>Cari</span>
              </button>
            </form>
          </div>

          <!-- Header Actions -->
          <div class="header-actions">
            <!-- Cart Icon -->
            <a href="<?= getBaseUrl('cart.php') ?>" class="header-icon-btn" title="Lihat Keranjang Belanja">
              <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="currentColor" viewBox="0 0 16 16">
                <path d="M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .491.592l-1.5 8A.5.5 0 0 1 13 12H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5zM3.102 4l1.313 7h8.17l1.313-7H3.102zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm-7 1a1 1 0 1 1 0 2 1 1 0 0 1 0-2zm7 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2z"/>
              </svg>
              <span class="cart-badge" style="display: none;">0</span>
            </a>

            <!-- WhatsApp Direct Button -->
            <a href="https://wa.me/<?= $whatsappOfficial ?>?text=Halo%20<?= urlencode($storeName) ?>%2C%20saya%20ingin%20bertanya%20seputar%20produk%20sembako." target="_blank" rel="noopener" class="btn-wa-header" title="Chat WhatsApp Toko">
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="currentColor" viewBox="0 0 16 16">
                <path d="M13.601 2.326A7.854 7.854 0 0 0 7.994 0C3.627 0 .068 3.558.064 7.926c0 1.399.366 2.76 1.057 3.965L0 16l4.204-1.102a7.933 7.933 0 0 0 3.79.965h.004c4.368 0 7.926-3.558 7.93-7.93A7.898 7.898 0 0 0 13.6 2.326zM7.994 14.521a6.573 6.573 0 0 1-3.356-.92l-.24-.144-2.494.654.666-2.433-.156-.251a6.56 6.56 0 0 1-1.007-3.505c0-3.626 2.957-6.584 6.591-6.584a6.56 6.56 0 0 1 4.66 1.931 6.557 6.557 0 0 1 1.928 4.66c-.004 3.639-2.961 6.592-6.592 6.592zm3.615-4.934c-.197-.099-1.17-.578-1.353-.646-.182-.065-.315-.099-.445.099-.133.197-.513.646-.627.775-.114.133-.232.148-.43.05-.197-.1-.836-.308-1.592-.985-.59-.525-.985-1.175-1.103-1.372-.114-.198-.011-.304.088-.403.087-.088.197-.232.296-.346.1-.114.133-.198.198-.33.065-.134.034-.248-.016-.347-.05-.099-.445-1.076-.612-1.47-.16-.389-.323-.335-.445-.34-.114-.007-.247-.007-.38-.007a.729.729 0 0 0-.529.247c-.182.198-.691.677-.691 1.654 0 .977.71 1.916.81 2.049.098.133 1.394 2.132 3.383 2.992.47.205.84.326 1.129.418.475.152.904.129 1.246.08.38-.058 1.171-.48 1.338-.943.164-.464.164-.86.114-.943-.049-.084-.182-.133-.38-.232z"/>
              </svg>
              <span>WhatsApp</span>
            </a>

            <!-- Mobile Menu Toggle Button -->
            <button class="mobile-nav-toggle" aria-label="Buka Menu">
              ☰
            </button>
          </div>

        </div>
      </div>
    </div>

    <!-- Navigation Menu -->
    <nav class="navbar" id="mainNavbar">
      <div class="container">
        <ul class="nav-list">
          <li><a href="<?= getBaseUrl('index.php') ?>" class="nav-link <?= $currentScript === 'index.php' ? 'active' : '' ?>">Beranda</a></li>
          <li><a href="<?= getBaseUrl('products.php') ?>" class="nav-link <?= $currentScript === 'products.php' && empty($_GET['category']) ? 'active' : '' ?>">Semua Produk</a></li>
          <li><a href="<?= getBaseUrl('categories.php') ?>" class="nav-link <?= $currentScript === 'categories.php' ? 'active' : '' ?>">Kategori Sembako</a></li>
          <li><a href="<?= getBaseUrl('about.php') ?>" class="nav-link <?= $currentScript === 'about.php' ? 'active' : '' ?>">Tentang Kami</a></li>
          <li><a href="<?= getBaseUrl('contact.php') ?>" class="nav-link <?= $currentScript === 'contact.php' ? 'active' : '' ?>">Kontak &amp; Alamat</a></li>
        </ul>
      </div>
    </nav>
  </header>

  <!-- Flash Message Container -->
  <?php $flash = getFlash(); ?>
  <?php if ($flash): ?>
    <div class="container" style="margin-top: 16px;">
      <div class="flash-alert <?= htmlspecialchars($flash['type']) ?>">
        <span><?= htmlspecialchars($flash['message']) ?></span>
        <button type="button" onclick="this.parentElement.remove()" style="background:none; border:none; cursor:pointer; font-size:16px;">&times;</button>
      </div>
    </div>
  <?php endif; ?>
